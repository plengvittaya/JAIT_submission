from pathlib import Path
from collections import Counter
import csv
rows = list(csv.DictReader(Path(__file__).with_name('case_results.csv').open(encoding='utf-8-sig')))
assert len(rows) == len({(r['site'], r['task']) for r in rows}) == 9
for rule in ('prespecified_endpoint', 'original_task_scope_secondary'):
    counts = Counter(row[rule] for row in rows)
    print(rule, dict(counts), 'correct', counts['TP'] + counts['TN'], 'wrong', counts['FP'] + counts['FN'], 'unresolved', counts['U'])
