from inspect_destinations import read,base
from urllib.parse import urlsplit,unquote,parse_qsl
from collections import Counter
import csv,hashlib
def canon(u):
 s=urlsplit(u);return (s.hostname.removeprefix('www.'),unquote(s.path).rstrip('/'),tuple(sorted(parse_qsl(s.query))))
labels={(r['site'],r['task'],r['requested']):r for r in read('destination_labels.json')}
refs={s[0]:s[3:] for s in read('references.json')['sites']}
assert (base/'capture.json').read_bytes()==(base/'replay.json').read_bytes()
rows=[];used=set()
for site in read('replay.json'):
 name=site['site'];f=name+'-states.json';assert hashlib.sha256((base/f).read_bytes()).hexdigest()==site['stateHash']
 states=read(f)['pages'];shared={}
 for method,arm in site['arms'].items():
  for choice in arm['choices']:
   key=(choice['id'],choice['url'])
   if key in shared:assert shared[key]==choice['all']
   shared[key]=choice['all']
  for task,t in arm['result'].items():
   visits=[v for v in arm['visits'] if v['id']==task];outcomes=[]
   gold={canon(u) for u in refs[name][int(task[1])-1]};exact=False
   for v in visits:
    k=(name,task,v['u']);used.add(k);tag=labels[k]['label'];outcomes.append(tag)
    if tag=='Y' and canon(states[v['u']]['actualUrl']) in gold:exact=True
   reached='Y' if 'Y' in outcomes else 'U' if 'U' in outcomes else 'N'
   reported=t['taskCompleted'];end=t['decisionLogs'][-1]
   terminal='NA'
   if reported:
    final=next((v for v in visits if v['step']==end['step']),None)
    if final:terminal=labels[(name,task,final['u'])]['label']
    else:
     assert 'Direct official document link' in end['reasoning'];terminal='U'
   assert t['totalSteps']<=5 and (terminal!='Y' or reached=='Y')
   rows.append(dict(site=name,task=task,method=method,steps=t['totalSteps'],reached=reached,exact_reference_opened=exact,reported=reported,terminal_correct=terminal,last_selected=end['selectedHref'],termination=t['terminationReason']))
assert used==set(labels)
assert len(rows)==18
with (base/'case_results.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
for m in ('IFT','BM25'):
 r=[x for x in rows if x['method']==m];print(m,Counter(x['reached'] for x in r),Counter(x['terminal_correct'] for x in r),sum(x['exact_reference_opened'] for x in r))
for r in rows:print(r['site'],r['task'],r['method'],r['steps'],r['reached'],r['terminal_correct'])
