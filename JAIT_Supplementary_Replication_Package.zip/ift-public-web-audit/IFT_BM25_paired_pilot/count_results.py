from pathlib import Path
import csv
from collections import Counter
rows=list(csv.DictReader(Path(__file__).with_name('case_results.csv').open(encoding='utf-8-sig')))
for method in ('IFT','BM25'):
    arm=[r for r in rows if r['method']==method]
    assert len({(r['site'],r['task']) for r in arm})==len(arm)==9
    reports=[r for r in arm if r['reported']=='True']
    print(method,'reached',sum(r['reached']=='Y' for r in arm),'of',len(arm),'reported',len(reports),'terminal labels',dict(Counter(r['terminal_correct'] for r in reports)))
