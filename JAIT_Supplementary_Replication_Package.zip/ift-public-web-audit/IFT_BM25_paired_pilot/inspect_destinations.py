from pathlib import Path
import json
from urllib.parse import unquote
base=Path(__file__).parent
def read(n):return json.loads((base/n).read_text(encoding='utf-8-sig'))
def records():
 for site in read('replay.json'):
  code=site['site']; states=read(code+'-states.json')['pages']
  unique={(v['id'],v['u']) for arm in site['arms'].values() for v in arm['visits']}
  for task,u in sorted(unique):
   st=states[u];ev=(st.get('snapshot') or {}).get('evidence',{});yield code,task,u,st,ev
if __name__=='__main__':
 for code,t,u,st,e in records():
  x=e.get('main','')
  print(code,t,unquote(u)[:145],st['navRes'],e.get('title'),str(e.get('headings',[]))[:330],x.replace('\n',' ')[:230])
