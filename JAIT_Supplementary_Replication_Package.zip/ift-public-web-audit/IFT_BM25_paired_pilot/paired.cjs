const fs=require('fs'),crypto=require('crypto'),{stripTypeScriptTypes}=require('node:module'),{chromium}=require('playwright');
process.chdir(__dirname);
const get=n=>fs.readFileSync(n,'utf8').replace(/^\uFEFF/,'');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const src=get('../tests/ift_foraging_audit.spec.ts').replace(/\r\n/g,'\n');
const sites=JSON.parse(get('references.json')).sites.map(s=>({id:s[0],home:s[2]}));
const mode=process.argv[2],lock=JSON.parse(get('lock.json'));
for(const [n,h] of Object.entries(lock.hashes))if(hash(fs.readFileSync(n))!==h)throw Error('Changed '+n);
function section(a,b){let i=src.indexOf(a),j=src.indexOf(b,i+a.length);if(i<0||j<0)throw Error(a);return src.slice(i,j);}
const segment=new Intl.Segmenter('th',{granularity:'word'});
function tokens(s){return Array.from(segment.segment(s.normalize('NFKC').toLowerCase())).filter(t=>t.isWordLike).map(t=>t.segment);}
function ranks(candidates,task){
 const query=new Set(tokens([...task.primaryKeywords,...task.secondaryKeywords,...task.urlTokens].join(' ')));
 const docs=candidates.map(c=>{let path=new URL(c.href).pathname;try{path=decodeURIComponent(path)}catch{}return tokens([...new Set([c.text,c.ariaLabel,c.title].filter(Boolean)),path].join(' '));});
 const mean=docs.reduce((a,d)=>a+d.length,0)/(docs.length||1)||1;
 const df=new Map();for(const d of docs)for(const t of new Set(d))if(query.has(t))df.set(t,1+(df.get(t)||0));
 return new Map(docs.map((d,i)=>{const freq=new Map();for(const t of d)if(query.has(t))freq.set(t,1+(freq.get(t)||0));let score=0;
 for(const [term,f] of freq){const n=df.get(term);score+=Math.log1p((docs.length-n+0.5)/(n+0.5))*f*2.2/(f+1.2*(0.25+0.75*d.length/mean));}return [candidates[i],score];}));
}
const original=section('type RegionType','test.describe(');
const api=original.replace('bodyTextSample: bodyText.slice(0, 5000),',`evidence:{title:document.title,url:location.href,body:document.body.innerText,headings:Array.from(document.querySelectorAll('h1,h2,h3')).map(x=>x.innerText).filter(Boolean),main:(document.querySelector('main,article,[role=main]')||document.body).innerText},bodyTextSample: bodyText.slice(0, 5000),`);
const setup=section('let homeSnapshot = await extractPageMetricsAndLinks(page);','let baseHost');
const live=section('const navRes = await safeNavigate(page, targetHref','if (!navRes.ok || !nextSnapshot');
let loop=section('const taskResults: Record','const taskList = Object.values(taskResults)').replace(live,'const {navRes,snapshot:nextSnapshot,actualUrl:actualNextUrl}=await lookup(targetHref,task.id,step);\n');
loop=loop.replace('const scoredCandidates =','const scores = useBM ? ranks(currentSnapshot.candidates,task) : null; const scoredCandidates =')
.replace('candidate: c,','candidate: c, rankScore: useBM ? scores.get(c) : s.scentScore,')
.replace('b.scentScore - a.scentScore','b.rankScore - a.rankScore')
.replace('if (step === 1','track(task.id,step,currentPatch.url,currentSnapshot.candidates,scoredCandidates); if (step === 1');
if(!loop.includes('rankScore:')||!api.includes('evidence:{'))throw Error('Instrumentation failed');
const prog=api+'return {safeNavigate,extractPageMetricsAndLinks,prepare:async(page,resolvedUrl)=>{'+setup+'return {snapshot:homeSnapshot,actualUrl:resolvedUrl}},run:async(homeSnapshot,resolvedUrl,lookup,useBM,track)=>{const baseHost=new URL(resolvedUrl).hostname;'+loop+'return taskResults}}';
const engine=new Function('ranks','return '+stripTypeScriptTypes('function make(){'+prog+'}'))(ranks)();
async function main(){
 if(!['capture','replay'].includes(mode))throw Error('mode');
 const browser=mode==='capture'?await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'}):null;
 async function fetch(url,home){
 const ctx=await browser.newContext({viewport:{width:1366,height:768},ignoreHTTPSErrors:true,serviceWorkers:'block',acceptDownloads:false,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'});
 try{await ctx.route('**/*',r=>['GET','HEAD'].includes(r.request().method())?r.continue():r.abort());const page=await ctx.newPage(),responses=[];
 page.on('response',r=>{if(r.request().isNavigationRequest()&&r.frame()===page.mainFrame())responses.push([r.url(),r.status()])});
 const navRes=await engine.safeNavigate(page,url,home?15000:11000);let state={snapshot:null,actualUrl:page.url()};
 if(navRes.ok){state=home?await engine.prepare(page,page.url()):{snapshot:await engine.extractPageMetricsAndLinks(page),actualUrl:page.url()};}
 return {...state,navRes,responses,time:new Date().toISOString()};}finally{await ctx.close()}}
 async function collect(s){
 const file=s.id+'-states.json',stash=mode==='capture'?{pages:{},time:new Date().toISOString()}:JSON.parse(get(file));
 if(mode==='capture'){if(fs.existsSync(file))throw Error('Existing '+file);stash.home=await fetch(s.home,true);stash.pages[stash.home.actualUrl]=stash.home;}
 const arms={};
 if(stash.home.navRes.ok&&stash.home.snapshot?.candidates.length){
 for(const method of ['IFT','BM25']){
 const visits=[],choices=[];
 async function lookup(u,id,step){if(!Object.hasOwn(stash.pages,u)){if(!browser)throw Error('Missing '+u);stash.pages[u]=await fetch(u,false);}visits.push({id,step,u});return stash.pages[u];}
 const track=(id,step,url,all,ranked)=>choices.push({id,step,url,all:hash(JSON.stringify(all)),eligible:hash(JSON.stringify(all.filter(c=>ranked.some(x=>x.candidate===c)))),n:all.length,best:ranked[0]?.candidate.href,rank:ranked[0]?.rankScore});
 const result=await engine.run(stash.home.snapshot,stash.home.actualUrl,lookup,method==='BM25',track);
 for(const t of Object.values(result))delete t.completionTimeMs;
 arms[method]={result,visits,choices};
 }}
 if(browser)fs.writeFileSync(file,JSON.stringify(stash));
 return {site:s.id,stateHash:hash(fs.readFileSync(file)),arms};}
 try{const out=await Promise.all(sites.map(collect));const json=JSON.stringify(out,null,1);
 if(mode==='replay'&&get('capture.json')!==json)throw Error('Replay diverged');fs.writeFileSync(mode+'.json',json);console.log(mode, out.map(x=>[x.site,Object.keys(x.arms)]));}finally{await browser?.close();}}
main().catch(e=>{console.error(e);process.exitCode=1});
