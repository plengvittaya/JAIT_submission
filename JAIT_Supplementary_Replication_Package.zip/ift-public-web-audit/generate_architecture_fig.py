#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate 300 DPI System Architecture diagram (Fig. 1 in JAIT manuscript)."""

from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch


def draw_box(
    ax,
    x: float,
    y: float,
    w: float,
    h: float,
    title: str,
    lines: list[str],
    facecolor: str,
    edgecolor: str,
    header_bg: str,
    title_color: str = "#ffffff",
    linestyle: str = "-",
    body_fontsize: float = 7.3,
    linespacing: float = 1.32,
) -> None:
    """Draw a crisp rounded box with a colored header banner and centered body bullets."""
    pad = 0.009
    box = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle=f"round,pad={pad},rounding_size=0.016",
        facecolor=facecolor,
        edgecolor=edgecolor,
        linewidth=1.5,
        linestyle=linestyle,
        zorder=2,
    )
    ax.add_patch(box)

    hh = max(0.062, min(0.105, h * 0.29))
    header = FancyBboxPatch(
        (x, y + h - hh),
        w,
        hh,
        boxstyle=f"round,pad={pad},rounding_size=0.014",
        facecolor=header_bg,
        edgecolor=edgecolor,
        linewidth=1.2,
        linestyle=linestyle,
        zorder=3,
    )
    ax.add_patch(header)

    ax.text(
        x + w / 2.0,
        y + h - hh / 2.0,
        title,
        ha="center",
        va="center",
        fontsize=8.1,
        fontweight="bold",
        color=title_color,
        linespacing=1.15,
        zorder=4,
    )

    body_text = "\n".join(lines)
    body_y = y + (h - hh - pad) / 2.0
    ax.text(
        x + w / 2.0,
        body_y,
        body_text,
        ha="center",
        va="center",
        fontsize=body_fontsize,
        color="#1e293b",
        linespacing=linespacing,
        zorder=4,
    )


def draw_arrow(
    ax,
    x0: float,
    y0: float,
    x1: float,
    y1: float,
    rad: float = 0.0,
    linestyle: str = "-",
) -> None:
    """Draw a clean directional connector arrow."""
    ax.annotate(
        "",
        xy=(x1, y1),
        xytext=(x0, y0),
        arrowprops=dict(
            arrowstyle="-|>,head_length=0.52,head_width=0.30",
            color="#334155",
            lw=1.6,
            linestyle=linestyle,
            connectionstyle=f"arc3,rad={rad}",
        ),
        zorder=5,
    )


def generate_architecture_diagram(out_path: Path) -> None:
    plt.rcParams.update({"font.family": "DejaVu Sans"})
    fig, ax = plt.subplots(figsize=(12.8, 6.2), dpi=300)
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.axis("off")

    # Subtle stage column bands
    stage_specs = [
        (0.010, 0.220, "STAGE 1: CORPUS", "#f8fafc"),
        (0.244, 0.484, "STAGE 2: MULTI-STREAM EXECUTION", "#f8fafc"),
        (0.742, 0.248, "STAGE 3: AUDIT OUTPUTS", "#f8fafc"),
    ]
    for sx, sw, stitle, sbg in stage_specs:
        band = FancyBboxPatch(
            (sx, 0.03),
            sw,
            0.93,
            boxstyle="round,pad=0.008,rounding_size=0.02",
            facecolor=sbg,
            edgecolor="#cbd5e1",
            linewidth=1.0,
            linestyle="--",
            zorder=1,
        )
        ax.add_patch(band)
        ax.text(
            sx + sw / 2.0,
            0.928,
            stitle,
            ha="center",
            va="center",
            fontsize=8.2,
            fontweight="bold",
            color="#475569",
            zorder=2,
        )

    # Stage 1 box: Stratified Web Corpus
    draw_box(
        ax,
        0.024,
        0.19,
        0.192,
        0.58,
        "Stratified Web\nCorpus (N = 60)",
        [
            "Group A: Central Agencies",
            "(n = 30 ministries/depts)",
            "",
            "Group B: Local Portals",
            "(n = 30, balanced 10/10/10",
            "across 4 regions)",
            "",
            "Single-Day Snapshot:",
            "Nov 21, 2026 (Read-Only GET)",
        ],
        facecolor="#eff6ff",
        edgecolor="#2563eb",
        header_bg="#1d4ed8",
        body_fontsize=7.4,
        linespacing=1.35,
    )

    # Stage 2 Left Box: Live Headless Playwright Runner
    draw_box(
        ax,
        0.258,
        0.33,
        0.184,
        0.30,
        "Playwright 1.53.0\nLive Runner",
        [
            "Desktop Viewport 1366x768",
            "SPA Hydration (__next/__nuxt)",
            "Ceremonial Splash Bypass",
            "DOM & ATF Telemetry",
        ],
        facecolor="#ecfeff",
        edgecolor="#0891b2",
        header_bg="#0e7490",
        body_fontsize=7.3,
        linespacing=1.36,
    )

    # Stage 2 Top Branch: Deterministic IFT Forager
    draw_box(
        ax,
        0.486,
        0.65,
        0.222,
        0.23,
        "Deterministic\nIFT Forager",
        [
            "Programmatic AT Proxy",
            "Scent Eqs. (1)-(2) + P_clutter",
            "Bilingual Phrase Matcher",
            "Algorithm 1 (maxSteps = 5)",
            "180 Trajectories (T1-T3)",
        ],
        facecolor="#f0fdf4",
        edgecolor="#16a34a",
        header_bg="#15803d",
        body_fontsize=7.1,
        linespacing=1.26,
    )

    # Stage 2 Middle Branch: Static WCAG Baseline
    draw_box(
        ax,
        0.486,
        0.355,
        0.222,
        0.22,
        "Static WCAG 2.1\nAA Baseline",
        [
            "@axe-core/playwright Scan",
            "60/60 Identical Resolved DOMs",
            "Tags: wcag2a, 2aa, 21a, 21aa",
            "Node & Rule Violations",
        ],
        facecolor="#fff7ed",
        edgecolor="#ea580c",
        header_bg="#c2410c",
        body_fontsize=7.1,
        linespacing=1.28,
    )

    # Stage 2 Bottom Branch: CDP Accessibility Tree & Keyboard Tab Validation
    draw_box(
        ax,
        0.486,
        0.06,
        0.222,
        0.22,
        "CDP AXTree &\nKeyboard Tab",
        [
            "Accessibility.getFullAXTree",
            "60-Step Sequential Tab Walk",
            "Stratified n = 9 (27 Tasks)",
            "Same-Day Follow-Up Check",
        ],
        facecolor="#f0fdfa",
        edgecolor="#0f766e",
        header_bg="#115e59",
        linestyle="--",
        body_fontsize=7.1,
        linespacing=1.28,
    )

    # Stage 3 Box: Statistical & Concordance Audit
    draw_box(
        ax,
        0.755,
        0.10,
        0.222,
        0.76,
        "Statistical &\nConcordance Audit",
        [
            "RQ1a: Mann-Whitney + Holm",
            "(Central vs. Local Gaps)",
            "",
            "RQ1b: 3-Tier & 4-Region KW",
            "(CMS Template Inheritance)",
            "",
            "RQ2-3: Task Depth & Clutter",
            "(Fisher Exact + Spearman rho)",
            "",
            "RQ4: Partial Spearman (| DOM)",
            "AXTree & Tab-60 Concordance",
            "False Comfort / Alarm Tiers",
            "60-Site Remediation Matrix",
        ],
        facecolor="#f5f3ff",
        edgecolor="#7c3aed",
        header_bg="#6d28d9",
        body_fontsize=7.2,
        linespacing=1.29,
    )

    # Connectors
    draw_arrow(ax, 0.226, 0.48, 0.248, 0.48)
    draw_arrow(ax, 0.452, 0.55, 0.476, 0.76)
    draw_arrow(ax, 0.452, 0.465, 0.476, 0.465)
    draw_arrow(ax, 0.452, 0.38, 0.476, 0.17, linestyle="--")

    draw_arrow(ax, 0.718, 0.76, 0.745, 0.67)
    draw_arrow(ax, 0.718, 0.465, 0.745, 0.48)
    draw_arrow(ax, 0.718, 0.17, 0.745, 0.27, linestyle="--")

    # Parity & subset labels between Stage 2 branches
    ax.text(
        0.597,
        0.612,
        "Identical Post-Splash DOM State",
        ha="center",
        va="center",
        fontsize=7.2,
        style="italic",
        color="#475569",
        bbox=dict(boxstyle="round,pad=0.18", facecolor="#ffffff", edgecolor="#cbd5e1", lw=0.8),
        zorder=5,
    )
    ax.text(
        0.597,
        0.317,
        "Stratified Cross-Validation (9 Portals)",
        ha="center",
        va="center",
        fontsize=7.2,
        style="italic",
        color="#0f766e",
        bbox=dict(boxstyle="round,pad=0.18", facecolor="#ffffff", edgecolor="#99f6e4", lw=0.8),
        zorder=5,
    )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=300, bbox_inches="tight", pad_inches=0.06, facecolor="#ffffff")
    plt.close(fig)
    print(f"Saved {out_path} ({out_path.stat().st_size} bytes)")


if __name__ == "__main__":
    base_dir = Path(__file__).resolve().parent
    generate_architecture_diagram(base_dir / "paper_analysis_output" / "fig0_system_architecture.png")
