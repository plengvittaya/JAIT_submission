#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JAIT Statistical Analysis & Publication Visualization Pipeline
Computational Information Foraging and Visual Complexity Auditing of Public-Sector Websites
"""

import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import brentq
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def rank_biserial_effect_size(u_stat: float, n1: int, n2: int) -> float:
    """Compute rank-biserial correlation r_rb = (2*U)/(n1*n2) - 1."""
    if n1 == 0 or n2 == 0:
        return 0.0
    return float((2.0 * u_stat) / (n1 * n2) - 1.0)


def compute_cochran_q(matrix: np.ndarray) -> tuple[float, float]:
    """Compute Cochran's Q test statistic and chi-square p-value for binary repeated measures."""
    n, k = matrix.shape
    if n == 0 or k < 2:
        return 0.0, 1.0
    t_j = matrix.sum(axis=0)
    l_i = matrix.sum(axis=1)
    t_bar = t_j.mean()
    denom = k * l_i.sum() - (l_i ** 2).sum()
    if denom <= 0:
        return 0.0, 1.0
    q_stat = (k - 1) * (k * ((t_j - t_bar) ** 2).sum()) / denom
    p_val = float(1.0 - stats.chi2.cdf(q_stat, df=k - 1))
    return float(q_stat), p_val


def holm_bonferroni_adjust(p_values: list[float]) -> list[float]:
    """Apply Holm-Bonferroni step-down adjustment while enforcing monotonicity."""
    m = len(p_values)
    if m == 0:
        return []
    indexed = sorted(enumerate(p_values), key=lambda x: x[1])
    adj = [0.0] * m
    running_max = 0.0
    for rank, (orig_idx, p_val) in enumerate(indexed):
        candidate = min(1.0, p_val * (m - rank))
        running_max = max(running_max, candidate)
        adj[orig_idx] = running_max
    return adj


def main() -> None:
    base_dir = Path(__file__).resolve().parent
    dataset_path = base_dir / "ift_hci_results" / "ift_hci_master_dataset.json"
    out_dir = base_dir / "paper_analysis_output"
    out_dir.mkdir(parents=True, exist_ok=True)

    if not dataset_path.exists():
        raise FileNotFoundError(f"Master dataset not found at {dataset_path}")

    with open(dataset_path, "r", encoding="utf-8") as f:
        master = json.load(f)

    sites = master.get("sites", [])
    print(f"Loaded {len(sites)} audited sites from {dataset_path}")

    axe_path = base_dir / "ift_hci_results" / "axe_baseline_dataset.json"
    axe_map = {}
    if axe_path.exists():
        with open(axe_path, "r", encoding="utf-8") as fx:
            axe_data = json.load(fx)
        for ax_rec in axe_data.get("sites", []):
            axe_map[ax_rec["siteId"]] = ax_rec

    site_rows = []
    task_rows = []

    for s in sites:
        vc = s.get("visualComplexity", {})
        fs_sum = s.get("foragingSummary", {})
        tasks = s.get("tasks", {})

        t1 = tasks.get("T1_Contact", {})
        t2 = tasks.get("T2_ServiceForm", {})
        t3 = tasks.get("T3_Procurement_Plan", {})

        tcr_val = fs_sum.get("TCR", 0.0)
        splash_b = bool(s.get("hasSplashPage", False))
        ambig_val = vc.get("ambiguousLinkRatio", 0.0)
        atf_val = vc.get("aboveTheFoldLinks", 0)
        bt_val = fs_sum.get("backtrackRate", 0.0)
        if tcr_val == 0.0:
            sev_code = "Tier_1_Critical"
        elif tcr_val < 0.5:
            sev_code = "Tier_2_High"
        elif tcr_val < 0.9:
            sev_code = "Tier_3_Moderate"
        elif splash_b or ambig_val >= 0.15 or atf_val < 12 or atf_val > 60 or bt_val > 0:
            sev_code = "Tier_4_Minor"
        else:
            sev_code = "Tier_5_Benchmark"

        ax_rec = axe_map.get(s["siteId"], {})

        site_rows.append(
            {
                "siteId": s["siteId"],
                "siteName": s["siteName"],
                "group": s["group"],
                "region": s.get("region", ""),
                "localTier": s.get("localTier", ""),
                "province": s.get("province", ""),
                "resolvedUrl": s.get("resolvedUrl", ""),
                "reachable": s.get("reachable", True),
                "httpStatus": s.get("httpStatus", 200),
                "loadTimeMs": s.get("loadTimeMs", 0),
                "hasSplashPage": int(splash_b),
                "aboveTheFoldLinks": atf_val,
                "totalVisibleLinks": vc.get("totalVisibleLinks", 0),
                "linkDensityPer10kPx": vc.get("linkDensityPer10kPx", 0.0),
                "totalDomNodes": vc.get("totalDomNodes", 0),
                "textToDomRatio": vc.get("textToDomRatio", 0.0),
                "ambiguousLinkRatio": ambig_val,
                "TCR": tcr_val,
                "tasksCompletedCount": fs_sum.get("tasksCompletedCount", 0),
                "avgClickDepth": fs_sum.get("avgClickDepth", 0.0),
                "totalBacktrackCount": fs_sum.get("totalBacktrackCount", 0),
                "avgBacktrackCount": fs_sum.get("avgBacktrackCount", 0.0),
                "backtrackRate": bt_val,
                "totalLoopCount": fs_sum.get("totalLoopCount", 0),
                "avgScentScore": fs_sum.get("avgScentScore", 0.0),
                "severityTierCode": sev_code,
                "T1_Completed": int(bool(t1.get("taskCompleted", False))),
                "T2_Completed": int(bool(t2.get("taskCompleted", False))),
                "T3_Completed": int(bool(t3.get("taskCompleted", False))),
                "axeScanned": int(bool(ax_rec.get("axeScanned", False))),
                "axeViolationRuleCount": ax_rec.get("axeViolationRuleCount", 0),
                "axeViolationNodeCount": ax_rec.get("axeViolationNodeCount", 0),
                "axeCriticalSeriousNodeCount": ax_rec.get("axeCriticalSeriousNodeCount", 0),
                "axeLinkNameViolationNodes": ax_rec.get("axeLinkNameViolationNodes", 0),
                "axeImageAltViolationNodes": ax_rec.get("axeImageAltViolationNodes", 0),
                "axePassRuleCount": ax_rec.get("axePassRuleCount", 0),
            }
        )

        for tid, tdata in tasks.items():
            task_rows.append(
                {
                    "siteId": s["siteId"],
                    "siteName": s["siteName"],
                    "group": s["group"],
                    "region": s.get("region", ""),
                    "localTier": s.get("localTier", ""),
                    "province": s.get("province", ""),
                    "taskId": tid,
                    "difficulty": tdata.get("difficulty", ""),
                    "taskCompleted": int(bool(tdata.get("taskCompleted", False))),
                    "clickDepth": tdata.get("clickDepth", 0),
                    "totalSteps": tdata.get("totalSteps", 0),
                    "backtrackCount": tdata.get("backtrackCount", 0),
                    "backtrackRate": tdata.get("backtrackRate", 0.0),
                    "loopCount": tdata.get("loopCount", 0),
                    "avgScentScore": tdata.get("avgScentScore", 0.0),
                    "initialPatchMaxScent": tdata.get("initialPatchMaxScent", 0.0),
                    "completionTimeMs": tdata.get("completionTimeMs", 0),
                    "terminationReason": tdata.get("terminationReason", ""),
                }
            )

    df_sites = pd.DataFrame(site_rows)
    df_tasks = pd.DataFrame(task_rows)

    site_csv_path = out_dir / "site_level_metrics.csv"
    df_sites.to_csv(site_csv_path, index=False, encoding="utf-8-sig")
    df_tasks.to_csv(out_dir / "task_level_trajectories.csv", index=False, encoding="utf-8-sig")

    # 1. Group Summary Statistics + Mann-Whitney U Tests + Holm-Bonferroni on Primary RQ1
    confirmatory_rq1 = {"linkDensityPer10kPx", "ambiguousLinkRatio", "backtrackRate"}
    metrics_to_compare = [
        ("aboveTheFoldLinks", "Above-the-Fold Links (count)"),
        ("linkDensityPer10kPx", "Link Density (per 10k px^2)"),
        ("totalDomNodes", "Total DOM Nodes (count)"),
        ("textToDomRatio", "Text-to-DOM Ratio (chars/node)"),
        ("ambiguousLinkRatio", "Ambiguous Link Ratio"),
        ("hasSplashPage", "Splash Page Incidence"),
        ("TCR", "Task Completion Rate (TCR)"),
        ("avgClickDepth", "Average Click Depth"),
        ("avgBacktrackCount", "Backtrack Count per Task"),
        ("backtrackRate", "Backtrack Rate"),
        ("totalLoopCount", "Navigation Loop Count (per site)"),
        ("avgScentScore", "Information Scent Score"),
    ]

    df_a = df_sites[df_sites["group"] == "Group_A_Central"]
    df_b = df_sites[df_sites["group"] == "Group_B_Regional"]

    summary_rows = []
    mann_whitney_results = {}

    for col, label in metrics_to_compare:
        a_vals = df_a[col].dropna().astype(float).values
        b_vals = df_b[col].dropna().astype(float).values

        if len(a_vals) > 0 and len(b_vals) > 0:
            u_stat, p_val = stats.mannwhitneyu(a_vals, b_vals, alternative="two-sided")
            r_rb = rank_biserial_effect_size(u_stat, len(a_vals), len(b_vals))
        else:
            u_stat, p_val, r_rb = 0.0, 1.0, 0.0

        row = {
            "Metric": col,
            "Label": label,
            "Test_Role": "Confirmatory_RQ1" if col in confirmatory_rq1 else "Exploratory",
            "GroupA_N": len(a_vals),
            "GroupA_Mean": round(float(np.mean(a_vals)), 4) if len(a_vals) else 0.0,
            "GroupA_SD": round(float(np.std(a_vals, ddof=1)), 4) if len(a_vals) > 1 else 0.0,
            "GroupA_Median": round(float(np.median(a_vals)), 4) if len(a_vals) else 0.0,
            "GroupA_IQR": round(float(np.percentile(a_vals, 75) - np.percentile(a_vals, 25)), 4) if len(a_vals) else 0.0,
            "GroupB_N": len(b_vals),
            "GroupB_Mean": round(float(np.mean(b_vals)), 4) if len(b_vals) else 0.0,
            "GroupB_SD": round(float(np.std(b_vals, ddof=1)), 4) if len(b_vals) > 1 else 0.0,
            "GroupB_Median": round(float(np.median(b_vals)), 4) if len(b_vals) else 0.0,
            "GroupB_IQR": round(float(np.percentile(b_vals, 75) - np.percentile(b_vals, 25)), 4) if len(b_vals) else 0.0,
            "MannWhitney_U": round(float(u_stat), 4),
            "p_value": round(float(p_val), 6),
            "Holm_adj_p": None,
            "RankBiserial_r": round(float(r_rb), 4),
            "Significant_p05": bool(p_val < 0.05),
        }
        summary_rows.append(row)
        mann_whitney_results[col] = row

    # Holm-Bonferroni adjustment across the 3 pre-specified primary RQ1 metrics
    prim_indices = [i for i, r in enumerate(summary_rows) if r["Test_Role"] == "Confirmatory_RQ1"]
    prim_raw_p = [summary_rows[i]["p_value"] for i in prim_indices]
    prim_holm_p = holm_bonferroni_adjust(prim_raw_p)
    for idx, adj_p in zip(prim_indices, prim_holm_p):
        adj_rounded = round(float(adj_p), 6)
        summary_rows[idx]["Holm_adj_p"] = adj_rounded
        summary_rows[idx]["Significant_p05"] = bool(adj_rounded < 0.05)
        mann_whitney_results[summary_rows[idx]["Metric"]] = summary_rows[idx]

    df_summary = pd.DataFrame(summary_rows)
    summary_csv_path = out_dir / "group_summary_stats.csv"
    df_summary.to_csv(summary_csv_path, index=False, encoding="utf-8-sig")

    # 2. Per-Task Completion & Foraging Breakdown + Fisher's Exact + Cochran's Q
    task_breakdown_rows = []
    fisher_tests = {}
    task_col_map = {
        "T1_Contact": "T1_Completed",
        "T2_ServiceForm": "T2_Completed",
        "T3_Procurement_Plan": "T3_Completed",
    }

    for tid in ["T1_Contact", "T2_ServiceForm", "T3_Procurement_Plan"]:
        col_done = task_col_map[tid]
        a_pass = int(df_a[col_done].sum())
        a_fail = len(df_a) - a_pass
        b_pass = int(df_b[col_done].sum())
        b_fail = len(df_b) - b_pass
        odds, f_p = stats.fisher_exact([[a_pass, a_fail], [b_pass, b_fail]])
        fisher_tests[tid] = {
            "GroupA_Pass": a_pass,
            "GroupA_N": len(df_a),
            "GroupB_Pass": b_pass,
            "GroupB_N": len(df_b),
            "odds_ratio": round(float(odds), 4) if np.isfinite(odds) else None,
            "fisher_p": round(float(f_p), 6),
        }

        for grp in ["Group_A_Central", "Group_B_Regional", "All_Sites"]:
            sub = df_tasks[df_tasks["taskId"] == tid] if grp == "All_Sites" else df_tasks[(df_tasks["taskId"] == tid) & (df_tasks["group"] == grp)]
            if len(sub) == 0:
                continue
            task_breakdown_rows.append(
                {
                    "Task_ID": tid,
                    "Difficulty": sub["difficulty"].iloc[0],
                    "Group": grp,
                    "N_Trials": len(sub),
                    "Completed_Count": int(sub["taskCompleted"].sum()),
                    "TCR_Percent": round(float(sub["taskCompleted"].mean() * 100.0), 2),
                    "Mean_ClickDepth": round(float(sub["clickDepth"].mean()), 4),
                    "SD_ClickDepth": round(float(sub["clickDepth"].std(ddof=1)), 4) if len(sub) > 1 else 0.0,
                    "Mean_BacktrackCount": round(float(sub["backtrackCount"].mean()), 4),
                    "Mean_BacktrackRate": round(float(sub["backtrackRate"].mean()), 4),
                    "SD_BacktrackRate": round(float(sub["backtrackRate"].std(ddof=1)), 4) if len(sub) > 1 else 0.0,
                    "Mean_LoopCount": round(float(sub["loopCount"].mean()), 4),
                    "Mean_ScentScore": round(float(sub["avgScentScore"].mean()), 4),
                    "Mean_InitialMaxScent": round(float(sub["initialPatchMaxScent"].mean()), 4),
                    "Fisher_p_A_vs_B": round(float(f_p), 6),
                }
            )

    df_task_breakdown = pd.DataFrame(task_breakdown_rows)
    task_csv_path = out_dir / "task_completion_breakdown.csv"
    df_task_breakdown.to_csv(task_csv_path, index=False, encoding="utf-8-sig")

    q_all, p_q_all = compute_cochran_q(df_sites[["T1_Completed", "T2_Completed", "T3_Completed"]].values)
    q_a, p_q_a = compute_cochran_q(df_a[["T1_Completed", "T2_Completed", "T3_Completed"]].values)
    q_b, p_q_b = compute_cochran_q(df_b[["T1_Completed", "T2_Completed", "T3_Completed"]].values)
    cochran_q_tests = {
        "All_Sites": {"Q": round(q_all, 4), "df": 2, "p_value": round(p_q_all, 6)},
        "Group_A_Central": {"Q": round(q_a, 4), "df": 2, "p_value": round(p_q_a, 6)},
        "Group_B_Regional": {"Q": round(q_b, 4), "df": 2, "p_value": round(p_q_b, 6)},
    }

    # 3. Correlation Analysis (Spearman & Pearson)
    correlation_pairs = [
        ("linkDensityPer10kPx", "backtrackRate", "Link Density vs. Backtrack Rate"),
        ("aboveTheFoldLinks", "backtrackRate", "Above-the-Fold Links vs. Backtrack Rate"),
        ("ambiguousLinkRatio", "backtrackRate", "Ambiguous Link Ratio vs. Backtrack Rate"),
        ("avgScentScore", "TCR", "Information Scent Score vs. Task Completion Rate"),
        ("avgScentScore", "backtrackRate", "Information Scent Score vs. Backtrack Rate"),
        ("linkDensityPer10kPx", "avgClickDepth", "Link Density vs. Average Click Depth"),
        ("totalDomNodes", "loadTimeMs", "Total DOM Nodes vs. Page Load Time (ms)"),
    ]

    correlations = {}
    for x_col, y_col, desc in correlation_pairs:
        x = df_sites[x_col].astype(float).values
        y = df_sites[y_col].astype(float).values
        if np.std(x) > 0 and np.std(y) > 0:
            r_p, p_p = stats.pearsonr(x, y)
            r_s, p_s = stats.spearmanr(x, y)
        else:
            r_p, p_p, r_s, p_s = 0.0, 1.0, 0.0, 1.0
        correlations[f"{x_col}_vs_{y_col}"] = {
            "description": desc,
            "x": x_col,
            "y": y_col,
            "pearson_r": round(float(r_p), 4),
            "pearson_p": round(float(p_p), 6),
            "spearman_rho": round(float(r_s), 4),
            "spearman_p": round(float(p_s), 6),
        }

    # 4. 10,000-Resample Bootstrap 95% Confidence Intervals
    rng_boot = np.random.default_rng(42)
    a_amb_arr = df_a["ambiguousLinkRatio"].astype(float).values
    b_amb_arr = df_b["ambiguousLinkRatio"].astype(float).values
    amb_diffs = [
        float(np.mean(rng_boot.choice(b_amb_arr, len(b_amb_arr), replace=True)) - np.mean(rng_boot.choice(a_amb_arr, len(a_amb_arr), replace=True)))
        for _ in range(10000)
    ]
    amb_ci = np.percentile(amb_diffs, [2.5, 97.5])

    dens_arr = df_sites["linkDensityPer10kPx"].astype(float).values
    bt_arr = df_sites["backtrackRate"].astype(float).values
    boot_rhos = []
    for _ in range(10000):
        idx = rng_boot.integers(0, len(dens_arr), len(dens_arr))
        rho_val, _ = stats.spearmanr(dens_arr[idx], bt_arr[idx])
        if not np.isnan(rho_val):
            boot_rhos.append(float(rho_val))
    rho_ci = np.percentile(boot_rhos, [2.5, 97.5])

    bootstrap_cis = {
        "n_resamples": 10000,
        "seed": 42,
        "ambiguousLinkRatio_diff_B_minus_A": {
            "point_estimate": round(float(np.mean(b_amb_arr) - np.mean(a_amb_arr)), 4),
            "ci_95_low": round(float(amb_ci[0]), 4),
            "ci_95_high": round(float(amb_ci[1]), 4),
        },
        "linkDensityPer10kPx_vs_backtrackRate_spearman_rho": {
            "point_estimate": correlations["linkDensityPer10kPx_vs_backtrackRate"]["spearman_rho"],
            "ci_95_low": round(float(rho_ci[0]), 4),
            "ci_95_high": round(float(rho_ci[1]), 4),
        },
    }

    # 5. Scent Formula Weight Sensitivity Analysis
    schemes = {
        "Baseline (0.58/0.18/0.16)": (0.58, 0.18, 0.16, 0.08),
        "Equal (0.34/0.33/0.33)": (0.34, 0.33, 0.33, 0.00),
        "Salience-Boosted (0.45/0.15/0.32)": (0.45, 0.15, 0.32, 0.08),
        "Lexical-Heavy (0.70/0.15/0.10)": (0.70, 0.15, 0.10, 0.05),
    }
    site_scores = {k: [] for k in schemes}
    for s in sites:
        for sname, (wl, wu, ws, b) in schemes.items():
            vals = []
            for t in s.get("tasks", {}).values():
                for log in t.get("decisionLogs", []):
                    c = log.get("scentComponents", {})
                    raw = (
                        wl * c.get("lexicalScent", 0.0)
                        + wu * c.get("urlScent", 0.0)
                        + ws * c.get("salienceBonus", 0.0)
                        + b
                        - c.get("clutterPenalty", 0.0)
                    )
                    vals.append(max(0.02, min(0.99, raw)))
            site_scores[sname].append(float(np.mean(vals)) if vals else 0.0)

    baseline_scores = site_scores["Baseline (0.58/0.18/0.16)"]
    sensitivity_rows = []
    for sname, vals in site_scores.items():
        rho, p_rho = stats.spearmanr(baseline_scores, vals)
        r_p, p_r = stats.pearsonr(baseline_scores, vals)
        sensitivity_rows.append(
            {
                "Scheme": sname,
                "Mean_Site_Scent": round(float(np.mean(vals)), 4),
                "SD_Site_Scent": round(float(np.std(vals, ddof=1)), 4),
                "Spearman_rho_vs_Baseline": round(float(rho), 4),
                "Spearman_p": round(float(p_rho), 6),
                "Pearson_r_vs_Baseline": round(float(r_p), 4),
                "Pearson_p": round(float(p_r), 6),
            }
        )
    df_sens = pd.DataFrame(sensitivity_rows)
    df_sens.to_csv(out_dir / "sensitivity_analysis.csv", index=False, encoding="utf-8-sig")

    # 6. Failure Mode Audit & Completion Precision Audit across all trajectories
    borderline_reasons = {
        ("A04", "T3_Procurement_Plan"): "Tax collection press release matched budget-year keywords rather than expenditure/procurement plan",
        ("A30", "T3_Procurement_Plan"): "Executive meeting news release matched planning tokens rather than a procurement notice or plan",
        ("B06", "T2_ServiceForm"): "Homepage section fragment link (Home#oss) rather than dedicated e-Service destination page",
        ("B19", "T3_Procurement_Plan"): "General PR news archive (pr-all/) matched generic announcement token rather than procurement/plan section",
        ("B29", "T3_Procurement_Plan"): "Archived FY 2563 ITA index page rather than current procurement or development plan",
    }
    failure_modes = {
        "Double_Splash_or_Patch_Exhausted": [],
        "Navigation_or_JS_Redirect_Loops": [],
        "Low_Scent_or_Buried_Menu_Exhaustion": [],
    }
    total_failed = 0
    total_completed = 0
    duplicate_final_url_sites = 0
    borderline_completions = []

    for s in sites:
        completed_hrefs = []
        for tid, t in s.get("tasks", {}).items():
            if t.get("taskCompleted", False):
                total_completed += 1
                last_log = t.get("decisionLogs", [{}])[-1]
                href = last_log.get("selectedHref", "")
                completed_hrefs.append(href)
                b_key = (s["siteId"], tid)
                if b_key in borderline_reasons:
                    borderline_completions.append(
                        {
                            "trajectory": f"{s['siteId']}:{tid}",
                            "selectedText": last_log.get("selectedText", ""),
                            "selectedHref": href,
                            "reason": borderline_reasons[b_key],
                        }
                    )
            else:
                total_failed += 1
                entry = f"{s['siteId']}:{tid}"
                actions = [l.get("action") for l in t.get("decisionLogs", [])]
                if "PATCH_EXHAUSTED" in actions or (s.get("hasSplashPage") and s.get("visualComplexity", {}).get("aboveTheFoldLinks", 0) <= 3):
                    failure_modes["Double_Splash_or_Patch_Exhausted"].append(entry)
                elif t.get("loopCount", 0) >= 2:
                    failure_modes["Navigation_or_JS_Redirect_Loops"].append(entry)
                else:
                    failure_modes["Low_Scent_or_Buried_Menu_Exhaustion"].append(entry)
        if len(completed_hrefs) != len(set(completed_hrefs)):
            duplicate_final_url_sites += 1

    # Pair the three tasks within each portal. Recode file selections, retaining all attempts.
    page_only = df_sites.set_index("siteId")[list(task_col_map.values())].copy()
    file_cases = []
    for site in sites:
        for task_id, task in site["tasks"].items():
            if task["taskCompleted"]:
                terminal = task["decisionLogs"][-1]
                if terminal["action"] != "GOAL_REACHED":
                    raise ValueError(f"Missing terminal goal record: {site['siteId']} {task_id}")
                if "Direct official document link reached (" in terminal["reasoning"]:
                    page_only.loc[site["siteId"], task_col_map[task_id]] = 0
                    file_cases.append(f"{site['siteId']}:{task_id}")
    page_q, page_p = compute_cochran_q(page_only.to_numpy())
    page_evidence_audit = {
        "perTask": {
            task_id: {"attempts": len(page_only), "original": int(df_sites[col].sum()),
                      "pageEvidence": int(page_only[col].sum())}
            for task_id, col in task_col_map.items()
        },
        "recodedFileSelections": file_cases,
        "cochranQ": page_q,
        "cochranP": page_p,
    }

    # Strict-mode T2/T3 completion excluding borderline matches
    df_strict = df_sites.copy()
    for bitem in borderline_completions:
        sid_b, tid_b = bitem["trajectory"].split(":")
        col_b = task_col_map[tid_b]
        df_strict.loc[df_strict["siteId"] == sid_b, col_b] = 0

    exact_matches = total_completed - len(borderline_completions)
    completion_precision_audit = {
        "totalCompletedTrajectories": total_completed,
        "exactTargetMatches": exact_matches,
        "precisionPercent": round(100.0 * exact_matches / max(1, total_completed), 2),
        "duplicateFinalUrlSites": duplicate_final_url_sites,
        "borderlineCount": len(borderline_completions),
        "borderlineCases": borderline_completions,
        "strictModeT2RatesPercent": {
            "Group_A_Central": round(float(df_strict[df_strict["group"] == "Group_A_Central"]["T2_Completed"].mean() * 100.0), 2),
            "Group_B_Regional": round(float(df_strict[df_strict["group"] == "Group_B_Regional"]["T2_Completed"].mean() * 100.0), 2),
            "All_Sites": round(float(df_strict["T2_Completed"].mean() * 100.0), 2),
        },
        "strictModeT3RatesPercent": {
            "Group_A_Central": round(float(df_strict[df_strict["group"] == "Group_A_Central"]["T3_Completed"].mean() * 100.0), 2),
            "Group_B_Regional": round(float(df_strict[df_strict["group"] == "Group_B_Regional"]["T3_Completed"].mean() * 100.0), 2),
            "All_Sites": round(float(df_strict["T3_Completed"].mean() * 100.0), 2),
        },
    }

    failure_summary = {
        "totalFailedTrajectories": total_failed,
        "totalTrajectories": len(df_tasks),
        "categories": {
            k: {
                "count": len(v),
                "percent_of_failed": round(100.0 * len(v) / max(1, total_failed), 2),
                "trajectories": v,
            }
            for k, v in failure_modes.items()
        },
    }

    # 6B. RQ1b: Within-Local 3-Tier Kruskal-Wallis H Tests (Large City/PAO vs Medium Town vs Small Subdistrict)
    local_tiers = ["Large_City_PAO", "Medium_Town", "Small_Subdistrict"]
    df_local = df_sites[df_sites["group"] == "Group_B_Regional"].copy()
    kw_metrics = [
        ("ambiguousLinkRatio", "Ambiguous Link Ratio"),
        ("linkDensityPer10kPx", "Link Density (per 10k px^2)"),
        ("backtrackRate", "Backtrack Rate"),
        ("TCR", "Task Completion Rate (TCR)"),
        ("avgScentScore", "Information Scent Score"),
        ("totalVisibleLinks", "Total Visible Links"),
        ("totalDomNodes", "Total DOM Nodes"),
        ("avgClickDepth", "Average Click Depth"),
        ("hasSplashPage", "Splash Page Incidence"),
    ]
    kw_rows = []
    kw_results = {}
    for col, label in kw_metrics:
        tier_arrays = [df_local[df_local["localTier"] == t][col].dropna().astype(float).values for t in local_tiers]
        non_empty = [arr for arr in tier_arrays if len(arr) > 0]
        if len(non_empty) == 3 and all(np.std(arr) == 0 for arr in non_empty) and len({arr[0] for arr in non_empty}) == 1:
            h_stat, kw_p = 0.0, 1.0
        elif len(non_empty) >= 2:
            h_stat, kw_p = stats.kruskal(*non_empty)
        else:
            h_stat, kw_p = 0.0, 1.0
        n_loc = sum(len(arr) for arr in non_empty)
        k_grp = len(non_empty)
        eps_sq = max(0.0, float((h_stat - k_grp + 1) / max(1, n_loc - k_grp)))

        row = {
            "Metric": col,
            "Label": label,
            "Test_Role": "Confirmatory_RQ1b" if col in confirmatory_rq1 else "Exploratory",
            "Large_City_PAO_N": len(tier_arrays[0]),
            "Large_City_PAO_Mean": round(float(np.mean(tier_arrays[0])), 4) if len(tier_arrays[0]) else 0.0,
            "Large_City_PAO_SD": round(float(np.std(tier_arrays[0], ddof=1)), 4) if len(tier_arrays[0]) > 1 else 0.0,
            "Large_City_PAO_Median": round(float(np.median(tier_arrays[0])), 4) if len(tier_arrays[0]) else 0.0,
            "Large_City_PAO_IQR": round(float(np.percentile(tier_arrays[0], 75) - np.percentile(tier_arrays[0], 25)), 4) if len(tier_arrays[0]) else 0.0,
            "Medium_Town_N": len(tier_arrays[1]),
            "Medium_Town_Mean": round(float(np.mean(tier_arrays[1])), 4) if len(tier_arrays[1]) else 0.0,
            "Medium_Town_SD": round(float(np.std(tier_arrays[1], ddof=1)), 4) if len(tier_arrays[1]) > 1 else 0.0,
            "Medium_Town_Median": round(float(np.median(tier_arrays[1])), 4) if len(tier_arrays[1]) else 0.0,
            "Medium_Town_IQR": round(float(np.percentile(tier_arrays[1], 75) - np.percentile(tier_arrays[1], 25)), 4) if len(tier_arrays[1]) else 0.0,
            "Small_Subdistrict_N": len(tier_arrays[2]),
            "Small_Subdistrict_Mean": round(float(np.mean(tier_arrays[2])), 4) if len(tier_arrays[2]) else 0.0,
            "Small_Subdistrict_SD": round(float(np.std(tier_arrays[2], ddof=1)), 4) if len(tier_arrays[2]) > 1 else 0.0,
            "Small_Subdistrict_Median": round(float(np.median(tier_arrays[2])), 4) if len(tier_arrays[2]) else 0.0,
            "Small_Subdistrict_IQR": round(float(np.percentile(tier_arrays[2], 75) - np.percentile(tier_arrays[2], 25)), 4) if len(tier_arrays[2]) else 0.0,
            "KruskalWallis_H": round(float(h_stat), 4),
            "p_value": round(float(kw_p), 6),
            "Holm_adj_p": None,
            "Epsilon_sq": round(eps_sq, 4),
            "Significant_p05": bool(kw_p < 0.05),
            "PostHoc_Pairwise": {},
        }
        if kw_p < 0.10 and len(non_empty) == 3:
            pairs = [("Large_City_PAO", 0, "Medium_Town", 1), ("Large_City_PAO", 0, "Small_Subdistrict", 2), ("Medium_Town", 1, "Small_Subdistrict", 2)]
            raw_pair_p = []
            pair_stats = []
            for n1, i1, n2, i2 in pairs:
                u_ph, p_ph = stats.mannwhitneyu(tier_arrays[i1], tier_arrays[i2], alternative="two-sided")
                r_ph = rank_biserial_effect_size(u_ph, len(tier_arrays[i1]), len(tier_arrays[i2]))
                raw_pair_p.append(float(p_ph))
                pair_stats.append((f"{n1}_vs_{n2}", float(u_ph), float(p_ph), float(r_ph)))
            adj_pair_p = holm_bonferroni_adjust(raw_pair_p)
            for (pname, u_ph, p_ph, r_ph), p_adj_ph in zip(pair_stats, adj_pair_p):
                row["PostHoc_Pairwise"][pname] = {
                    "MannWhitney_U": round(u_ph, 4),
                    "p_raw": round(p_ph, 6),
                    "Holm_adj_p": round(p_adj_ph, 6),
                    "RankBiserial_r": round(r_ph, 4),
                }
        kw_rows.append(row)
        kw_results[col] = row

    kw_conf_idx = [i for i, r in enumerate(kw_rows) if r["Test_Role"] == "Confirmatory_RQ1b"]
    kw_holm_p = holm_bonferroni_adjust([kw_rows[i]["p_value"] for i in kw_conf_idx])
    for idx, adj_p in zip(kw_conf_idx, kw_holm_p):
        adj_r = round(float(adj_p), 6)
        kw_rows[idx]["Holm_adj_p"] = adj_r
        kw_rows[idx]["Significant_p05"] = bool(adj_r < 0.05)
        kw_results[kw_rows[idx]["Metric"]] = kw_rows[idx]

    df_kw = pd.DataFrame([{k: v for k, v in r.items() if k != "PostHoc_Pairwise"} for r in kw_rows])
    df_kw.to_csv(out_dir / "local_tier_summary_stats.csv", index=False, encoding="utf-8-sig")

    regional_summary = {}
    for reg_name in ["North", "Northeast", "Central_East", "South"]:
        sub_r = df_local[df_local["region"] == reg_name]
        if len(sub_r) > 0:
            regional_summary[reg_name] = {
                "n": int(len(sub_r)),
                "mean_AmbiguousLinkRatio": round(float(sub_r["ambiguousLinkRatio"].mean()), 4),
                "mean_LinkDensity": round(float(sub_r["linkDensityPer10kPx"].mean()), 4),
                "mean_BacktrackRate": round(float(sub_r["backtrackRate"].mean()), 4),
                "mean_TCR": round(float(sub_r["TCR"].mean()), 4),
                "mean_AvgScentScore": round(float(sub_r["avgScentScore"].mean()), 4),
                "mean_axeViolationNodes": round(float(sub_r["axeViolationNodeCount"].mean()), 2),
            }

    # Within-North Stratification Check (n=10 Northern portals: 4 Large_City_PAO, 2 Medium_Town, 4 Small_Subdistrict)
    df_north = df_local[df_local["region"] == "North"]
    within_north_tiers = {}
    for t in local_tiers:
        sub_nt = df_north[df_north["localTier"] == t]
        within_north_tiers[t] = {
            "n": int(len(sub_nt)),
            "mean_AmbiguousLinkRatio": round(float(sub_nt["ambiguousLinkRatio"].mean()), 4) if len(sub_nt) else 0.0,
            "mean_LinkDensity": round(float(sub_nt["linkDensityPer10kPx"].mean()), 4) if len(sub_nt) else 0.0,
            "mean_TotalDomNodes": round(float(sub_nt["totalDomNodes"].mean()), 1) if len(sub_nt) else 0.0,
            "mean_TCR": round(float(sub_nt["TCR"].mean()), 4) if len(sub_nt) else 0.0,
            "mean_BacktrackRate": round(float(sub_nt["backtrackRate"].mean()), 4) if len(sub_nt) else 0.0,
            "mean_axeViolationNodes": round(float(sub_nt["axeViolationNodeCount"].mean()), 2) if len(sub_nt) else 0.0,
        }
    regional_summary["Within_North_By_Tier"] = within_north_tiers

    # 6C. Outlier & Zero-Link Sensitivity Checks
    df_no_b25 = df_sites[df_sites["siteId"] != "B25"]
    u_nb25, p_nb25 = stats.mannwhitneyu(
        df_no_b25[df_no_b25["group"] == "Group_A_Central"]["ambiguousLinkRatio"].values,
        df_no_b25[df_no_b25["group"] == "Group_B_Regional"]["ambiguousLinkRatio"].values,
        alternative="two-sided",
    )
    r_nb25 = rank_biserial_effect_size(
        u_nb25,
        int((df_no_b25["group"] == "Group_A_Central").sum()),
        int((df_no_b25["group"] == "Group_B_Regional").sum()),
    )
    df_local_nb25 = df_local[df_local["siteId"] != "B25"]
    kw_nb25_arr = [df_local_nb25[df_local_nb25["localTier"] == t]["ambiguousLinkRatio"].values for t in local_tiers]
    h_nb25, p_kw_nb25 = stats.kruskal(*kw_nb25_arr)
    eps_nb25 = max(0.0, float((h_nb25 - 3 + 1) / (len(df_local_nb25) - 3)))

    df_no_a09 = df_sites[df_sites["siteId"] != "A09"]
    rho_na09, p_rho_na09 = stats.spearmanr(df_no_a09["linkDensityPer10kPx"], df_no_a09["backtrackRate"])
    r_na09, p_r_na09 = stats.pearsonr(df_no_a09["linkDensityPer10kPx"], df_no_a09["backtrackRate"])

    df_nonzero = df_sites[df_sites["totalVisibleLinks"] > 0]
    rho_nz, p_rho_nz = stats.spearmanr(df_nonzero["linkDensityPer10kPx"], df_nonzero["backtrackRate"])
    r_nz, p_r_nz = stats.pearsonr(df_nonzero["linkDensityPer10kPx"], df_nonzero["backtrackRate"])
    u_tcr_nz, p_tcr_nz = stats.mannwhitneyu(
        df_nonzero[df_nonzero["group"] == "Group_A_Central"]["TCR"].values,
        df_nonzero[df_nonzero["group"] == "Group_B_Regional"]["TCR"].values,
        alternative="two-sided",
    )
    u_bt_nz, p_bt_nz = stats.mannwhitneyu(
        df_nonzero[df_nonzero["group"] == "Group_A_Central"]["backtrackRate"].values,
        df_nonzero[df_nonzero["group"] == "Group_B_Regional"]["backtrackRate"].values,
        alternative="two-sided",
    )

    outlier_sensitivity = {
        "exclude_B25_100pct_ambig": {
            "N_remaining": int(len(df_no_b25)),
            "groupB_mean_ambig": round(float(df_local_nb25["ambiguousLinkRatio"].mean()), 4),
            "mediumTown_mean_ambig": round(float(df_local_nb25[df_local_nb25["localTier"] == "Medium_Town"]["ambiguousLinkRatio"].mean()), 4),
            "MannWhitney_U_A_vs_B": round(float(u_nb25), 4),
            "p_value_A_vs_B": round(float(p_nb25), 6),
            "RankBiserial_r": round(float(r_nb25), 4),
            "KruskalWallis_H_localTiers": round(float(h_nb25), 4),
            "p_value_localTiers": round(float(p_kw_nb25), 6),
            "Epsilon_sq_localTiers": round(eps_nb25, 4),
        },
        "exclude_A09_leverage": {
            "N_remaining": int(len(df_no_a09)),
            "spearman_rho": round(float(rho_na09), 4),
            "spearman_p": round(float(p_rho_na09), 6),
            "pearson_r": round(float(r_na09), 4),
            "pearson_p": round(float(p_r_na09), 6),
        },
        "exclude_zero_link_shells": {
            "excluded_ids": list(df_sites[df_sites["totalVisibleLinks"] == 0]["siteId"]),
            "N_remaining": int(len(df_nonzero)),
            "spearman_rho_density_vs_bt": round(float(rho_nz), 4),
            "spearman_p_density_vs_bt": round(float(p_rho_nz), 6),
            "pearson_r_density_vs_bt": round(float(r_nz), 4),
            "pearson_p_density_vs_bt": round(float(p_r_nz), 6),
            "TCR_MannWhitney_U": round(float(u_tcr_nz), 4),
            "TCR_p_value": round(float(p_tcr_nz), 6),
            "backtrackRate_MannWhitney_U": round(float(u_bt_nz), 4),
            "backtrackRate_p_value": round(float(p_bt_nz), 6),
        },
    }

    # 6D. RQ4: Static axe-core Baseline vs. Behavioral Information Foraging Validation
    df_ax = df_sites[df_sites["axeScanned"] == 1].copy()
    axe_metrics_list = [
        ("axeViolationNodeCount", "Total WCAG Violation Nodes"),
        ("axeViolationRuleCount", "Violated WCAG Rule Types"),
        ("axeCriticalSeriousNodeCount", "Critical + Serious Violation Nodes"),
        ("axeLinkNameViolationNodes", "link-name Violation Nodes"),
        ("axeImageAltViolationNodes", "image-alt Violation Nodes"),
    ]
    axe_group_rows = []
    axe_group_dict = {}
    for col, label in axe_metrics_list:
        ax_a = df_ax[df_ax["group"] == "Group_A_Central"][col].astype(float).values
        ax_b = df_ax[df_ax["group"] == "Group_B_Regional"][col].astype(float).values
        u_ax, p_ax = stats.mannwhitneyu(ax_a, ax_b, alternative="two-sided") if len(ax_a) and len(ax_b) else (0.0, 1.0)
        r_ax = rank_biserial_effect_size(u_ax, len(ax_a), len(ax_b))
        ax_loc_arr = [df_ax[df_ax["localTier"] == t][col].astype(float).values for t in local_tiers]
        h_ax, p_kw_ax = stats.kruskal(*ax_loc_arr) if all(len(a) > 0 for a in ax_loc_arr) else (0.0, 1.0)
        eps_ax = max(0.0, float((h_ax - 3 + 1) / max(1, sum(len(a) for a in ax_loc_arr) - 3)))
        rec_ax = {
            "Metric": col,
            "Label": label,
            "All_Mean": round(float(df_ax[col].mean()), 2) if len(df_ax) else 0.0,
            "All_Median": round(float(df_ax[col].median()), 2) if len(df_ax) else 0.0,
            "GroupA_Mean": round(float(np.mean(ax_a)), 2) if len(ax_a) else 0.0,
            "GroupA_Median": round(float(np.median(ax_a)), 2) if len(ax_a) else 0.0,
            "GroupB_Mean": round(float(np.mean(ax_b)), 2) if len(ax_b) else 0.0,
            "GroupB_Median": round(float(np.median(ax_b)), 2) if len(ax_b) else 0.0,
            "MannWhitney_U": round(float(u_ax), 4),
            "p_value_A_vs_B": round(float(p_ax), 6),
            "RankBiserial_r": round(float(r_ax), 4),
            "Large_City_PAO_Mean": round(float(np.mean(ax_loc_arr[0])), 2) if len(ax_loc_arr[0]) else 0.0,
            "Medium_Town_Mean": round(float(np.mean(ax_loc_arr[1])), 2) if len(ax_loc_arr[1]) else 0.0,
            "Small_Subdistrict_Mean": round(float(np.mean(ax_loc_arr[2])), 2) if len(ax_loc_arr[2]) else 0.0,
            "LocalTier_KW_H": round(float(h_ax), 4),
            "LocalTier_KW_p": round(float(p_kw_ax), 6),
            "LocalTier_Epsilon_sq": round(eps_ax, 4),
        }
        axe_group_rows.append(rec_ax)
        axe_group_dict[col] = rec_ax

    df_axe_summary = pd.DataFrame(axe_group_rows)
    df_axe_summary.to_csv(out_dir / "axe_vs_foraging_summary.csv", index=False, encoding="utf-8-sig")

    axe_corrs = {}
    for ax_x in ["axeViolationNodeCount", "axeCriticalSeriousNodeCount"]:
        for bh_y in ["TCR", "backtrackRate", "avgClickDepth", "ambiguousLinkRatio"]:
            xv = df_ax[ax_x].astype(float).values
            yv = df_ax[bh_y].astype(float).values
            rp, pp = stats.pearsonr(xv, yv) if np.std(xv) > 0 and np.std(yv) > 0 else (0.0, 1.0)
            rs, ps = stats.spearmanr(xv, yv) if np.std(xv) > 0 and np.std(yv) > 0 else (0.0, 1.0)
            axe_corrs[f"{ax_x}_vs_{bh_y}"] = {
                "pearson_r": round(float(rp), 4),
                "pearson_p": round(float(pp), 6),
                "spearman_rho": round(float(rs), 4),
                "spearman_p": round(float(ps), 6),
            }

    false_comfort_df = df_ax[(df_ax["axeViolationNodeCount"] <= 10) & (df_ax["TCR"] == 0.0)]
    false_comfort_low_df = df_ax[(df_ax["axeViolationNodeCount"] <= 10) & (df_ax["TCR"] < 0.5)]
    false_alarm_df = df_ax[(df_ax["axeViolationNodeCount"] >= 50) & (df_ax["TCR"] >= 0.99)]

    tier_codes_order = ["Tier_1_Critical", "Tier_2_High", "Tier_3_Moderate", "Tier_4_Minor", "Tier_5_Benchmark"]
    axe_by_severity = {}
    sev_arrays = []
    for tc in tier_codes_order:
        sub_s = df_ax[df_ax["severityTierCode"] == tc]["axeViolationNodeCount"].astype(float).values
        sev_arrays.append(sub_s)
        axe_by_severity[tc] = {
            "n": int(len(sub_s)),
            "mean_axeNodes": round(float(np.mean(sub_s)), 2) if len(sub_s) else 0.0,
            "median_axeNodes": round(float(np.median(sub_s)), 2) if len(sub_s) else 0.0,
            "min_axeNodes": int(np.min(sub_s)) if len(sub_s) else 0,
            "max_axeNodes": int(np.max(sub_s)) if len(sub_s) else 0,
        }
    non_empty_sev = [arr for arr in sev_arrays if len(arr) > 0]
    h_sev, p_sev = stats.kruskal(*non_empty_sev) if len(non_empty_sev) >= 2 else (0.0, 1.0)

    # 6E. DOM-Size Confounding & Normalized Violation Density Check (N = 60)
    df_ax["axeViolationDensity"] = df_ax["axeViolationNodeCount"].astype(float) / (
        df_ax["totalDomNodes"].astype(float).clip(lower=1.0) / 1000.0
    )
    rho_ax_dom, p_ax_dom = stats.spearmanr(df_ax["axeViolationNodeCount"].astype(float), df_ax["totalDomNodes"].astype(float))
    rho_dom_tcr, p_dom_tcr = stats.spearmanr(df_ax["totalDomNodes"].astype(float), df_ax["TCR"].astype(float))
    rho_dens_tcr, p_dens_tcr = stats.spearmanr(df_ax["axeViolationDensity"].astype(float), df_ax["TCR"].astype(float))

    rx = stats.rankdata(df_ax["axeViolationNodeCount"].astype(float).values)
    ry = stats.rankdata(df_ax["TCR"].astype(float).values)
    rz = stats.rankdata(df_ax["totalDomNodes"].astype(float).values)
    sx, ix, _, _, _ = stats.linregress(rz, rx)
    sy, iy, _, _, _ = stats.linregress(rz, ry)
    r_part, _ = stats.pearsonr(rx - (sx * rz + ix), ry - (sy * rz + iy))
    df_part = max(1, len(df_ax) - 3)
    t_part = r_part * math.sqrt(df_part / max(1e-12, 1.0 - r_part ** 2))
    p_part = float(2.0 * stats.t.sf(abs(t_part), df_part))

    dens_a = df_ax[df_ax["group"] == "Group_A_Central"]["axeViolationDensity"].astype(float).values
    dens_b = df_ax[df_ax["group"] == "Group_B_Regional"]["axeViolationDensity"].astype(float).values
    u_dens, p_dens_mw = stats.mannwhitneyu(dens_a, dens_b, alternative="two-sided")
    r_dens_mw = rank_biserial_effect_size(u_dens, len(dens_a), len(dens_b))

    dom_confounding = {
        "spearman_axe_vs_dom": {"rho": round(float(rho_ax_dom), 4), "p_value": round(float(p_ax_dom), 6)},
        "spearman_dom_vs_tcr": {"rho": round(float(rho_dom_tcr), 4), "p_value": round(float(p_dom_tcr), 6)},
        "spearman_axeDensityPer1kDom_vs_tcr": {"rho": round(float(rho_dens_tcr), 4), "p_value": round(float(p_dens_tcr), 6)},
        "partialSpearman_axe_vs_tcr_given_dom": {
            "rho_partial": round(float(r_part), 4),
            "t_stat": round(float(t_part), 4),
            "df": int(df_part),
            "p_value": round(float(p_part), 6),
        },
        "axeViolationDensityPer1kDom_GroupA_vs_GroupB": {
            "GroupA_Mean": round(float(np.mean(dens_a)), 2),
            "GroupA_Median": round(float(np.median(dens_a)), 2),
            "GroupB_Mean": round(float(np.mean(dens_b)), 2),
            "GroupB_Median": round(float(np.median(dens_b)), 2),
            "MannWhitney_U": round(float(u_dens), 1),
            "p_value": round(float(p_dens_mw), 6),
            "RankBiserial_r": round(float(r_dens_mw), 4),
        },
    }

    # 6F. Four-Region Kruskal-Wallis across Group B Local Governments (n = 30)
    reg_order = ["North", "Northeast", "Central_East", "South"]
    reg_metrics = [
        ("axeViolationNodeCount", "Static WCAG Violation Nodes", True),
        ("linkDensityPer10kPx", "Above-the-Fold Link Density (/10k px^2)", True),
        ("totalDomNodes", "Total DOM Nodes", True),
        ("ambiguousLinkRatio", "Ambiguous Link Ratio", True),
        ("TCR", "Task Completion Rate (TCR)", False),
    ]
    reg_raw_p_idx = []
    reg_kw_dict = {}
    for col, lbl, in_holm in reg_metrics:
        reg_arrs = [df_local[df_local["region"] == r][col].astype(float).values for r in reg_order]
        h_reg, p_reg = stats.kruskal(*reg_arrs)
        n_reg = sum(len(a) for a in reg_arrs)
        k_reg = len(reg_arrs)
        eps_reg = max(0.0, float((h_reg - k_reg + 1) / max(1, n_reg - k_reg)))
        reg_kw_dict[col] = {
            "Label": lbl,
            "RegionMeans": {r: round(float(np.mean(a)), 4) for r, a in zip(reg_order, reg_arrs)},
            "RegionMedians": {r: round(float(np.median(a)), 4) for r, a in zip(reg_order, reg_arrs)},
            "KW_H": round(float(h_reg), 4),
            "Raw_p": round(float(p_reg), 6),
            "Holm_adj_p": None,
            "Epsilon_sq": round(float(eps_reg), 4),
        }
        if in_holm:
            reg_raw_p_idx.append((col, float(p_reg)))
    holm_reg = holm_bonferroni_adjust([p for _, p in reg_raw_p_idx])
    for (col, _), adj_p in zip(reg_raw_p_idx, holm_reg):
        reg_kw_dict[col]["Holm_adj_p"] = round(float(adj_p), 6)

    # 6G. Sensitivity Power Analysis (alpha = 0.05, power = 0.80, Pitman ARE = 3/pi)
    z_a = float(stats.norm.ppf(1.0 - 0.05 / 2.0))
    z_b = float(stats.norm.ppf(0.80))
    are_pitman = 3.0 / math.pi
    mdes_mw_d = (z_a + z_b) * math.sqrt(2.0 / (30.0 * are_pitman))
    mdes_mw_rrb = 2.0 * float(stats.norm.cdf(mdes_mw_d / math.sqrt(2.0))) - 1.0
    crit_chi2_k3 = float(stats.chi2.ppf(0.95, df=2))
    lam_kw_k3 = float(brentq(lambda lam: (1.0 - float(stats.ncx2.cdf(crit_chi2_k3, df=2, nc=lam))) - 0.80, 0.1, 50.0))
    mdes_kw_f = math.sqrt(lam_kw_k3 / (30.0 * are_pitman))
    mdes_kw_eta2 = (mdes_kw_f ** 2) / (1.0 + mdes_kw_f ** 2)
    power_analysis = {
        "alpha": 0.05,
        "targetPower": 0.80,
        "pitmanARE": round(are_pitman, 4),
        "mannWhitney_30vs30": {
            "mdes_cohen_d": round(float(mdes_mw_d), 3),
            "approx_mdes_abs_rrb": round(float(mdes_mw_rrb), 3),
        },
        "kruskalWallis_3tiers_n10each": {
            "noncentrality_lambda": round(float(lam_kw_k3), 3),
            "mdes_cohen_f": round(float(mdes_kw_f), 3),
            "mdes_eta_sq": round(float(mdes_kw_eta2), 3),
        },
    }

    axe_validation = {
        "scannedSitesCount": int(len(df_ax)),
        "zeroViolationPortalsCount": int((df_ax["axeViolationNodeCount"] == 0).sum()),
        "groupComparisons": axe_group_dict,
        "correlationsWithForaging": axe_corrs,
        "discordanceAudit": {
            "falseComfort_strict_count": int(len(false_comfort_df)),
            "falseComfort_strict_ids": list(false_comfort_df["siteId"]),
            "falseComfort_lowTCR_count": int(len(false_comfort_low_df)),
            "falseComfort_lowTCR_ids": list(false_comfort_low_df["siteId"]),
            "falseAlarm_count": int(len(false_alarm_df)),
            "falseAlarm_ids": list(false_alarm_df["siteId"]),
        },
        "axeNodesByBehavioralSeverity": axe_by_severity,
        "severityTierKruskalWallis": {"H": round(float(h_sev), 4), "p_value": round(float(p_sev), 6)},
        "domSizeConfounding": dom_confounding,
    }

    report_payload = {
        "sampleSize": len(df_sites),
        "groupACount": len(df_a),
        "groupBCount": len(df_b),
        "localTierCounts": {t: int((df_local["localTier"] == t).sum()) for t in local_tiers},
        "totalTaskTrajectories": len(df_tasks),
        "mannWhitneyTests": mann_whitney_results,
        "localTierKruskalWallis": kw_results,
        "regionalKruskalWallis": reg_kw_dict,
        "regionalDescriptiveSummary": regional_summary,
        "fisherExactPerTask": fisher_tests,
        "cochranQTests": cochran_q_tests,
        "bootstrapCIs": bootstrap_cis,
        "correlations": correlations,
        "sensitivityAnalysis": sensitivity_rows,
        "outlierSensitivity": outlier_sensitivity,
        "axeBaselineValidation": axe_validation,
        "powerAnalysis": power_analysis,
        "failureModeAudit": failure_summary,
        "completionPrecisionAudit": completion_precision_audit,
        "pageEvidenceSensitivity": page_evidence_audit,
    }
    report_json_path = out_dir / "hypothesis_tests_report.json"
    with open(report_json_path, "w", encoding="utf-8") as f:
        json.dump(report_payload, f, indent=2, ensure_ascii=False)

    # 7. Figure 1: Hero Finding (Ambiguous Link Ratio %) & Per-Task Completion by Group
    plt.rcParams.update({
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "figure.dpi": 300,
    })

    n_a = len(df_a)
    n_b = len(df_b)
    n_total = len(df_sites)

    fig, axes = plt.subplots(1, 2, figsize=(12.2, 5.1))

    ax1 = axes[0]
    a_amb = df_a["ambiguousLinkRatio"].values * 100.0
    b_amb = df_b["ambiguousLinkRatio"].values * 100.0
    bp = ax1.boxplot(
        [a_amb, b_amb],
        tick_labels=[
            f"Group A:\nCentral Agencies\n(n = {n_a})",
            f"Group B:\nLocal Governments\n(4 Regions, n = {n_b})",
        ],
        widths=0.45,
        patch_artist=True,
        showfliers=False,
        medianprops={"color": "#111111", "linewidth": 2.0},
        boxprops={"linewidth": 1.2},
    )
    colors = ["#2563eb", "#ea580c"]
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.32)

    rng = np.random.default_rng(42)
    for i, (vals, col) in enumerate(zip([a_amb, b_amb], colors), start=1):
        jitter = rng.uniform(-0.10, 0.10, size=len(vals))
        ax1.scatter(
            np.full(len(vals), i) + jitter,
            vals,
            color=col,
            edgecolor="#0f172a",
            linewidth=0.7,
            s=42,
            alpha=0.88,
            zorder=3,
        )

    mw_amb = mann_whitney_results.get("ambiguousLinkRatio", {})
    u_amb = mw_amb.get("MannWhitney_U", 0.0)
    p_amb_holm = mw_amb.get("Holm_adj_p", 1.0)
    r_amb = mw_amb.get("RankBiserial_r", 0.0)
    sig_amb = "*" if p_amb_holm < 0.05 else ""
    ax1.set_title(
        f"(a) Ambiguous Link Ratio by Agency Tier\n(U = {u_amb:.1f}, p_Holm = {p_amb_holm:.4f}{sig_amb}, r_rb = {r_amb:.2f})",
        fontweight="bold",
    )
    ax1.set_ylabel("Ambiguous / Unlabelled Links (%)")
    y_max_amb = max(62.0, float(np.max(a_amb)) + 8.0, float(np.max(b_amb)) + 8.0)
    ax1.set_ylim(-3.0, y_max_amb)
    ax1.grid(axis="y", linestyle="--", alpha=0.45)

    ax2 = axes[1]
    tasks_order = ["T1_Contact", "T2_ServiceForm", "T3_Procurement_Plan"]
    task_labels = ["T1: Contact\n(Shallow)", "T2: Service/Form\n(Medium)", "T3: Procurement/Plan\n(Deep)"]

    a_tcr = [
        df_tasks[(df_tasks["taskId"] == t) & (df_tasks["group"] == "Group_A_Central")]["taskCompleted"].mean() * 100.0
        for t in tasks_order
    ]
    b_tcr = [
        df_tasks[(df_tasks["taskId"] == t) & (df_tasks["group"] == "Group_B_Regional")]["taskCompleted"].mean() * 100.0
        for t in tasks_order
    ]

    x_idx = np.arange(len(tasks_order))
    width = 0.34
    bars_a = ax2.bar(x_idx - width / 2, a_tcr, width, label=f"Group A: Central (n={n_a})", color="#2563eb", alpha=0.85, edgecolor="#0f172a")
    bars_b = ax2.bar(x_idx + width / 2, b_tcr, width, label=f"Group B: Local (n={n_b})", color="#ea580c", alpha=0.85, edgecolor="#0f172a")

    for bars in [bars_a, bars_b]:
        for bar in bars:
            h = bar.get_height()
            ax2.annotate(
                f"{h:.1f}%",
                xy=(bar.get_x() + bar.get_width() / 2, h),
                xytext=(0, 3),
                textcoords="offset points",
                ha="center",
                va="bottom",
                fontsize=8.5,
                fontweight="bold",
            )

    ax2.set_xticks(x_idx)
    ax2.set_xticklabels(task_labels)
    ax2.set_ylabel("Task Completion Rate (%)")
    ax2.set_ylim(0, 118)
    ax2.set_title(f"(b) Task Completion Rate Across Foraging Depth\n(Cochran's Q = {q_all:.2f}, p = {p_q_all:.4f})", fontweight="bold")
    ax2.legend(loc="upper right", frameon=True)
    ax2.grid(axis="y", linestyle="--", alpha=0.45)

    plt.tight_layout()
    fig1_path = out_dir / "fig1_backtrack_by_group.png"
    fig1_alt_path = out_dir / "fig1_ambiguity_and_tasks.png"
    plt.savefig(fig1_path, dpi=300)
    plt.savefig(fig1_alt_path, dpi=300)
    plt.close(fig)

    # 8. Figure 2: Link Density vs. Backtrack Rate Scatter + Bounded Kernel Smoother (No Negative OLS Extrapolation)
    fig2, ax = plt.subplots(figsize=(8.0, 5.4))

    ax.scatter(
        df_a["linkDensityPer10kPx"],
        df_a["backtrackRate"],
        color="#2563eb",
        marker="o",
        s=58,
        alpha=0.86,
        edgecolor="#0f172a",
        linewidth=0.8,
        label=f"Group A: Central Agencies (n={n_a})",
    )
    ax.scatter(
        df_b["linkDensityPer10kPx"],
        df_b["backtrackRate"],
        color="#ea580c",
        marker="^",
        s=64,
        alpha=0.86,
        edgecolor="#0f172a",
        linewidth=0.8,
        label=f"Group B: Local Governments (n={n_b})",
    )

    highlight_ids = {"A01", "A02", "A09", "A27", "B01", "B07", "B13", "B20", "B25", "B26"}
    for _, r in df_sites.iterrows():
        if r["siteId"] in highlight_ids:
            lbl_txt = "A09 (Outlier)" if r["siteId"] == "A09" else r["siteId"]
            if r["siteId"] == "A09":
                offset_x, offset_y = -46, 6
            elif r["siteId"] == "B25":
                offset_x, offset_y = 4, -12
            elif r["siteId"] == "B13":
                offset_x, offset_y = 6, 5
            elif r["siteId"] == "A01":
                offset_x, offset_y = 5, 6
            elif r["siteId"] in {"A02", "B07"}:
                offset_x, offset_y = 4, -11
            else:
                offset_x, offset_y = 4, 6
            ax.annotate(
                lbl_txt,
                (r["linkDensityPer10kPx"], r["backtrackRate"]),
                xytext=(offset_x, offset_y),
                textcoords="offset points",
                fontsize=7.5,
                color="#334155",
            )
    ax.annotate(
        "A22, A25\n(0-link)",
        (0.0, 0.0),
        xytext=(5, 10),
        textcoords="offset points",
        fontsize=7.1,
        color="#1e3a8a",
    )

    x_all = df_sites["linkDensityPer10kPx"].astype(float).values
    y_all = df_sites["backtrackRate"].astype(float).values
    main_mask = x_all <= 0.60
    x_main = x_all[main_mask]
    y_main = y_all[main_mask]
    if len(x_main) >= 5:
        x_grid = np.linspace(0.0, float(np.max(x_main)), 120)
        bw = 0.085
        weights = np.exp(-0.5 * ((x_grid[:, None] - x_main[None, :]) / bw) ** 2)
        y_smooth = np.clip((weights @ y_main) / np.maximum(weights.sum(axis=1), 1e-12), 0.0, 1.0)
        ax.plot(
            x_grid,
            y_smooth,
            color="#0f172a",
            linestyle="--",
            linewidth=1.8,
            label="Bounded Kernel Smoother (Main Cluster)",
        )

    c_info = correlations.get("linkDensityPer10kPx_vs_backtrackRate", {})
    rho = c_info.get("spearman_rho", 0.0)
    p_s = c_info.get("spearman_p", 1.0)

    ax.set_title(
        f"Above-the-Fold Link Density vs. Backtrack Rate (N = {n_total})\n"
        f"Full Spearman ρ = {rho:.3f} (p = {p_s:.4f}) | Excl. A09 ρ = {rho_na09:.3f} (p = {p_rho_na09:.4f})",
        fontweight="bold",
    )
    ax.set_xlabel("Above-the-Fold Link Density (Links per 10,000 px² at 1366×768)")
    ax.set_ylabel("Mean Foraging Backtrack Rate (Backtracks / Step)")
    ax.set_ylim(-0.05, 1.08)
    ax.set_xlim(-0.04, max(0.60, float(np.max(x_all)) + 0.08))
    ax.grid(True, linestyle="--", alpha=0.45)
    ax.legend(loc="upper right", frameon=True)

    plt.tight_layout()
    fig2_path = out_dir / "fig2_density_vs_backtrack.png"
    fig3_seq_path = out_dir / "fig3_density_vs_backtrack.png"
    plt.savefig(fig2_path, dpi=300)
    plt.savefig(fig3_seq_path, dpi=300)
    plt.close(fig2)

    # 9. Figure 3: Within-Local Local Government Strata vs. Four-Region CMS Inheritance (RQ1b)
    fig3, axes3 = plt.subplots(1, 2, figsize=(12.6, 5.2))
    tier_labels = [
        "Large City / PAO\n(n = 10)",
        "Medium Town\n(n = 10)",
        "Small Subdistrict\n(n = 10)",
    ]
    tier_colors = ["#0f766e", "#d97706", "#be123c"]
    tier_data_amb = [df_local[df_local["localTier"] == t]["ambiguousLinkRatio"].values * 100.0 for t in local_tiers]

    ax3a = axes3[0]
    bp3 = ax3a.boxplot(
        tier_data_amb,
        tick_labels=tier_labels,
        widths=0.46,
        patch_artist=True,
        showfliers=False,
        medianprops={"color": "#111111", "linewidth": 2.0},
        boxprops={"linewidth": 1.2},
    )
    for patch, col in zip(bp3["boxes"], tier_colors):
        patch.set_facecolor(col)
        patch.set_alpha(0.32)

    rng3 = np.random.default_rng(7)
    for idx_t, (vals_t, col_t) in enumerate(zip(tier_data_amb, tier_colors), start=1):
        jitter_t = rng3.uniform(-0.10, 0.10, size=len(vals_t))
        ax3a.scatter(
            np.full(len(vals_t), idx_t) + jitter_t,
            vals_t,
            color=col_t,
            edgecolor="#0f172a",
            linewidth=0.7,
            s=46,
            alpha=0.9,
            zorder=3,
        )

    central_amb_mean = float(df_a["ambiguousLinkRatio"].mean() * 100.0)
    ax3a.axhline(
        central_amb_mean,
        color="#2563eb",
        linestyle="--",
        linewidth=1.5,
        label=f"Group A Central Mean ({central_amb_mean:.1f}%)",
    )
    kw_amb = kw_results.get("ambiguousLinkRatio", {})
    ax3a.set_title(
        f"(a) Ambiguous Link Ratio by Local Tier\n"
        f"(H = {kw_amb.get('KruskalWallis_H', 0):.2f}, p_Holm = {kw_amb.get('Holm_adj_p', 1):.4f}, ε² = {kw_amb.get('Epsilon_sq', 0):.3f})",
        fontweight="bold",
    )
    ax3a.set_ylabel("Ambiguous / Unlabelled Links (%)")
    ax3a.set_ylim(-4.0, max(62.0, float(np.max(df_local["ambiguousLinkRatio"].values * 100.0)) + 10.0))
    ax3a.legend(loc="upper right", frameon=True)
    ax3a.grid(axis="y", linestyle="--", alpha=0.45)

    ax3b = axes3[1]
    reg_tick_labels = ["North\n(n = 10)", "Northeast\n(n = 7)", "Central/East\n(n = 6)", "South\n(n = 7)"]
    reg_data_ax = [df_local[df_local["region"] == r]["axeViolationNodeCount"].astype(float).values for r in reg_order]
    bp3b = ax3b.boxplot(
        reg_data_ax,
        tick_labels=reg_tick_labels,
        widths=0.46,
        patch_artist=True,
        showfliers=False,
        medianprops={"color": "#111111", "linewidth": 2.0},
        boxprops={"linewidth": 1.2},
    )
    reg_box_colors = ["#cbd5e1", "#cbd5e1", "#cbd5e1", "#cbd5e1"]
    for patch, col in zip(bp3b["boxes"], reg_box_colors):
        patch.set_facecolor(col)
        patch.set_alpha(0.42)

    tier_display = ["Large City / PAO (n=10)", "Medium Town (n=10)", "Small Subdistrict (n=10)"]
    tier_markers = ["o", "s", "^"]
    rng3b = np.random.default_rng(19)
    for idx_t, (tier_key, tier_lbl, col_t, mk_t) in enumerate(zip(local_tiers, tier_display, tier_colors, tier_markers)):
        added_lbl = False
        for idx_r, reg_key in enumerate(reg_order, start=1):
            vals_rt = df_local[(df_local["region"] == reg_key) & (df_local["localTier"] == tier_key)]["axeViolationNodeCount"].astype(float).values
            if len(vals_rt) == 0:
                continue
            jit_rt = rng3b.uniform(-0.11, 0.11, size=len(vals_rt))
            ax3b.scatter(
                np.full(len(vals_rt), idx_r) + jit_rt,
                vals_rt,
                color=col_t,
                marker=mk_t,
                edgecolor="#0f172a",
                linewidth=0.75,
                s=52,
                alpha=0.92,
                zorder=3,
                label=tier_lbl if not added_lbl else None,
            )
            added_lbl = True

    reg_ax_info = reg_kw_dict.get("axeViolationNodeCount", {})
    ax3b.set_title(
        f"(b) Static WCAG Violations by Geographic Region\n"
        f"(4-Region KW H = {reg_ax_info.get('KW_H', 0):.2f}, p_Holm = {reg_ax_info.get('Holm_adj_p', 1):.4f}*, ε² = {reg_ax_info.get('Epsilon_sq', 0):.3f})",
        fontweight="bold",
    )
    ax3b.set_ylabel("axe-core WCAG 2.1 rule-node instances")
    ax3b.set_ylim(-25.0, max(645.0, float(df_local["axeViolationNodeCount"].max()) + 65.0))
    ax3b.legend(loc="upper left", frameon=True, fontsize=8.3, title="Local Government Stratum", title_fontsize=8.3)
    ax3b.grid(axis="y", linestyle="--", alpha=0.45)

    plt.tight_layout()
    fig2_seq_path = out_dir / "fig2_local_tier_comparison.png"
    fig3_path = out_dir / "fig3_local_tier_comparison.png"
    plt.savefig(fig2_seq_path, dpi=300)
    plt.savefig(fig3_path, dpi=300)
    plt.close(fig3)

    # 10. Figure 4: RQ4 Static axe-core Baseline vs. Behavioral Information Foraging
    fig4, axes4 = plt.subplots(1, 2, figsize=(12.8, 5.4))

    ax4a = axes4[0]
    ax_a = df_ax[df_ax["group"] == "Group_A_Central"]
    ax_b = df_ax[df_ax["group"] == "Group_B_Regional"]
    ax4a.fill_betweenx([0, 50], 0, 10, color="#fecaca", alpha=0.55, label="≤10 instances, <50% completion")
    ax4a.hlines(100, 50, max(620, float(df_ax["axeViolationNodeCount"].max()) + 30), color="#16a34a", alpha=0.45, linewidth=3, label="≥50 instances, 100% completion")

    ax4a.scatter(
        ax_a["axeViolationNodeCount"],
        ax_a["TCR"] * 100.0,
        color="#2563eb",
        marker="o",
        s=58,
        alpha=0.88,
        edgecolor="#0f172a",
        linewidth=0.8,
        label=f"Group A: Central (n={len(ax_a)})",
    )
    ax4a.scatter(
        ax_b["axeViolationNodeCount"],
        ax_b["TCR"] * 100.0,
        color="#ea580c",
        marker="^",
        s=64,
        alpha=0.88,
        edgecolor="#0f172a",
        linewidth=0.8,
        label=f"Group B: Local (n={len(ax_b)})",
    )

    ax4a.annotate(
        "A16, A22, A24, A25, A29, B09\n(0-2 instances, 0% completion)",
        (2, 0),
        xytext=(10, 14),
        textcoords="offset points",
        fontsize=7.3,
        color="#991b1b",
        fontweight="bold",
    )
    for _, r in df_ax.iterrows():
        if r["siteId"] in {"A01", "A27", "B20", "B26", "B29", "B30", "B02"}:
            ox = 6 if r["axeViolationNodeCount"] < 500 else -26
            oy = -11 if r["siteId"] in {"A27", "B26", "B30"} else 5
            ax4a.annotate(
                r["siteId"],
                (r["axeViolationNodeCount"], r["TCR"] * 100.0),
                xytext=(ox, oy),
                textcoords="offset points",
                fontsize=7.5,
                color="#334155",
            )

    ax_tcr_corr = axe_corrs.get("axeViolationNodeCount_vs_TCR", {})
    ax4a.set_title(
        f"(a) axe-core Counts vs. Simulated Completion\n"
        f"(Spearman ρ = {ax_tcr_corr.get('spearman_rho', 0):.3f}, p = {ax_tcr_corr.get('spearman_p', 1):.4f})",
        fontweight="bold",
    )
    ax4a.set_xlabel("axe-core WCAG 2.1 rule-node instances")
    ax4a.set_ylabel("Simulated task completion (%)")
    ax4a.set_xlim(-18, max(620, float(df_ax["axeViolationNodeCount"].max()) + 35))
    ax4a.set_ylim(-6, 110)
    ax4a.grid(True, linestyle="--", alpha=0.45)
    ax4a.legend(loc="center right", frameon=True, fontsize=8.0)

    ax4b = axes4[1]
    sev_labels = ["Tier 1\nCritical", "Tier 2\nHigh", "Tier 3\nModerate", "Tier 4\nMinor", "Tier 5\nBenchmark"]
    sev_colors = ["#dc2626", "#ea580c", "#d97706", "#2563eb", "#0f766e"]
    bp4 = ax4b.boxplot(
        sev_arrays,
        tick_labels=[f"{lbl}\n(n={len(arr)})" for lbl, arr in zip(sev_labels, sev_arrays)],
        widths=0.48,
        patch_artist=True,
        showfliers=False,
        medianprops={"color": "#111111", "linewidth": 2.0},
        boxprops={"linewidth": 1.2},
    )
    for patch, col in zip(bp4["boxes"], sev_colors):
        patch.set_facecolor(col)
        patch.set_alpha(0.32)

    rng4 = np.random.default_rng(11)
    for idx_s, (arr_s, col_s) in enumerate(zip(sev_arrays, sev_colors), start=1):
        if len(arr_s) == 0:
            continue
        jit_s = rng4.uniform(-0.10, 0.10, size=len(arr_s))
        ax4b.scatter(
            np.full(len(arr_s), idx_s) + jit_s,
            arr_s,
            color=col_s,
            edgecolor="#0f172a",
            linewidth=0.7,
            s=40,
            alpha=0.88,
            zorder=3,
        )

    ax4b.set_title(
        f"(b) axe-core Counts Across Diagnostic Tiers\n"
        f"(Kruskal-Wallis H = {h_sev:.2f}, p = {p_sev:.4f})",
        fontweight="bold",
    )
    ax4b.set_ylabel("axe-core WCAG 2.1 rule-node instances")
    ax4b.set_ylim(-20, max(620, float(df_ax["axeViolationNodeCount"].max()) + 40))
    ax4b.grid(axis="y", linestyle="--", alpha=0.45)

    plt.tight_layout()
    fig4_path = out_dir / "fig4_axe_vs_foraging.png"
    plt.savefig(fig4_path, dpi=300)
    plt.close(fig4)

    print(f"\n=== N={n_total} MANN-WHITNEY & HOLM-BONFERRONI SUMMARY ===")
    print(df_summary[["Metric", "Test_Role", "GroupA_Mean", "GroupB_Mean", "p_value", "Holm_adj_p", "Significant_p05"]].to_string(index=False))
    print("\n=== RQ1b KRUSKAL-WALLIS 3-TIER LOCAL COMPARISON (n=10 / tier) ===")
    print(df_kw[["Metric", "Large_City_PAO_Mean", "Medium_Town_Mean", "Small_Subdistrict_Mean", "KruskalWallis_H", "p_value", "Holm_adj_p", "Epsilon_sq"]].to_string(index=False))
    print("\n=== OUTLIER & ZERO-LINK SENSITIVITY ===")
    print(json.dumps(outlier_sensitivity, indent=2))
    print("\n=== RQ4 AXE-CORE BASELINE VALIDATION ===")
    print(df_axe_summary[["Metric", "GroupA_Mean", "GroupB_Mean", "p_value_A_vs_B", "LocalTier_KW_H", "LocalTier_KW_p"]].to_string(index=False))
    print("Axe Correlations:", json.dumps(axe_corrs, indent=2))
    print("Discordance Audit:", json.dumps(axe_validation["discordanceAudit"], indent=2))
    print("\n=== BOOTSTRAP 95% CIs ===")
    print(json.dumps(bootstrap_cis, indent=2))
    print("\n=== COMPLETION PRECISION AUDIT ===")
    print(json.dumps(completion_precision_audit, indent=2, ensure_ascii=False))
    print(f"\nSaved all N={n_total} outputs + Figures 1-4 to: {out_dir}")


if __name__ == "__main__":
    main()
