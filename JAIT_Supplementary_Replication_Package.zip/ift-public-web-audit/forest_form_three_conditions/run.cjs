const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const Module = require('node:module');
const assert = require('node:assert/strict');
const root = __dirname;
const pilot = path.resolve(root, '../IFT_BM25_paired_pilot');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
const file = name => path.join(root, name);
const digest = name => crypto.createHash('sha256').update(fs.readFileSync(name)).digest('hex');
const originalFile = path.join(pilot, 'paired.cjs');
const lock = read(path.join(pilot, 'lock.json'));
for (const [n,h] of Object.entries(lock.hashes)) assert.equal(digest(path.resolve(pilot,n)),h);
const source = fs.readFileSync(originalFile,'utf8');
const prefix = source.slice(0,source.indexOf('async function main()'));
const loader = new Module(originalFile, module);
loader.filename = originalFile;
loader.paths = module.paths;
loader._compile(prefix + '\nmodule.exports=engine;', originalFile);
const engine = loader.exports;
const stash = read(path.join(pilot,'FOREST-states.json'));
const baseline = read(path.join(pilot,'replay.json')).find(s=>s.site==='FOREST');
assert.equal(digest(path.join(pilot,'FOREST-states.json')),baseline.stateHash);
const task = 'T2_ServiceForm';
const forms = new URL(read(path.join(pilot,'references.json')).sites.find(s=>s[0]==='FOREST')[4][0]).href;
const staff = 'https://www.forest.go.th/services/personnel/';
const label = 'บริการประชาชน';
const namedForm = 'แบบคำขอข้อมูลข่าวสารของกรมป่าไม้';
const labels = read(path.join(pilot,'destination_labels.json')).filter(l=>l.site==='FOREST' && l.task===task);
async function capturePage(url, filename) {
 const {chromium} = require('playwright');
 const browser = await chromium.launch({channel:'chrome'});
 try {
  const ctx=await browser.newContext({viewport:{width:1366,height:768},serviceWorkers:'block',acceptDownloads:false,ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'});
  await ctx.route('**/*',r=>['GET','HEAD'].includes(r.request().method())?r.continue():r.abort());
  const page=await ctx.newPage();
  const navRes=await engine.safeNavigate(page,url,11000);
  if(url===forms)assert.equal(navRes.status,200);
  const snapshot=navRes.ok?await engine.extractPageMetricsAndLinks(page):null;
  if(url===forms)assert(snapshot.evidence.main.includes(namedForm));
  if(url===forms)assert(snapshot.candidates.some(c=>c.text.includes(namedForm)));
  fs.writeFileSync(file(filename),JSON.stringify({snapshot,navRes,actualUrl:page.url(),time:new Date().toISOString()}));
 } finally {await browser.close();}
}
async function run() {
 if(!fs.existsSync(file('form-index.json'))){assert(process.argv.includes('--capture-form'),'Missing form snapshot');await capturePage(forms,'form-index.json');}
 const index=read(file('form-index.json'));
 const guide='https://www.forest.go.th/psdg/act-2/guide_for_the_citizens/';
 if (!fs.existsSync(file('guide.json'))) {assert(process.argv.includes('--capture-form'));await capturePage(guide,'guide.json');}
 const guidePage=read(file('guide.json'));
 if(process.argv.includes('--inspect')){console.log(guidePage.snapshot.evidence.main.slice(0,3000),guidePage.snapshot.candidates.filter(c=>/pdf|docx/i.test(c.href)).map(c=>c.text));return;}
 const results=[];
 for(const condition of ['original','label_only','target_only']){
  const home=structuredClone(stash.home.snapshot);
  const matches=home.candidates.filter(c=>c.text===label && c.href===staff);
  assert.equal(matches.length,1);
  if(condition==='label_only') matches[0].text='บริการสำหรับเจ้าหน้าที่';
  if(condition==='target_only') matches[0].href=forms;
  const visits=[];
  const lookup=async(u,id,step)=>{
   let state=u===forms?index:u===guide?guidePage:stash.pages[u];
   if(!state){const f='page-'+crypto.createHash('sha256').update(u).digest('hex').slice(0,14)+'.json';if(!fs.existsSync(file(f))){assert(process.argv.includes('--capture-form'),'Uncached '+u);await capturePage(u,f);}state=read(file(f));}

   if(id===task && state.snapshot){
    const evidence=u===forms?{label:'Y',reason:index.snapshot.candidates.find(c=>c.text.includes(namedForm)).text}:u===guide?{label:'N',reason:'Citizen manual updates and circulars; no named public form in main content.'}:u==='https://cloud.forest.go.th/s/mdY7qk4PFBRmzPm'?{label:'U',reason:'File viewer shows V195.pdf and Download, without readable file contents.'}:labels.find(l=>l.actual===state.actualUrl);
    if(!evidence) console.log('REVIEW',u,state.navRes,state.snapshot.evidence.main.slice(0,1800));
    visits.push({step,url:state.actualUrl,title:state.snapshot.pageTitle,qualifies:evidence?.label||'pending',reason:evidence?.reason||evidence?.rationale_th});
   }
   return state;
  };
  const t=(await engine.run(home,stash.home.actualUrl,lookup,false,()=>{}))[task];
  delete t.completionTimeMs;
  if(condition==='original')assert.deepEqual(t,baseline.arms.IFT.result[task]);
  results.push({condition,visits,reached:visits.some(v=>v.qualifies==='Y')?'Y':visits.some(v=>v.qualifies==='U')?'U':'N',reported:t.taskCompleted,trace:t});
 }
 if(results.some(r=>r.visits.some(v=>v.qualifies==='pending')))throw Error('Inspect new endpoint before scoring');
 const output=JSON.stringify({sourceHash:baseline.stateHash,formHash:digest(file('form-index.json')),guideHash:digest(file('guide.json')),protocolHash:digest(file('protocol.txt')),results},null,2);
 if(fs.existsSync(file('results.json')))assert.equal(fs.readFileSync(file('results.json'),'utf8'),output);
 else fs.writeFileSync(file('results.json'),output);
 for(const r of results)console.log(r.condition,r.trace.decisionLogs.map(d=>[d.selectedText,d.selectedHref]),r.reached,r.reported);
}
run().catch(e=>{console.error(e);process.exitCode=1});
