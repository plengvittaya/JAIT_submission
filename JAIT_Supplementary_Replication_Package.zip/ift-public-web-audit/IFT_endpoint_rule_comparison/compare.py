from pathlib import Path
import csv, json, re, hashlib
from collections import Counter
from bs4 import BeautifulSoup

out=Path(__file__).resolve().parent
project=out.parent
archive=project/'JAIT_Endpoint_Review/coordinator/runs/Desktop60_R01'
def readcsv(path):
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def normalized(text):
    return ' '.join(text.lower().split())
def gate(task,e):
    if e['kind']!='navigation': return 'unverified','unopened target'
    page=e.get('page') or {}
    body=normalized(page.get('body',''))
    if not (200<=int(e.get('status') or 0)<400 and body and page.get('dom')):
        return 'unverified','unavailable page'
    if task.startswith('T1'):
        phone=r'(?:โทรศัพท์|โทร\.?|tel(?:ephone)?\.?)\s*[:.\-]?\s*\(?0[\d ()\-]{7,15}\d'
        email=r'[\w.+-]+@[\w.-]+\.(?:go|or)\.th\b'
        if re.search(phone,body) or re.search(email,body): return 'success','contact channel in visible text'
        return 'withheld','no qualifying contact pattern'
    dom=BeautifulSoup(page['dom'],'html.parser')
    for tag in dom.select('nav, header, footer, aside, script, style, [role=navigation], [hidden], [aria-hidden=true]'):
        if tag.parent is not None: tag.decompose()
    main=dom.select_one('main, [role=main], article') or dom.body or dom
    # Evaluate named links, headings or individual list items that also appear in visible text.
    for el in main.select('a[href],h1,h2,h3,h4,li'):
        text=normalized(el.get_text(' ',strip=True))
        if not 6<=len(text)<=280 or text not in body: continue
        if task.startswith('T2'):
            if re.search(r'(?:แบบคำขอ|แบบฟอร์ม|แบบคำร้อง|แบบขอ|คู่มือ(?:สำหรับประชาชน)?|application form|service guide)\s*[:\-–]?\s*(?:การ|ขอ|รับ|ยื่น|จด|แจ้ง|ขึ้น|ลง|ต่อ|ชำระ|ยกเลิก|อนุญาต|ทะเบียน|for\b)\S*',text):
                return 'success','named form or service guide'
        elif re.search(r'แผน(?:การ)?จัด(?:ซื้อ|หา)|procurement plan',text) and re.search(r'(?:25[0-9]{2}|๒๕[๐-๙]{2}|20[0-9]{2}|โครงการ\s*\S{3,})',text):
            return 'success','procurement plan with year or named project'
    return 'withheld','no qualifying destination item'

keys=readcsv(archive/'release/export/key.csv')
pred=[]
for k in keys:
    yes=k['simulated_completed']=='1'
    if yes:
        data=(archive/'evidence'/f"{k['site']}_{k['task']}.json").read_bytes()
        assert hashlib.sha256(data).hexdigest()==k['evidence_sha256']
        decision,reason=gate(k['task'],json.loads(data.decode('utf-8-sig')))
    else: decision,reason='original_negative','original did not report success'
    pred.append(dict(case=k['case'],site=k['site'],task=k['task'],original=yes,gate=decision,reason=reason))
# Join reference labels only after every prediction has been made.
reference={r['case']:r for r in readcsv(project/'Desktop60_R01_positive_endpoint_review/case_results.csv')}
assert len(pred)==len({r['case'] for r in pred})==180 and len(reference)==122
assert set(reference)=={r['case'] for r in pred if r['original']}
for r in pred:
    ref=reference.get(r['case'])
    if ref: assert (ref['site'],ref['task'])==(r['site'],r['task'])
    r['reference']=({'Y':'correct','N':'wrong','U':'unknown','L':'unknown'}[ref['code']] if ref else 'unassessed')
with (out/'case_results.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=pred[0]);w.writeheader();w.writerows(pred)
summary={}
for task in ['all',*sorted({r['task'] for r in pred})]:
    subset=[r for r in pred if task=='all' or r['task']==task]
    summary[task]={}
    for arm,select in [('original',lambda r:r['original']),('endpoint',lambda r:r['gate']=='success'),('withheld_from_original',lambda r:r['original'] and r['gate']!='success')]:
        summary[task][arm]=dict(Counter(r['reference'] for r in subset if select(r)))
print(json.dumps(summary,indent=2))
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
