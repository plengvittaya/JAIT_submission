# Computational Information Foraging & Static Accessibility Audits (`ift-public-web-audit`)

This package contains the audit scripts, archived data and analysis outputs for a study of 60 Thai government portals.

---

## Overview & Archived Snapshot (`November 21, 2026`)

- **De-Confounded Corpus (`N = 60` portals, `180` foraging trajectories):** `30` Thai central government agencies (`A01..A30`) and `30` local governments (27 municipalities and three provincial administrative organizations) (`B01..B30`) balanced `10/10/10` across three analytical strata: seven city municipalities plus three PAOs (Phayao, Chiang Rai and Udon Thani), ten town municipalities, and ten subdistrict municipalities across four geographic regions (`North = 10`, `Northeast = 7`, `Central/East = 6`, `South = 7`).
- **Paired Live Static Baseline (`N = 60`):** `@axe-core/playwright` WCAG 2.1 Level AA scans executed in a separate same-day run for the same 60 portal homepages, using the splash-bypass procedure.
- **Stratified CDP AXTree & Keyboard `Tab` Validation (`n = 9` portals, `27` tasks):** Achieved `92.59%` exact agreement (`Cohen's kappa = 0.8525`) against native `Accessibility.getFullAXTree` named task-cue exposure and `77.78%` (`kappa = 0.5500`) against 60-step sequential keyboard `Tab` reachability.

---

Supplementary Table S1 (JAIT_Supplementary_Material_Table_S1.docx) is supplied as a separate OJS attachment. It contains the diagnostics for all 60 portals.

## Replication ZIP contents

```text
ift-public-web-audit/
├── tests/
│   ├── ift_foraging_audit.spec.ts       # Deterministic IFT/SNIF-ACT crawler (180 trajectories)
│   ├── axe_baseline_audit.spec.ts       # Paired @axe-core/playwright WCAG 2.1 AA scanner
│   └── axtree_keyboard_audit.spec.ts    # Stratified CDP AXTree & 60-step Tab validator
├── ift_hci_results/
│   ├── ift_hci_master_dataset.json      # Consolidated 60-portal / 180-trajectory snapshot
│   ├── axe_baseline_dataset.json        # Matched 60/60 live axe-core WCAG 2.1 AA output
│   ├── axtree_keyboard_validation.json  # Stratified 9-portal / 27-task CDP & Tab validation
│   └── A01..B30_foraging_result.json    # Per-portal foraging telemetry & trace logs (60 files)
├── paper_analysis_output/
│   ├── *.csv (8 files)                  # Group, tier, task, correlation, and remediation tables
│   ├── hypothesis_tests_report.json     # Full Mann-Whitney, Kruskal-Wallis, Spearman & power JSON
│   └── fig0..fig4_*.png (5 files)       # 300 DPI publication figures (Figs. 1-5)
├── analyze_ift_hci.py                   # Statistical pipeline & empirical plots (Figs. 2-5)
├── generate_architecture_fig.py         # Tri-stream system architecture diagram (Fig. 1)
├── playwright.config.ts
├── package.json
├── package-lock.json
├── requirements.txt
└── LICENSE
```

---

## Setup & Reproduction

### 1. Reproduce Published Statistics & Figures from Archived Datasets

```bash
pip install -r requirements.txt
npm run analyze
npm run fig:arch
```

All statistical tests (`paper_analysis_output/hypothesis_tests_report.json`), summary CSV tables, and 300 DPI figures (`Fig. 1` through `Fig. 5`) regenerate deterministically from `ift_hci_results/`.

### 2. Re-Run Live Browser Audits

```bash
npm install
npx playwright install chromium
npm run audit
npm run audit:axe
npm run audit:axtree
```

If using a custom local Chromium binary, set `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` before running `npx playwright test`. Note that live public websites change content and seasonal splash overlays over time; exact numerical reproduction of the November 21, 2026 findings relies on `ift_hci_results/`.

---

## Exploratory Live Follow-ups

The failed-route check and density-penalty ablation are separate from the 60-portal archive. See [follow-up evidence and protocol](paper_analysis_output/followup/README.md) for scope, observed outcomes, and interpretation. The main replication commands still use the archived dataset.

---

## Page-evidence sensitivity analysis

Running `npm run analyze` writes the per-task counts, five recoded site/task identifiers and paired Cochran test to `pageEvidenceSensitivity` in `paper_analysis_output/hypothesis_tests_report.json`. The denominator remains 60 per task. Only archived completions ending in direct document-link selection are recoded. The borderline endpoint analysis uses a different criterion. No independent reviewer labels enter this analysis.

## Ethical Crawling Protocol

The Playwright crawlers operate sequentially (`workers: 1`) using read-only HTTP `GET` requests, bypass non-interactive server errors gracefully, submit zero `POST` forms or account credentials, and store zero personal data.

---

## License

- **Code (`*.ts`, `*.py`, configs):** [MIT License](LICENSE).
- **Archived JSON/CSV Datasets, Figures & Separately Supplied Supplementary Table (`ift_hci_results/`, `paper_analysis_output/`, `JAIT_Supplementary_Material_Table_S1.docx`):** Creative Commons Attribution 4.0 International (`CC BY 4.0`).
