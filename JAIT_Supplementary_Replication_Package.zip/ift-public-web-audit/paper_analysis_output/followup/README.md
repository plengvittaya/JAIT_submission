# Exploratory live checks

The original archived audit, derived statistics, and figures remain the study's primary dataset. Both live follow-ups ran on 22 November 2026. Mutable sites, browser differences, and independent page loads limit comparisons with the archive.

- `failed_route_check.json` records all 58 archived non-completions. The probe examined live links on each archived resolved start page and opened up to three same-host candidates per task. Seven are conservative positives confirmed from the destination content, six returned an unsuccessful homepage status, and 45 remain unresolved. This is neither a blinded human validation nor an estimate of historical false negatives.
- `density_ablation.json` records both arms of the focused live pilot, including unpaired sites and task summaries. The sample comprises all nine archived portals with above-the-fold link density strictly above the scoring threshold of 0.35 links per 10,000 square pixels. The separate baseline and zero-density runs use the same fixed resolved URL per portal and the same request policy. They start in independent browser contexts and can receive different live content.

## Re-execution

Run the saved probe from the repository root after `npm ci` and with Google Chrome installed.

```powershell
node paper_analysis_output/followup/failed_route_probe.cjs
```

The probe writes local candidate material for inspection. That raw output may include unrelated page content and should not be distributed. The release includes only the per-task assessment and links for the positive cases.

For the ablation, use a disposable copy of the replication directory. From its root, apply `git apply --ignore-space-change paper_analysis_output/followup/density_ablation.patch`. Run the following from that root in each new copy. Configure the Chrome executable for the local system. Use fresh output folders for every pair of runs so that the audit cache cannot mix conditions.

```powershell
$env:JAIT_ARCHIVE = (Resolve-Path ift_hci_results/ift_hci_master_dataset.json).Path
$env:PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH = 'C:/Program Files/Google/Chrome/Application/chrome.exe'
$env:JAIT_FOLLOWUP_ARM = 'baseline'
npx playwright test tests/ift_foraging_audit.spec.ts
$env:JAIT_FOLLOWUP_ARM = 'no-density'
npx playwright test tests/ift_foraging_audit.spec.ts
```

The two result folders are written under `tests/` by the pilot. The installed Playwright runner and Google Chrome are separate from the archived scan environment. Future live outcomes can change.

## Paired replay with frozen page inputs

Start from the original, unpatched simulator source. Use Node 24 and the dependencies in the project lockfile. The cohort consists of all nine archived sites above the home-page density threshold. Capture starts at each recorded resolved URL in a 1366 x 768 desktop viewport. It stores the simulator's extracted page inputs, requested and resolved URLs, navigation responses and status. The two arms share one prepared home state and one cached response per requested destination per site. Each new destination is captured in a fresh browser context. Offline replay uses the original task loop and thresholds, including the original direct-document rule. No browser launches in replay mode. A homepage without usable evidence removes all three pairs; a failed capture used by either arm removes the individual pair. An observed HTTP error is a recorded destination response. These data represent a new round, not the archived state of the 180 original attempts.

Run from the project root with the Chrome executable configured as in the pilot. Use a new folder name for a new capture.

```powershell
node paper_analysis_output/followup/paired_replay.cjs capture density-states
node paper_analysis_output/followup/paired_replay.cjs replay density-states
python paper_analysis_output/followup/summarize_paired_replay.py density-states
```

The CSV records all 27 planned pairs, outcomes, backtracks and first trace or selected-link differences for complete pairs. SHA-256 identifies the underlying site capture. Page inputs and complete traces are retained locally because they include excerpts from third-party sites. A new capture may yield different outcomes. To replay a saved capture, run only the last two commands against its directory.

Eight of nine sites supplied usable start pages. Of 27 planned pairs, 23 were evaluable: B26 had no homepage capture, and the A19 service-form task lacked a destination capture. The two arms completed the same 22 pairs, with six backtracks each and identical action and selected-link sequences throughout. The A30 service-form task failed under both arms. Offline replay reproduced the capture-run results byte for byte.
