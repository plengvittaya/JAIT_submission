"""Summarize paired replay results. No network calls."""
import csv
import json
import sys
from pathlib import Path

folder = Path(sys.argv[1])
dest = Path(__file__).parent
capture = json.loads((folder / "capture-results.json").read_bytes())
replay = json.loads((folder / "replay-results.json").read_bytes())
assert len(capture) == 9 and capture == replay
rows = []
for site in replay:
    pairs = {p["id"]: p for p in site["paired"]}
    missing = {p["id"]: p for p in site["missing"]}
    for task in ("T1_Contact", "T2_ServiceForm", "T3_Procurement_Plan"):
        row = dict(site=site["site"], task=task, state_sha256=site["stateSHA256"],
                   homepage_status=site["homeStatus"])
        rows.append(row)
        if task not in pairs:
            row["pair_status"] = "missing destination" if task in missing else "missing homepage"
            continue
        pair = pairs[task]
        a, b = pair["traces"]
        row.update(pair_status="paired", same_action_and_link_sequence=int(a == b), baseline_complete=int(pair["completed"][0]),
                   zero_complete=int(pair["completed"][1]), baseline_backtracks=pair["backtracks"][0],
                   zero_backtracks=pair["backtracks"][1])
        for i in range(max(len(a), len(b))):
            x = a[i] if i < len(a) else {}
            y = b[i] if i < len(b) else {}
            if x != y:
                row.update(first_different_step=i+1, baseline_action=x.get("action","END"),
                           zero_action=y.get("action","END"), baseline_href=x.get("href",""),
                           zero_href=y.get("href",""))
                break
        for i in range(min(len(a),len(b))):
            if a[i]["href"] != b[i]["href"]:
                row.update(first_different_href_step=i+1, baseline_different_href=a[i]["href"],
                           zero_different_href=b[i]["href"])
                break
fields = list(dict.fromkeys(k for row in rows for k in row))
with (dest / "paired_replay_tasks.csv").open("w",newline="",encoding="utf-8") as out:
    writer = csv.DictWriter(out,fields)
    writer.writeheader()
    writer.writerows(rows)
for r in rows:
    print(r["site"],r["task"],r["pair_status"],r.get("baseline_complete"),r.get("zero_complete"),
          r.get("baseline_backtracks"),r.get("zero_backtracks"),r.get("first_different_step","-"))

