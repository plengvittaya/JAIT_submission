// Node 24+, from the project root. Use a new directory for capture.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {stripTypeScriptTypes} = require('node:module');
const {chromium} = require('playwright');
const [mode,folder] = process.argv.slice(2);
if (!folder || !['capture','replay'].includes(mode)) throw Error('Expected capture|replay DIRECTORY');
const source = fs.readFileSync('tests/ift_foraging_audit.spec.ts','utf8').replace(/\r\n/g,'\n');
function section(start,end) {
  const a=source.indexOf(start), b=source.indexOf(end,a+start.length);
  if(a<0 || b<0) throw Error('Simulator source changed: '+start);
  return source.slice(a,b);
}
const api = section('type RegionType','test.describe(').replace('const densityPenalty = Math.min', 'const densityPenalty = disableDensity ? 0 : Math.min');
if(!api.includes('disableDensity ? 0')) throw Error('Density switch missing');
const loop = section('const taskResults: Record','const taskList = Object.values(taskResults)');
const live = section('const navRes = await safeNavigate(page, targetHref','if (!navRes.ok || !nextSnapshot');
const read = 'const {navRes, snapshot: nextSnapshot, actualUrl: actualNextUrl} = await lookup(targetHref, task.id);\n';
const setup = section('let homeSnapshot = await extractPageMetricsAndLinks(page);','let baseHost');
const program=api+'\nreturn {safeNavigate, extractPageMetricsAndLinks, prepare: async(page,resolvedUrl)=>{'+setup+'return {snapshot:homeSnapshot,actualUrl:resolvedUrl};}, run: async(homeSnapshot,resolvedUrl,lookup)=>{const baseHost=new URL(resolvedUrl).hostname;'+loop.replace(live,read)+'return taskResults;}}';
const makeEngine=new Function('return '+stripTypeScriptTypes('function engine(disableDensity){'+program+'}'))();
const engines=[makeEngine(false),makeEngine(true)];
const sites=JSON.parse(fs.readFileSync('ift_hci_results/ift_hci_master_dataset.json','utf8').replace(/^\uFEFF/,'')).sites.filter(s=>s.visualComplexity.linkDensityPer10kPx>0.35);
if(sites.length!==9) throw Error('Unexpected cohort');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
async function main() {
  let browser;
  if(mode==='capture'){
    fs.mkdirSync(folder,{recursive:false});
    browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH});
  }
  async function collect(site){
    const file=path.join(folder,site.siteId+'.json');
    const stash=mode==='capture'?{start:site.resolvedUrl,source:hash(source),time:new Date().toISOString(),pages:{}}:JSON.parse(fs.readFileSync(file));
    if(stash.source!==hash(source)||stash.start!==site.resolvedUrl) throw Error('Provenance mismatch');
    async function fetchState(url,home=false){
      const ctx=await browser.newContext({viewport:{width:1366,height:768},ignoreHTTPSErrors:true,serviceWorkers:'block',acceptDownloads:false,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'});
      try{
        await ctx.route('**/*',r=>['GET','HEAD'].includes(r.request().method())?r.continue():r.abort());
        const page=await ctx.newPage(), responses=[];
        page.on('response',r=>{if(r.request().isNavigationRequest()&&r.frame()===page.mainFrame()) responses.push([r.url(),r.status()]);});
        const navRes=await engines[0].safeNavigate(page,url,home?15000:11000);
        let state={actualUrl:page.url(),snapshot:null};
        if(navRes.ok && navRes.status<400) state=home?await engines[0].prepare(page,page.url()):{actualUrl:page.url(),snapshot:await engines[0].extractPageMetricsAndLinks(page)};
        return {...state,navRes,responses,missing:!navRes.ok||!responses.length||(navRes.status<400&&!state.snapshot?.totalDomNodes)};
      }finally{await ctx.close();}
    }
    if(mode==='capture') stash.home=await fetchState(site.resolvedUrl,true);
    const out={site:site.siteId,homeStatus:stash.home.navRes.status,paired:[],missing:[]};
    if(stash.home.snapshot?.totalDomNodes && !stash.home.missing){
      const missing=new Map(), arms=[];
      for(const engine of engines){
        const lookup=async(url,id)=>{
          if(!Object.hasOwn(stash.pages,url)){
            if(mode==='replay') throw Error('Absent replay key '+url);
            stash.pages[url]=await fetchState(url);
          }
          const p=stash.pages[url];
          if(p.missing){if(!missing.has(id))missing.set(id,new Set());missing.get(id).add(url);}
          return p;
        };
        arms.push(await engine.run(stash.home.snapshot,stash.home.actualUrl,lookup));
      }
      for(const id of Object.keys(arms[0])){
        if(missing.has(id)){out.missing.push({id,urls:[...missing.get(id)]});continue;}
        const pair=arms.map(a=>a[id]);
        const traces=pair.map(t=>t.decisionLogs.map(d=>({action:d.action,href:d.selectedHref,source:d.currentUrl})));
        out.paired.push({id,completed:pair.map(t=>t.taskCompleted),backtracks:pair.map(t=>t.backtrackCount),traces});
      }
    }
    if(mode==='capture') fs.writeFileSync(file,JSON.stringify(stash));
    out.stateSHA256=hash(fs.readFileSync(file));
    return out;
  }
  try{
    const results=[];
    for(let i=0;i<sites.length;i+=3) results.push(...await Promise.all(sites.slice(i,i+3).map(collect)));
    fs.writeFileSync(path.join(folder,mode+'-results.json'),JSON.stringify(results,null,2));
  }finally{await browser?.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});

