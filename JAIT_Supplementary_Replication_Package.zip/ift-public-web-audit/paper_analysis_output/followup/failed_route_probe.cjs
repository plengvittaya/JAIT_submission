const fs = require('node:fs');
const { chromium } = require('playwright');
const data = JSON.parse(fs.readFileSync('ift_hci_results/ift_hci_master_dataset.json','utf8'));
const patterns = { T1_Contact:/ติดต่อ|ช่องทางการติดต่อ|contact|ที่ตั้ง/i, T2_ServiceForm:/ดาวน์โหลดแบบฟอร์ม|แบบฟอร์ม|คู่มือประชาชน|บริการประชาชน|e.service|downloads/i, T3_Procurement_Plan:/แผน.{0,15}(จัดซื้อ|จัดจ้าง)|จัดซื้อจัดจ้าง|procurement/i };
(async()=>{
 const browser = await chromium.launch({channel:'chrome'});
 const cases = [];
 try {
 for(const site of data.sites){
  const tasks = Object.entries(site.tasks).filter(([,t])=>!t.taskCompleted);
  if(!tasks.length) continue;
  const context=await browser.newContext({ignoreHTTPSErrors:true});
  await context.route('**/*',route=>['GET','HEAD'].includes(route.request().method()) && !['image','media','font'].includes(route.request().resourceType()) ? route.continue() : route.abort());
  const page=await context.newPage();
  async function inspect(url){
   try {
    const resp=await page.goto(url,{waitUntil:'domcontentloaded',timeout:8500});
    await page.locator('body').waitFor({timeout:1800});
    return {url:page.url(),status:resp?.status(),...await page.evaluate(()=>({
     title:document.title, heading:Array.from(document.querySelectorAll('h1,h2,h3')).map(x=>x.textContent.trim()).slice(0,14),
     links:Array.from(document.querySelectorAll('a[href]')).map(a=>({label:(a.innerText || a.getAttribute('aria-label') || a.title || '').trim().replace(/\s+/g,' '),url:a.href})).filter(a=>a.label&&/^https?:/.test(a.url)),
     body:(document.body.innerText||'').replace(/\s+/g,' ').slice(0,11000)
    }))};
   } catch(e){return {url,error:String(e).split('\n')[0]};}
  }
  const home=await inspect(site.resolvedUrl);
  const root = /^https?:/.test(home.url) ? new URL(home.url).hostname.replace(/^www\./,'') : '';
  const seen = new Map();
  for(const [task] of tasks){
   const pattern=patterns[task];
   const same=(link)=>new URL(link.url).hostname.replace(/^www\./,'')===root && link.url.split('#')[0]!==home.url.split('#')[0];
   const links=(home.links||[]).filter(a=>same(a) && pattern.test(a.label));
   const results=[];
   for(const l of [...new Map(links.map(a=>[a.url,a])).values()].slice(0,3)){
    if(!seen.has(l.url)) seen.set(l.url,await inspect(l.url));
    const {links:out,...evidence}=seen.get(l.url);
    results.push({link:l,...evidence,evidenceLinks:(out||[]).filter(a=>pattern.test(a.label)).slice(0,8)});
   }
   const {links:ignored,...homeEvidence}=home;
   cases.push({siteId:site.siteId,task,archivedStart:site.resolvedUrl,home:homeEvidence,results});
  }
  await context.close();
  fs.writeFileSync('failure-candidates.local.json',JSON.stringify(cases,null,2));
  console.log(site.siteId,home.status||home.error,tasks.length);
 }
 } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});

