import { test, Page } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

type RegionType = 'Central_National' | 'North' | 'Northeast' | 'Central_East' | 'South';
type LocalTierType = 'Central_Agency' | 'Large_City_PAO' | 'Medium_Town' | 'Small_Subdistrict';

interface CandidateEndpoint {
  url: string;
  name?: string;
  province?: string;
}

interface TargetSite {
  id: string;
  name: string;
  group: 'Group_A_Central' | 'Group_B_Regional';
  region: RegionType;
  localTier: LocalTierType;
  province: string;
  urls: string[];
  candidates?: CandidateEndpoint[];
}

interface ScentComponents {
  lexicalScent: number;
  urlScent: number;
  salienceBonus: number;
  clutterPenalty: number;
}

interface DecisionLog {
  step: number;
  currentUrl: string;
  action: 'CLICK' | 'BACKTRACK' | 'LOOP_DETECTED' | 'GOAL_REACHED' | 'PATCH_EXHAUSTED';
  decisionMode: 'LLM-Agent' | 'IFT-Cognitive-Agent';
  selectedText: string;
  selectedHref: string;
  scentScore: number;
  scentComponents: ScentComponents;
  candidateCount: number;
  reasoning: string;
}

interface TaskResult {
  taskId: 'T1_Contact' | 'T2_ServiceForm' | 'T3_Procurement_Plan';
  taskName: string;
  difficulty: 'Shallow' | 'Medium' | 'Deep';
  taskCompleted: boolean;
  clickDepth: number;
  totalSteps: number;
  backtrackCount: number;
  backtrackRate: number;
  loopCount: number;
  avgScentScore: number;
  initialPatchMaxScent: number;
  completionTimeMs: number;
  terminationReason: 'GOAL_REACHED' | 'MAX_STEPS_EXCEEDED' | 'LOW_SCENT_ABANDONED' | 'NAVIGATION_ERROR';
  finalUrl: string;
  decisionLogs: DecisionLog[];
}

interface SiteAuditRecord {
  siteId: string;
  siteName: string;
  group: 'Group_A_Central' | 'Group_B_Regional';
  region: RegionType;
  localTier: LocalTierType;
  province: string;
  requestedUrl: string;
  resolvedUrl: string;
  reachable: boolean;
  httpStatus: number;
  loadTimeMs: number;
  hasSplashPage: boolean;
  visualComplexity: {
    aboveTheFoldLinks: number;
    totalVisibleLinks: number;
    viewportAreaPx: number;
    linkDensityPer10kPx: number;
    totalDomNodes: number;
    textToDomRatio: number;
    ambiguousLinkRatio: number;
  };
  foragingSummary: {
    TCR: number;
    tasksCompletedCount: number;
    avgClickDepth: number;
    totalBacktrackCount: number;
    avgBacktrackCount: number;
    backtrackRate: number;
    totalLoopCount: number;
    avgScentScore: number;
  };
  tasks: Record<string, TaskResult>;
  auditedAt: string;
}

const TARGET_SITES: TargetSite[] = [
  // ================= GROUP A: CENTRAL AGENCIES (30 SITES) =================
  {
    id: 'A01',
    name: 'Royal Thai Government (thaigov.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.thaigov.go.th', 'https://www.opm.go.th'],
  },
  {
    id: 'A02',
    name: 'Digital Government Development Agency (dga.or.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.dga.or.th', 'https://standard.dga.or.th'],
  },
  {
    id: 'A03',
    name: 'Ministry of Finance (mof.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.mof.go.th', 'https://www.cgd.go.th'],
  },
  {
    id: 'A04',
    name: 'The Revenue Department (rd.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.rd.go.th'],
  },
  {
    id: 'A05',
    name: 'Ministry of Interior (moi.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.moi.go.th', 'https://www.dopa.go.th'],
  },
  {
    id: 'A06',
    name: 'Department of Provincial Administration (dopa.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.dopa.go.th'],
  },
  {
    id: 'A07',
    name: 'Ministry of Public Health (moph.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.moph.go.th'],
  },
  {
    id: 'A08',
    name: 'Ministry of Digital Economy and Society (mdes.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.mdes.go.th'],
  },
  {
    id: 'A09',
    name: 'Ministry of Education (moe.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.moe.go.th'],
  },
  {
    id: 'A10',
    name: 'Ministry of Commerce (moc.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.moc.go.th', 'https://www.dbd.go.th'],
  },
  {
    id: 'A11',
    name: 'Ministry of Transport (mot.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.mot.go.th', 'https://www.dlt.go.th'],
  },
  {
    id: 'A12',
    name: 'Ministry of Labour (mol.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.mol.go.th'],
  },
  {
    id: 'A13',
    name: 'Social Security Office (sso.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.sso.go.th', 'https://www.m-society.go.th'],
  },
  {
    id: 'A14',
    name: 'Ministry of Justice (moj.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.moj.go.th'],
  },
  {
    id: 'A15',
    name: 'Office of the Consumer Protection Board (ocpb.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.ocpb.go.th', 'https://www.mnre.go.th', 'https://www.moac.go.th'],
  },
  {
    id: 'A16',
    name: 'Ministry of Agriculture and Cooperatives (moac.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.moac.go.th', 'https://www.doae.go.th'],
    candidates: [
      { url: 'https://www.moac.go.th' },
      { url: 'https://www.doae.go.th', name: 'Department of Agricultural Extension (doae.go.th)' },
    ],
  },
  {
    id: 'A17',
    name: 'Ministry of Foreign Affairs (mfa.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.mfa.go.th', 'https://consular.mfa.go.th'],
    candidates: [
      { url: 'https://www.mfa.go.th' },
      { url: 'https://consular.mfa.go.th', name: 'Department of Consular Affairs (consular.mfa.go.th)' },
    ],
  },
  {
    id: 'A18',
    name: 'Ministry of Natural Resources and Environment (mnre.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.mnre.go.th', 'https://www.pcd.go.th'],
    candidates: [
      { url: 'https://www.mnre.go.th' },
      { url: 'https://www.pcd.go.th', name: 'Pollution Control Department (pcd.go.th)' },
    ],
  },
  {
    id: 'A19',
    name: 'Ministry of Social Development and Human Security (m-society.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.m-society.go.th', 'https://www.dop.go.th'],
    candidates: [
      { url: 'https://www.m-society.go.th' },
      { url: 'https://www.dop.go.th', name: 'Department of Older Persons (dop.go.th)' },
    ],
  },
  {
    id: 'A20',
    name: 'Ministry of Industry (industry.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.industry.go.th', 'https://www.diw.go.th'],
    candidates: [
      { url: 'https://www.industry.go.th' },
      { url: 'https://www.diw.go.th', name: 'Department of Industrial Works (diw.go.th)' },
    ],
  },
  {
    id: 'A21',
    name: 'Ministry of Tourism and Sports (mots.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.mots.go.th', 'https://www.dot.go.th'],
    candidates: [
      { url: 'https://www.mots.go.th' },
      { url: 'https://www.dot.go.th', name: 'Department of Tourism (dot.go.th)' },
    ],
  },
  {
    id: 'A22',
    name: 'Ministry of Culture (m-culture.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.m-culture.go.th', 'https://www.finearts.go.th'],
    candidates: [
      { url: 'https://www.m-culture.go.th' },
      { url: 'https://www.finearts.go.th', name: 'Fine Arts Department (finearts.go.th)' },
    ],
  },
  {
    id: 'A23',
    name: 'Ministry of Energy (energy.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://energy.go.th', 'https://www.dede.go.th'],
    candidates: [
      { url: 'https://energy.go.th' },
      { url: 'https://www.dede.go.th', name: 'Department of Alternative Energy Development and Efficiency (dede.go.th)' },
    ],
  },
  {
    id: 'A24',
    name: 'Department of Business Development (dbd.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.dbd.go.th', 'https://www.ditp.go.th'],
    candidates: [
      { url: 'https://www.dbd.go.th' },
      { url: 'https://www.ditp.go.th', name: 'Department of International Trade Promotion (ditp.go.th)' },
    ],
  },
  {
    id: 'A25',
    name: 'Department of Land Transport (dlt.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.dlt.go.th', 'https://www.doh.go.th'],
    candidates: [
      { url: 'https://www.dlt.go.th' },
      { url: 'https://www.doh.go.th', name: 'Department of Highways (doh.go.th)' },
    ],
  },
  {
    id: 'A26',
    name: "The Comptroller General's Department (cgd.go.th)",
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.cgd.go.th', 'https://www.treasury.go.th'],
    candidates: [
      { url: 'https://www.cgd.go.th' },
      { url: 'https://www.treasury.go.th', name: 'The Treasury Department (treasury.go.th)' },
    ],
  },
  {
    id: 'A27',
    name: 'Thailand Board of Investment (boi.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.boi.go.th', 'https://www.nesdc.go.th'],
    candidates: [
      { url: 'https://www.boi.go.th' },
      { url: 'https://www.nesdc.go.th', name: 'Office of the National Economic and Social Development Council (nesdc.go.th)' },
    ],
  },
  {
    id: 'A28',
    name: 'Thai Meteorological Department (tmd.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.tmd.go.th', 'https://www.onwr.go.th'],
    candidates: [
      { url: 'https://www.tmd.go.th' },
      { url: 'https://www.onwr.go.th', name: 'Office of the National Water Resources (onwr.go.th)' },
    ],
  },
  {
    id: 'A29',
    name: 'National Statistical Office (nso.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.nso.go.th', 'https://www.onde.go.th'],
    candidates: [
      { url: 'https://www.nso.go.th' },
      { url: 'https://www.onde.go.th', name: 'Office of the National Digital Economy and Society Commission (onde.go.th)' },
    ],
  },
  {
    id: 'A30',
    name: 'The Customs Department (customs.go.th)',
    group: 'Group_A_Central',
    region: 'Central_National',
    localTier: 'Central_Agency',
    province: 'Bangkok (Central)',
    urls: ['https://www.customs.go.th', 'https://www.excise.go.th'],
    candidates: [
      { url: 'https://www.customs.go.th' },
      { url: 'https://www.excise.go.th', name: 'The Excise Department (excise.go.th)' },
    ],
  },

  // ================= GROUP B: LOCAL GOVERNMENTS ACROSS 4 REGIONS (30 SITES: 10 LARGE CITY/PAO, 10 MEDIUM TOWN, 10 SMALL SUBDISTRICT) =================
  {
    id: 'B01',
    name: 'Phayao Provincial Administrative Organization (py-pao.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Large_City_PAO',
    province: 'Phayao',
    urls: ['https://www.py-pao.go.th', 'http://www.py-pao.go.th'],
  },
  {
    id: 'B02',
    name: 'Phayao Town Municipality (phayaocity.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Medium_Town',
    province: 'Phayao',
    urls: ['https://phayaocity.go.th', 'http://phayaocity.go.th'],
  },
  {
    id: 'B03',
    name: 'Dok Khamtai Town Municipality (tessabandokkhamtai.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Medium_Town',
    province: 'Phayao',
    urls: ['https://tessabandokkhamtai.go.th', 'https://www.dokkhamtai.go.th'],
  },
  {
    id: 'B04',
    name: 'Mae Ka Subdistrict Municipality (maekalocal.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Small_Subdistrict',
    province: 'Phayao',
    urls: ['http://www.maekalocal.go.th', 'https://www.maekalocal.go.th'],
  },
  {
    id: 'B05',
    name: 'Ban Tam Subdistrict Municipality (bantamlocal.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Small_Subdistrict',
    province: 'Phayao',
    urls: ['https://www.bantamlocal.go.th', 'http://www.bantamlocal.go.th'],
  },
  {
    id: 'B06',
    name: 'Na Kham Subdistrict Municipality (nakham-kk.go.th)',
    group: 'Group_B_Regional',
    region: 'Northeast',
    localTier: 'Small_Subdistrict',
    province: 'Khon Kaen',
    urls: ['https://www.nakham-kk.go.th', 'http://www.nakham-kk.go.th', 'https://www.ubol.go.th'],
    candidates: [
      { url: 'https://www.nakham-kk.go.th' },
      { url: 'http://www.nakham-kk.go.th' },
      { url: 'https://www.ubol.go.th', name: 'Ubon Subdistrict Municipality (ubol.go.th)', province: 'Ubon Ratchathani' },
    ],
  },
  {
    id: 'B07',
    name: 'Pong Subdistrict Municipality (tessabantambonpong.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Small_Subdistrict',
    province: 'Phayao',
    urls: ['https://www.tessabantambonpong.go.th', 'http://www.tessabantambonpong.go.th'],
  },
  {
    id: 'B08',
    name: 'Nong Khon Kwang Subdistrict Municipality (nongkhonkwanglocal.go.th)',
    group: 'Group_B_Regional',
    region: 'Northeast',
    localTier: 'Small_Subdistrict',
    province: 'Udon Thani',
    urls: ['https://www.nongkhonkwanglocal.go.th', 'http://www.nongkhonkwanglocal.go.th', 'https://www.ubol.go.th'],
    candidates: [
      { url: 'https://www.nongkhonkwanglocal.go.th' },
      { url: 'http://www.nongkhonkwanglocal.go.th' },
      { url: 'https://www.ubol.go.th', name: 'Ubon Subdistrict Municipality (ubol.go.th)', province: 'Ubon Ratchathani' },
    ],
  },
  {
    id: 'B09',
    name: 'Chiang Rai Provincial Administrative Organization (chiangraipao.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Large_City_PAO',
    province: 'Chiang Rai',
    urls: ['https://www.chiangraipao.go.th', 'http://www.chiangraipao.go.th'],
  },
  {
    id: 'B10',
    name: 'Chiang Rai City Municipality (chiangraicity.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Large_City_PAO',
    province: 'Chiang Rai',
    urls: ['https://www.chiangraicity.go.th', 'http://www.chiangraicity.go.th'],
  },
  {
    id: 'B11',
    name: 'Mae Sai Subdistrict Municipality (maesai.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Small_Subdistrict',
    province: 'Chiang Rai',
    urls: ['https://www.maesai.go.th', 'http://www.maesai.go.th'],
  },
  {
    id: 'B12',
    name: 'Huay Kapi Subdistrict Municipality (huaykapi.go.th)',
    group: 'Group_B_Regional',
    region: 'Central_East',
    localTier: 'Small_Subdistrict',
    province: 'Chonburi',
    urls: ['https://www.huaykapi.go.th', 'http://www.huaykapi.go.th', 'https://www.mheung.go.th'],
    candidates: [
      { url: 'https://www.huaykapi.go.th' },
      { url: 'http://www.huaykapi.go.th' },
      { url: 'https://www.mheung.go.th', name: 'Mheung Subdistrict Municipality (mheung.go.th)', province: 'Chonburi' },
      { url: 'https://www.tessabannajomtien.go.th', name: 'Na Jomtien Subdistrict Municipality (tessabannajomtien.go.th)', province: 'Chonburi' },
    ],
  },
  {
    id: 'B13',
    name: 'Khlong Khwai Subdistrict Municipality (khlongkhwai.go.th)',
    group: 'Group_B_Regional',
    region: 'Central_East',
    localTier: 'Small_Subdistrict',
    province: 'Pathum Thani',
    urls: ['https://www.khlongkhwai.go.th', 'http://www.khlongkhwai.go.th', 'https://www.bangduea.go.th'],
    candidates: [
      { url: 'https://www.khlongkhwai.go.th' },
      { url: 'http://www.khlongkhwai.go.th' },
      { url: 'https://www.bangduea.go.th', name: 'Bang Duea Subdistrict Municipality (bangduea.go.th)', province: 'Pathum Thani' },
      { url: 'https://www.sunthornphu.go.th', name: 'Sunthornphu Subdistrict Municipality (sunthornphu.go.th)', province: 'Rayong' },
    ],
  },
  {
    id: 'B14',
    name: 'Wichit Subdistrict Municipality (phuket-vichit.go.th)',
    group: 'Group_B_Regional',
    region: 'South',
    localTier: 'Small_Subdistrict',
    province: 'Phuket',
    urls: ['https://www.phuket-vichit.go.th', 'http://www.phuket-vichit.go.th', 'https://www.srisunthon.go.th'],
    candidates: [
      { url: 'https://www.phuket-vichit.go.th' },
      { url: 'http://www.phuket-vichit.go.th' },
      { url: 'https://www.srisunthon.go.th', name: 'Si Sunthon Subdistrict Municipality (srisunthon.go.th)', province: 'Phuket' },
      { url: 'https://www.krabinoi.go.th', name: 'Krabi Noi Subdistrict Municipality (krabinoi.go.th)', province: 'Krabi' },
    ],
  },
  {
    id: 'B15',
    name: 'Sathing Phra Subdistrict Municipality (sathingpra.go.th)',
    group: 'Group_B_Regional',
    region: 'South',
    localTier: 'Small_Subdistrict',
    province: 'Songkhla',
    urls: ['https://www.sathingpra.go.th', 'http://www.sathingpra.go.th', 'https://www.chanacity.go.th'],
    candidates: [
      { url: 'https://www.sathingpra.go.th' },
      { url: 'http://www.sathingpra.go.th' },
      { url: 'https://www.chanacity.go.th', name: 'Chana Subdistrict Municipality (chanacity.go.th)', province: 'Songkhla' },
      { url: 'https://www.thachangcity.go.th', name: 'Tha Chang Subdistrict Municipality (thachangcity.go.th)', province: 'Surat Thani' },
    ],
  },
  // --- New 7 Large_City_PAO across North, Northeast, Central_East, South (Total Large_City_PAO = 10) ---
  {
    id: 'B16',
    name: 'Chiang Mai City Municipality (cmcity.go.th)',
    group: 'Group_B_Regional',
    region: 'North',
    localTier: 'Large_City_PAO',
    province: 'Chiang Mai',
    urls: ['https://www.cmcity.go.th', 'http://www.cmcity.go.th'],
    candidates: [
      { url: 'https://www.cmcity.go.th' },
      { url: 'http://www.cmcity.go.th' },
      { url: 'https://www.chiangmaipao.go.th', name: 'Chiang Mai PAO (chiangmaipao.go.th)', province: 'Chiang Mai' },
    ],
  },
  {
    id: 'B17',
    name: 'Khon Kaen City Municipality (kkmuni.go.th)',
    group: 'Group_B_Regional',
    region: 'Northeast',
    localTier: 'Large_City_PAO',
    province: 'Khon Kaen',
    urls: ['https://www.kkmuni.go.th', 'https://kkmuni.go.th'],
    candidates: [
      { url: 'https://www.kkmuni.go.th' },
      { url: 'https://kkmuni.go.th' },
      { url: 'http://www.kkmuni.go.th' },
      { url: 'https://www.kkpao.go.th', name: 'Khon Kaen PAO (kkpao.go.th)', province: 'Khon Kaen' },
    ],
  },
  {
    id: 'B18',
    name: 'Nakhon Ratchasima City Municipality (koratcity.go.th)',
    group: 'Group_B_Regional',
    region: 'Northeast',
    localTier: 'Large_City_PAO',
    province: 'Nakhon Ratchasima',
    urls: ['https://www.koratcity.go.th', 'http://www.koratcity.go.th'],
    candidates: [
      { url: 'https://www.koratcity.go.th' },
      { url: 'http://www.koratcity.go.th' },
      { url: 'https://www.koratpao.go.th', name: 'Nakhon Ratchasima PAO (koratpao.go.th)', province: 'Nakhon Ratchasima' },
    ],
  },
  {
    id: 'B19',
    name: 'Udon Thani City Municipality (udoncity.go.th)',
    group: 'Group_B_Regional',
    region: 'Northeast',
    localTier: 'Large_City_PAO',
    province: 'Udon Thani',
    urls: ['https://www.udoncity.go.th', 'http://www.udoncity.go.th'],
    candidates: [
      { url: 'https://www.udoncity.go.th' },
      { url: 'http://www.udoncity.go.th' },
      { url: 'https://www.udonpao.go.th', name: 'Udon Thani PAO (udonpao.go.th)', province: 'Udon Thani' },
      { url: 'https://www.uboncity.go.th', name: 'Ubon Ratchathani City Municipality (uboncity.go.th)', province: 'Ubon Ratchathani' },
    ],
  },
  {
    id: 'B20',
    name: 'Nonthaburi City Municipality (nakornnont.go.th)',
    group: 'Group_B_Regional',
    region: 'Central_East',
    localTier: 'Large_City_PAO',
    province: 'Nonthaburi',
    urls: ['https://www.nakornnont.go.th', 'http://www.nakornnont.go.th'],
    candidates: [
      { url: 'https://www.nakornnont.go.th' },
      { url: 'http://www.nakornnont.go.th' },
      { url: 'https://www.pakkretcity.go.th', name: 'Pak Kret City Municipality (pakkretcity.go.th)', province: 'Nonthaburi' },
    ],
  },
  {
    id: 'B21',
    name: 'Hat Yai City Municipality (hatyaicity.go.th)',
    group: 'Group_B_Regional',
    region: 'South',
    localTier: 'Large_City_PAO',
    province: 'Songkhla',
    urls: ['https://www.hatyaicity.go.th', 'http://www.hatyaicity.go.th'],
    candidates: [
      { url: 'https://www.hatyaicity.go.th' },
      { url: 'http://www.hatyaicity.go.th' },
      { url: 'https://www.suratcity.go.th', name: 'Surat Thani City Municipality (suratcity.go.th)', province: 'Surat Thani' },
    ],
  },
  {
    id: 'B22',
    name: 'Phuket City Municipality (phuketcity.go.th)',
    group: 'Group_B_Regional',
    region: 'South',
    localTier: 'Large_City_PAO',
    province: 'Phuket',
    urls: ['https://www.phuketcity.go.th', 'http://www.phuketcity.go.th'],
    candidates: [
      { url: 'https://www.phuketcity.go.th' },
      { url: 'http://www.phuketcity.go.th' },
      { url: 'https://www.trangcity.go.th', name: 'Trang City Municipality (trangcity.go.th)', province: 'Trang' },
      { url: 'https://www.nakhoncity.org', name: 'Nakhon Si Thammarat City Municipality (nakhoncity.org)', province: 'Nakhon Si Thammarat' },
    ],
  },
  // --- New 8 Medium_Town across Northeast, Central_East, South (Total Medium_Town = 10) ---
  {
    id: 'B23',
    name: 'Maha Sarakham Town Municipality (mkm.go.th)',
    group: 'Group_B_Regional',
    region: 'Northeast',
    localTier: 'Medium_Town',
    province: 'Maha Sarakham',
    urls: ['https://www.mkm.go.th', 'https://main.mkm.go.th'],
    candidates: [
      { url: 'https://www.mkm.go.th' },
      { url: 'https://main.mkm.go.th' },
      { url: 'http://www.mkm.go.th' },
      { url: 'https://www.nongkhaimunicipality.go.th', name: 'Nong Khai Town Municipality (nongkhaimunicipality.go.th)', province: 'Nong Khai' },
    ],
  },
  {
    id: 'B24',
    name: 'Roi Et Town Municipality (roietmunicipal.go.th)',
    group: 'Group_B_Regional',
    region: 'Northeast',
    localTier: 'Medium_Town',
    province: 'Roi Et',
    urls: ['https://roietmunicipal.go.th', 'https://www.roietmunicipal.go.th'],
    candidates: [
      { url: 'https://roietmunicipal.go.th' },
      { url: 'https://www.roietmunicipal.go.th' },
      { url: 'http://roietmunicipal.go.th' },
      { url: 'https://www.loeicity.go.th', name: 'Loei Town Municipality (loeicity.go.th)', province: 'Loei' },
    ],
  },
  {
    id: 'B25',
    name: 'Chonburi Town Municipality (chonburicity.go.th)',
    group: 'Group_B_Regional',
    region: 'Central_East',
    localTier: 'Medium_Town',
    province: 'Chonburi',
    urls: ['https://www.chonburicity.go.th', 'http://www.chonburicity.go.th'],
    candidates: [
      { url: 'https://www.chonburicity.go.th' },
      { url: 'http://www.chonburicity.go.th' },
      { url: 'https://www.tbmccs.go.th', name: 'Chachoengsao Town Municipality (tbmccs.go.th)', province: 'Chachoengsao' },
    ],
  },
  {
    id: 'B26',
    name: 'Saraburi Town Municipality (tmsbr.go.th)',
    group: 'Group_B_Regional',
    region: 'Central_East',
    localTier: 'Medium_Town',
    province: 'Saraburi',
    urls: ['https://www.tmsbr.go.th', 'http://www.tmsbr.go.th'],
    candidates: [
      { url: 'https://www.tmsbr.go.th' },
      { url: 'http://www.tmsbr.go.th' },
      { url: 'https://www.muangkancity.go.th', name: 'Kanchanaburi Town Municipality (muangkancity.go.th)', province: 'Kanchanaburi' },
    ],
  },
  {
    id: 'B27',
    name: 'Lopburi Town Municipality (lopburicity.go.th)',
    group: 'Group_B_Regional',
    region: 'Central_East',
    localTier: 'Medium_Town',
    province: 'Lopburi',
    urls: ['https://www.lopburicity.go.th', 'http://www.lopburicity.go.th'],
    candidates: [
      { url: 'https://www.lopburicity.go.th' },
      { url: 'http://www.lopburicity.go.th' },
      { url: 'https://www.songpeenongcity.go.th', name: 'Song Phi Nong Town Municipality (songpeenongcity.go.th)', province: 'Suphan Buri' },
      { url: 'https://www.tbmccs.go.th', name: 'Chachoengsao Town Municipality (tbmccs.go.th)', province: 'Chachoengsao' },
    ],
  },
  {
    id: 'B28',
    name: 'Krabi Town Municipality (krabicity.go.th)',
    group: 'Group_B_Regional',
    region: 'South',
    localTier: 'Medium_Town',
    province: 'Krabi',
    urls: ['https://www.krabicity.go.th', 'http://www.krabicity.go.th'],
    candidates: [
      { url: 'https://www.krabicity.go.th' },
      { url: 'http://www.krabicity.go.th' },
      { url: 'https://www.chumphontown.go.th', name: 'Chumphon Town Municipality (chumphontown.go.th)', province: 'Chumphon' },
    ],
  },
  {
    id: 'B29',
    name: 'Patong Town Municipality (patongcity.go.th)',
    group: 'Group_B_Regional',
    region: 'South',
    localTier: 'Medium_Town',
    province: 'Phuket',
    urls: ['https://www.patongcity.go.th', 'http://www.patongcity.go.th'],
    candidates: [
      { url: 'https://www.patongcity.go.th' },
      { url: 'http://www.patongcity.go.th' },
      { url: 'https://www.chumphontown.go.th', name: 'Chumphon Town Municipality (chumphontown.go.th)', province: 'Chumphon' },
    ],
  },
  {
    id: 'B30',
    name: 'Phatthalung Town Municipality (phatthalungcity.go.th)',
    group: 'Group_B_Regional',
    region: 'South',
    localTier: 'Medium_Town',
    province: 'Phatthalung',
    urls: ['https://www.phatthalungcity.go.th', 'http://www.phatthalungcity.go.th'],
    candidates: [
      { url: 'https://www.phatthalungcity.go.th' },
      { url: 'http://www.phatthalungcity.go.th' },
      { url: 'https://www.satuncity.go.th', name: 'Satun Town Municipality (satuncity.go.th)', province: 'Satun' },
    ],
  },
];

interface TaskConfig {
  id: 'T1_Contact' | 'T2_ServiceForm' | 'T3_Procurement_Plan';
  name: string;
  difficulty: 'Shallow' | 'Medium' | 'Deep';
  primaryKeywords: string[];
  secondaryKeywords: string[];
  urlTokens: string[];
  goalVerifyKeywords: string[];
  goalVerifyRegex: RegExp;
  patchLeaveThreshold: number;
}

const FORAGING_TASKS: TaskConfig[] = [
  {
    id: 'T1_Contact',
    name: 'Locating Official Contact Details, Phone Numbers, or Office Address',
    difficulty: 'Shallow',
    primaryKeywords: [
      'ติดต่อเรา',
      'ติดต่อหน่วยงาน',
      'ข้อมูลการติดต่อ',
      'ติดต่อสอบถาม',
      'ช่องทางการติดต่อ',
      'ที่อยู่หน่วยงาน',
      'แผนที่ตั้ง',
      'contact us',
      'contact',
    ],
    secondaryKeywords: [
      'ติดต่อ',
      'ที่อยู่',
      'โทรศัพท์',
      'เบอร์โทร',
      'แผนที่',
      'สายด่วน',
      'เกี่ยวกับเรา',
      'ข้อมูลพื้นฐาน',
      'ข้อมูลทั่วไป',
      'about',
      'location',
    ],
    urlTokens: ['contact', 'about', 'location', 'map', 'address', 'info', 'tel'],
    goalVerifyKeywords: ['โทรศัพท์', 'โทร', 'ที่อยู่', 'ถนน', 'ตำบล', 'อำเภอ', 'จังหวัด', 'รหัสไปรษณีย์', 'อีเมล', 'แผนที่', 'สายด่วน', 'โทรสาร', 'fax', 'email', 'tel'],
    goalVerifyRegex: /(0\d[-\s]?\d{3}[-\s]?\d{3,4}|0\d{2}[-\s]?\d{3}[-\s]?\d{3,4}|โทร\.?\s*0|รหัสไปรษณีย์\s*\d{5}|สายด่วน\s*\d{4}|@[a-zA-Z0-9.-]+\.(go|or)\.th)/i,
    patchLeaveThreshold: 0.28,
  },
  {
    id: 'T2_ServiceForm',
    name: 'Locating Online Citizen Services, Manuals, or Downloadable Official Forms',
    difficulty: 'Medium',
    primaryKeywords: [
      'คู่มือสำหรับประชาชน',
      'คู่มือประชาชน',
      'ดาวน์โหลดแบบฟอร์ม',
      'แบบฟอร์มคำร้อง',
      'บริการประชาชน',
      'บริการออนไลน์',
      'ระบบบริการออนไลน์',
      'e-service',
      'eservice',
      'citizen manual',
    ],
    secondaryKeywords: [
      'บริการ',
      'คู่มือ',
      'แบบฟอร์ม',
      'ดาวน์โหลด',
      'คำร้อง',
      'ยื่นคำร้อง',
      'จุดเดียวเบ็ดเสร็จ',
      'oss',
      'ข้อมูลบริการ',
      'เอกสารดาวน์โหลด',
      'service',
      'download',
      'form',
      'manual',
    ],
    urlTokens: ['service', 'eservice', 'e-service', 'manual', 'form', 'download', 'citizen', 'oss', 'document', 'doc'],
    goalVerifyKeywords: ['คู่มือ', 'แบบฟอร์ม', 'คำร้อง', 'ดาวน์โหลด', 'บริการประชาชน', 'บริการออนไลน์', 'ขั้นตอนการให้บริการ', 'เอกสาร', 'ยื่นคำขอ', 'e-service'],
    goalVerifyRegex: /(\.(pdf|doc|docx|xls|xlsx)|ดาวน์โหลด|แบบฟอร์ม|คู่มือสำหรับประชาชน|คู่มือประชาชน|คำร้อง|บริการออนไลน์|e-service)/i,
    patchLeaveThreshold: 0.30,
  },
  {
    id: 'T3_Procurement_Plan',
    name: 'Locating Procurement Announcements, Budgets, or Development Plans',
    difficulty: 'Deep',
    primaryKeywords: [
      'จัดซื้อจัดจ้าง',
      'ประกาศจัดซื้อจัดจ้าง',
      'ข่าวจัดซื้อจัดจ้าง',
      'ประกวดราคา',
      'ราคากลาง',
      'สรุปผลการจัดซื้อจัดจ้าง',
      'แผนการจัดซื้อจัดจ้าง',
      'แผนพัฒนาท้องถิ่น',
      'แผนปฏิบัติการ',
      'ข้อบัญญัติงบประมาณ',
      'งบประมาณรายจ่าย',
    ],
    secondaryKeywords: [
      'จัดซื้อ',
      'จัดจ้าง',
      'สอบราคา',
      'แผนงาน',
      'แผนพัฒนา',
      'งบประมาณ',
      'แผนการใช้จ่าย',
      'รายงานผล',
      'ita',
      'oit',
      'ความโปร่งใส',
      'ข่าวประกาศ',
      'ประชาสัมพันธ์',
      'procurement',
      'tender',
      'budget',
      'plan',
    ],
    urlTokens: ['procure', 'egp', 'tender', 'bid', 'budget', 'plan', 'ita', 'oit', 'announce', 'finance', 'supply'],
    goalVerifyKeywords: ['จัดซื้อจัดจ้าง', 'ประกวดราคา', 'ราคากลาง', 'สอบราคา', 'แผนพัฒนา', 'แผนปฏิบัติการ', 'งบประมาณ', 'ประจำปี', 'พ.ศ.', 'ประกาศ', 'โครงการ'],
    goalVerifyRegex: /(จัดซื้อจัดจ้าง|ประกวดราคา|ราคากลาง|แผนพัฒนา|แผนปฏิบัติการ|งบประมาณ|ประจำปี\s*(งบประมาณ)?\s*(พ\.ศ\.)?\s*256\d|e-gp|\.(pdf|xls|xlsx))/i,
    patchLeaveThreshold: 0.32,
  },
];

interface ExtractedCandidateLink {
  text: string;
  title: string;
  ariaLabel: string;
  href: string;
  inNavHeader: boolean;
  aboveFold: boolean;
  isAmbiguous: boolean;
  top: number;
  left: number;
}

interface PageExtractionResult {
  aboveTheFoldLinks: number;
  totalVisibleLinks: number;
  viewportAreaPx: number;
  linkDensityPer10kPx: number;
  totalDomNodes: number;
  textToDomRatio: number;
  ambiguousLinkRatio: number;
  hasSplashCta: boolean;
  splashCtaHref: string | null;
  splashCtaText: string | null;
  bodyTextSample: string;
  pageTitle: string;
  candidates: ExtractedCandidateLink[];
}

async function safeNavigate(page: Page, url: string, timeoutMs = 15000): Promise<{ ok: boolean; status: number }> {
  try {
    const resp = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: timeoutMs });
    await page.waitForLoadState('networkidle', { timeout: 3500 }).catch(() => {});
    await page.waitForTimeout(1200);
    return { ok: true, status: resp ? resp.status() : 200 };
  } catch (err: any) {
    const msg = String(err?.message || '');
    // Handle client-side redirect interruption (meta refresh / window.location redirect)
    if (msg.includes('interrupted by another navigation') || msg.includes('Execution context was destroyed')) {
      try {
        await page.waitForLoadState('networkidle', { timeout: 3500 }).catch(() => {});
        await page.waitForTimeout(1800);
        return { ok: true, status: 200 };
      } catch {
        return { ok: false, status: 0 };
      }
    }
    return { ok: false, status: 0 };
  }
}

async function extractPageMetricsAndLinks(page: Page): Promise<PageExtractionResult> {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await page.evaluate(() => {
        const vw = window.innerWidth || 1366;
        const vh = window.innerHeight || 768;
        const viewportAreaPx = vw * vh;
        const totalDomNodes = document.querySelectorAll('*').length;
        const bodyText = (document.body?.innerText || '').replace(/\s+/g, ' ').trim();
        const textToDomRatio = Number((bodyText.length / Math.max(1, totalDomNodes)).toFixed(4));

        const ambiguousTerms = new Set([
          '',
          'คลิก',
          'คลิกที่นี่',
          'กดที่นี่',
          'อ่านต่อ',
          'อ่านเพิ่มเติม',
          'รายละเอียด',
          'ดูรายละเอียด',
          'เพิ่มเติม',
          'ดูทั้งหมด',
          'ทั้งหมด',
          'เข้าชม',
          'ลิงก์',
          'click',
          'click here',
          'more',
          'read more',
          'detail',
          'details',
          'view',
          '...',
          '>>',
          '>',
        ]);

        const splashRegex =
          /(เข้าสู่เว็บไซต์|เข้าสู่หน้าหลัก|เข้าสู่ระบบเว็บไซต์|เข้าสู่เว็บไชต์|หน้าหลักเว็บไซต์|enter\s*site|enter\s*website|skip\s*intro)/i;

        const anchors = Array.from(document.querySelectorAll('a'));
        let aboveTheFoldLinks = 0;
        let totalVisibleLinks = 0;
        let ambiguousCount = 0;
        let hasSplashCta = false;
        let splashCtaHref: string | null = null;
        let splashCtaText: string | null = null;

        const candidates: ExtractedCandidateLink[] = [];
        const seenHrefs = new Set<string>();

        for (const a of anchors) {
          const style = window.getComputedStyle(a);
          if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity || '1') === 0) {
            continue;
          }
          const rect = a.getBoundingClientRect();
          if (rect.width <= 2 || rect.height <= 2) {
            continue;
          }

          totalVisibleLinks++;
          const isAboveFold = rect.top >= -10 && rect.top < vh && rect.left >= -10 && rect.left < vw;
          if (isAboveFold) {
            aboveTheFoldLinks++;
          }

          const rawText = (a.innerText || a.textContent || '').replace(/\s+/g, ' ').trim();
          const title = (a.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
          const ariaLabel = (a.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
          const imgAlt = (a.querySelector('img')?.getAttribute('alt') || '').replace(/\s+/g, ' ').trim();
          const effectiveText = rawText || ariaLabel || title || imgAlt;
          const normLabel = effectiveText.toLowerCase();

          const isAmbiguous =
            normLabel.length <= 1 ||
            ambiguousTerms.has(normLabel) ||
            /^(คลิก|อ่านต่อ|รายละเอียด|ดูทั้งหมด|more|click)$/i.test(normLabel);
          if (isAmbiguous) {
            ambiguousCount++;
          }

          const rawHref = a.getAttribute('href') || '';
          if (
            !rawHref ||
            rawHref.startsWith('#') ||
            rawHref.startsWith('javascript:') ||
            rawHref.startsWith('mailto:') ||
            rawHref.startsWith('tel:')
          ) {
            continue;
          }

          let resolvedHref = '';
          try {
            resolvedHref = new URL(rawHref, window.location.href).href;
          } catch {
            continue;
          }

          const currentBaseNoHash = window.location.href.split('#')[0];
          const resolvedNoHash = resolvedHref.split('#')[0];
          if (resolvedNoHash === currentBaseNoHash && resolvedHref.includes('#')) {
            continue;
          }

          const isSkipOrPolicyLink =
            /(skip|ข้ามไปยัง|cookie|คุกกี้|privacy|policy|นโยบายความเป็นส่วนตัว|royaloffice\.th)/i.test(
              `${effectiveText} ${title} ${ariaLabel} ${resolvedHref}`
            );

          if (
            !hasSplashCta &&
            !isSkipOrPolicyLink &&
            splashRegex.test(`${effectiveText} ${title} ${ariaLabel} ${imgAlt}`)
          ) {
            hasSplashCta = true;
            splashCtaHref = resolvedHref;
            splashCtaText = effectiveText || 'เข้าสู่เว็บไซต์';
          }

          const inNavHeader =
            Boolean(
              a.closest('nav, header, [role="navigation"], .nav, .navbar, .menu, .main-menu, .top-menu, #menu, #nav')
            ) || rect.top < 240;

          const dedupeKey = `${resolvedHref}::${effectiveText.slice(0, 40)}`;
          if (!seenHrefs.has(dedupeKey) && candidates.length < 220) {
            seenHrefs.add(dedupeKey);
            candidates.push({
              text: effectiveText.slice(0, 140),
              title: title.slice(0, 100),
              ariaLabel: ariaLabel.slice(0, 100),
              href: resolvedHref,
              inNavHeader,
              aboveFold: isAboveFold,
              isAmbiguous,
              top: Math.round(rect.top),
              left: Math.round(rect.left),
            });
          }
        }

        // Also detect minimal image-banner splash screen (exclude hash/cookie/policy/external links)
        if (!hasSplashCta && totalVisibleLinks <= 5 && candidates.length >= 1) {
          const validEntry = candidates.find((c) => {
            try {
              const targetUrl = new URL(c.href);
              const isNonEntry = /(cookie|คุกกี้|privacy|policy|นโยบาย|skip|ข้ามไปยัง|royaloffice\.th|facebook\.com|line\.me)/i.test(
                `${c.text} ${c.href}`
              );
              return !isNonEntry && targetUrl.hostname === window.location.hostname;
            } catch {
              return false;
            }
          });
          if (validEntry) {
            hasSplashCta = true;
            splashCtaHref = validEntry.href;
            splashCtaText = validEntry.text || '[Image Banner Splash Entry]';
          }
        }

        const linkDensityPer10kPx = Number(((aboveTheFoldLinks / Math.max(1, viewportAreaPx)) * 10000).toFixed(4));
        const ambiguousLinkRatio = Number((ambiguousCount / Math.max(1, totalVisibleLinks)).toFixed(4));

        return {
          aboveTheFoldLinks,
          totalVisibleLinks,
          viewportAreaPx,
          linkDensityPer10kPx,
          totalDomNodes,
          textToDomRatio,
          ambiguousLinkRatio,
          hasSplashCta: hasSplashCta && (totalVisibleLinks < 45 || aboveTheFoldLinks < 25),
          splashCtaHref,
          splashCtaText,
          bodyTextSample: bodyText.slice(0, 5000),
          pageTitle: document.title || '',
          candidates,
        };
      });
    } catch {
      await page.waitForTimeout(1500);
    }
  }
  return {
    aboveTheFoldLinks: 0,
    totalVisibleLinks: 0,
    viewportAreaPx: 1366 * 768,
    linkDensityPer10kPx: 0,
    totalDomNodes: 0,
    textToDomRatio: 0,
    ambiguousLinkRatio: 0,
    hasSplashCta: false,
    splashCtaHref: null,
    splashCtaText: null,
    bodyTextSample: '',
    pageTitle: '',
    candidates: [],
  };
}

function normalizeUrlForLoopCheck(u: string): string {
  try {
    const parsed = new URL(u);
    parsed.hash = '';
    return parsed.href.replace(/\/$/, '').toLowerCase();
  } catch {
    return u.toLowerCase();
  }
}

function computeCandidateScent(
  candidate: ExtractedCandidateLink,
  task: TaskConfig,
  pageMetrics: { linkDensityPer10kPx: number; ambiguousLinkRatio: number },
  baseHost: string
): { scentScore: number; components: ScentComponents; rationale: string } {
  const combinedText = `${candidate.text} ${candidate.title} ${candidate.ariaLabel}`.toLowerCase();
  const hrefLower = candidate.href.toLowerCase();

  let lexicalScent = 0.05;
  let matchedKeyword = '';

  for (const kw of task.primaryKeywords) {
    if (combinedText.includes(kw.toLowerCase())) {
      const lengthFactor = candidate.text.length <= 35 ? 1.0 : 0.88;
      lexicalScent = Math.max(lexicalScent, lengthFactor);
      matchedKeyword = kw;
      break;
    }
  }

  if (lexicalScent < 0.8) {
    for (const kw of task.secondaryKeywords) {
      if (combinedText.includes(kw.toLowerCase())) {
        const score = candidate.text.length <= 40 ? 0.62 : 0.48;
        if (score > lexicalScent) {
          lexicalScent = score;
          matchedKeyword = kw;
        }
      }
    }
  }

  if (
    lexicalScent <= 0.1 &&
    /(ข่าว|ประชาสัมพันธ์|กิจกรรม|ข้อมูลทั่วไป|เกี่ยวกับ|หน้าหลัก|รายละเอียด|อ่านต่อ)/i.test(combinedText)
  ) {
    lexicalScent = 0.24;
    matchedKeyword = matchedKeyword || 'distractor-general-cue';
  }

  let urlScent = 0.05;
  let matchedSlug = '';
  for (const token of task.urlTokens) {
    if (hrefLower.includes(token.toLowerCase())) {
      urlScent = 0.92;
      matchedSlug = token;
      break;
    }
  }
  if (urlScent < 0.5 && /\.(pdf|doc|docx|xls|xlsx)$/i.test(hrefLower) && task.id !== 'T1_Contact') {
    urlScent = 0.68;
    matchedSlug = 'document-file';
  }

  try {
    const candHost = new URL(candidate.href).hostname.replace(/^www\./, '');
    const rootHost = baseHost.replace(/^www\./, '');
    if (!candHost.endsWith(rootHost) && !rootHost.endsWith(candHost) && !candHost.endsWith('.go.th')) {
      urlScent *= 0.4;
    }
  } catch {
    // ignore
  }

  let salienceBonus = 0.20;
  if (candidate.inNavHeader && candidate.aboveFold) {
    salienceBonus = 0.95;
  } else if (candidate.inNavHeader || candidate.aboveFold) {
    salienceBonus = 0.65;
  }

  const densityPenalty = Math.min(0.22, Math.max(0, (pageMetrics.linkDensityPer10kPx - 0.35) * 0.24));
  const ambiguityPenalty = candidate.isAmbiguous ? 0.22 : pageMetrics.ambiguousLinkRatio * 0.12;
  const longTextPenalty = candidate.text.length > 85 ? 0.08 : 0;
  const clutterPenalty = Number(Math.min(0.38, densityPenalty + ambiguityPenalty + longTextPenalty).toFixed(4));

  const rawScore = 0.58 * lexicalScent + 0.18 * urlScent + 0.16 * salienceBonus + 0.08 - clutterPenalty;
  const scentScore = Number(Math.max(0.02, Math.min(0.99, rawScore)).toFixed(4));

  const components: ScentComponents = {
    lexicalScent: Number(lexicalScent.toFixed(4)),
    urlScent: Number(urlScent.toFixed(4)),
    salienceBonus: Number(salienceBonus.toFixed(4)),
    clutterPenalty,
  };

  const rationale = matchedKeyword
    ? `Matched cue '${matchedKeyword}'${matchedSlug ? ` + URL token '${matchedSlug}'` : ''} (lex=${components.lexicalScent}, url=${components.urlScent}, sal=${components.salienceBonus}, clutterPen=${components.clutterPenalty})`
    : `Weak lexical cue${matchedSlug ? ` with URL token '${matchedSlug}'` : ''} under visual density ${pageMetrics.linkDensityPer10kPx}/10kPx (clutterPen=${components.clutterPenalty})`;

  return { scentScore, components, rationale };
}

function verifyGoalReached(
  task: TaskConfig,
  pageData: PageExtractionResult,
  currentUrl: string,
  lastSelectedScent: number,
  lastSelectedText: string
): { reached: boolean; evidence: string } {
  const combinedContent = `${pageData.pageTitle} ${lastSelectedText} ${pageData.bodyTextSample}`.toLowerCase();
  const urlLower = currentUrl.toLowerCase();

  let keywordHits = 0;
  const matchedCues: string[] = [];
  for (const kw of task.goalVerifyKeywords) {
    if (combinedContent.includes(kw.toLowerCase())) {
      keywordHits++;
      if (matchedCues.length < 4) matchedCues.push(kw);
    }
  }

  const regexMatch = task.goalVerifyRegex.test(combinedContent) || task.goalVerifyRegex.test(urlLower);
  const urlTokenMatch = task.urlTokens.some((tok) => urlLower.includes(tok));
  const strongEntryScent = lastSelectedScent >= 0.50;

  if (task.id === 'T1_Contact') {
    const reached =
      strongEntryScent && ((keywordHits >= 2 && regexMatch) || (urlTokenMatch && keywordHits >= 2) || keywordHits >= 4);
    return {
      reached,
      evidence: reached
        ? `Verified Contact patch: matched [${matchedCues.join(', ')}] + contact pattern=${regexMatch}`
        : `Insufficient contact evidence on patch (hits=${keywordHits}, regex=${regexMatch}, entryScent=${lastSelectedScent})`,
    };
  }

  if (task.id === 'T2_ServiceForm') {
    const reached =
      strongEntryScent && ((keywordHits >= 2 && regexMatch) || (urlTokenMatch && keywordHits >= 2) || keywordHits >= 3);
    return {
      reached,
      evidence: reached
        ? `Verified Service/Form patch: matched [${matchedCues.join(', ')}] + form/manual indicator=${regexMatch}`
        : `Insufficient service/form evidence on patch (hits=${keywordHits}, regex=${regexMatch}, entryScent=${lastSelectedScent})`,
    };
  }

  const reached =
    strongEntryScent && ((keywordHits >= 2 && regexMatch) || (urlTokenMatch && keywordHits >= 2) || keywordHits >= 3);
  return {
    reached,
    evidence: reached
      ? `Verified Procurement/Plan patch: matched [${matchedCues.join(', ')}] + dated announcement/plan pattern=${regexMatch}`
      : `Insufficient procurement/plan evidence on patch (hits=${keywordHits}, regex=${regexMatch}, entryScent=${lastSelectedScent})`,
  };
}

test.describe('JAIT Computational Information Foraging Audit (N=60)', () => {
  test('Execute Visual Complexity & 3-Task Information Foraging across 60 Thai Gov Websites', async ({ browser }) => {
    const resultsDir = path.resolve(__dirname, '..', 'ift_hci_results');
    if (!fs.existsSync(resultsDir)) {
      fs.mkdirSync(resultsDir, { recursive: true });
    }
    const masterOutputPath = path.join(resultsDir, 'ift_hci_master_dataset.json');

    const allRecords: SiteAuditRecord[] = [];
    // Preserve verified de-confounded N=60 dataset cache on re-runs unless explicitly refreshed
    const forceReauditIds = new Set<string>();

    for (let idx = 0; idx < TARGET_SITES.length; idx++) {
      const site = TARGET_SITES[idx];
      const cachedFilePath = path.join(resultsDir, `${site.id}_foraging_result.json`);

      if (!forceReauditIds.has(site.id) && fs.existsSync(cachedFilePath)) {
        try {
          const cachedRecord = JSON.parse(fs.readFileSync(cachedFilePath, 'utf-8')) as SiteAuditRecord;
          if (cachedRecord && cachedRecord.reachable && cachedRecord.visualComplexity.totalDomNodes > 20) {
            if (cachedRecord.region !== site.region || cachedRecord.localTier !== site.localTier) {
              cachedRecord.region = site.region;
              cachedRecord.localTier = site.localTier;
              fs.writeFileSync(cachedFilePath, JSON.stringify(cachedRecord, null, 2), 'utf-8');
            }
            console.log(
              `[${idx + 1}/${TARGET_SITES.length}] Loaded cached result for ${site.id} (${cachedRecord.siteName}) [${site.localTier}]: TCR=${cachedRecord.foragingSummary.TCR}, BacktrackRate=${cachedRecord.foragingSummary.backtrackRate}`
            );
            allRecords.push(cachedRecord);
            continue;
          }
        } catch {
          // Proceed to live audit if cache read fails
        }
      }

      console.log(`\n[${idx + 1}/${TARGET_SITES.length}] Auditing ${site.id} (${site.group} | ${site.region} | ${site.localTier}): ${site.name}`);

      const context = await browser.newContext({
        viewport: { width: 1366, height: 768 },
        ignoreHTTPSErrors: true,
        userAgent:
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      });

      try {
        const page = await context.newPage();

        const candidateList: CandidateEndpoint[] = site.candidates ?? site.urls.map((url) => ({ url }));
        let reachable = false;
        let httpStatus = 0;
        let requestedUrl = candidateList[0].url;
        let resolvedUrl = candidateList[0].url;
        let actualSiteName = site.name;
        let actualProvince = site.province;
        let loadTimeMs = 0;

        for (const candidate of candidateList) {
          const candidateUrl = candidate.url;
          requestedUrl = candidateUrl;
          const t0 = Date.now();
          const navRes = await safeNavigate(page, candidateUrl, 15000);
          if (navRes.ok) {
            httpStatus = navRes.status;
            resolvedUrl = page.url();
            loadTimeMs = Date.now() - t0;
            const snap = await extractPageMetricsAndLinks(page);
            const isParkedServer =
              /your new web server is ready to use/i.test(snap.bodyTextSample) ||
              (snap.pageTitle.trim().toLowerCase() === 'success!' && snap.totalVisibleLinks === 0);
            if (!isParkedServer && snap.totalDomNodes > 12 && (snap.totalVisibleLinks > 0 || snap.totalDomNodes > 40)) {
              reachable = true;
              actualSiteName = candidate.name ?? site.name;
              actualProvince = candidate.province ?? site.province;
              console.log(
                `  -> Loaded ${candidateUrl} -> ${resolvedUrl} [${actualSiteName}] (HTTP ${httpStatus}, ${loadTimeMs}ms, DOM=${snap.totalDomNodes})`
              );
              break;
            }
            console.log(`  -> Fallback needed for ${candidateUrl} (parked/empty shell DOM=${snap.totalDomNodes}, Links=${snap.totalVisibleLinks})`);
          } else {
            console.log(`  -> Fallback needed for ${candidateUrl}`);
          }
        }

        if (!reachable) {
          console.log(`  [UNREACHABLE] ${site.id} (${site.name}) failed all ${candidateList.length} candidate URLs.`);
          continue;
        }

        let homeSnapshot = await extractPageMetricsAndLinks(page);
        let hasSplashPage = false;

        if (homeSnapshot.hasSplashCta && homeSnapshot.splashCtaHref) {
          hasSplashPage = true;
          console.log(
            `  -> Splash Page detected ('${homeSnapshot.splashCtaText}'). Bypassing to ${homeSnapshot.splashCtaHref}`
          );
          let bypassedByClick = false;
          try {
            const clickTarget = page
              .locator('a')
              .filter({ hasText: /(เข้าสู่เว็บไซต์|เข้าสู่หน้าหลัก|enter\s*site|enter\s*website|skip\s*intro)/i })
              .first();
            if ((await clickTarget.count()) > 0) {
              await Promise.all([
                page.waitForLoadState('domcontentloaded', { timeout: 10000 }).catch(() => {}),
                clickTarget.click({ timeout: 5000 }).catch(() => {}),
              ]);
              await page.waitForLoadState('networkidle', { timeout: 3000 }).catch(() => {});
              await page.waitForTimeout(1200);
              const postClickSnapshot = await extractPageMetricsAndLinks(page);
              if (postClickSnapshot.totalVisibleLinks > homeSnapshot.totalVisibleLinks) {
                resolvedUrl = page.url();
                homeSnapshot = postClickSnapshot;
                bypassedByClick = true;
              }
            }
          } catch {
            // Fall back to direct URL navigation below
          }
          if (!bypassedByClick) {
            const splashNav = await safeNavigate(page, homeSnapshot.splashCtaHref, 15000);
            if (splashNav.ok) {
              const postSplashSnapshot = await extractPageMetricsAndLinks(page);
              if (postSplashSnapshot.totalVisibleLinks >= homeSnapshot.totalVisibleLinks) {
                resolvedUrl = page.url();
                homeSnapshot = postSplashSnapshot;
              }
            }
          }
        }

        let baseHost = '';
        try {
          baseHost = new URL(resolvedUrl).hostname;
        } catch {
          baseHost = resolvedUrl;
        }

        const visualComplexity = {
          aboveTheFoldLinks: homeSnapshot.aboveTheFoldLinks,
          totalVisibleLinks: homeSnapshot.totalVisibleLinks,
          viewportAreaPx: homeSnapshot.viewportAreaPx,
          linkDensityPer10kPx: homeSnapshot.linkDensityPer10kPx,
          totalDomNodes: homeSnapshot.totalDomNodes,
          textToDomRatio: homeSnapshot.textToDomRatio,
          ambiguousLinkRatio: homeSnapshot.ambiguousLinkRatio,
        };

        console.log(
          `  -> Visual Complexity: ATF_Links=${visualComplexity.aboveTheFoldLinks}, Density=${visualComplexity.linkDensityPer10kPx}/10kPx, DOM=${visualComplexity.totalDomNodes}, AmbigRatio=${visualComplexity.ambiguousLinkRatio}`
        );

        const taskResults: Record<string, TaskResult> = {};

        for (const task of FORAGING_TASKS) {
          const taskStart = Date.now();
          const maxSteps = 5;
          let clickDepth = 0;
          let totalSteps = 0;
          let backtrackCount = 0;
          let loopCount = 0;
          let taskCompleted = false;
          let terminationReason: TaskResult['terminationReason'] = 'MAX_STEPS_EXCEEDED';

          const decisionLogs: DecisionLog[] = [];
          const scentHistory: number[] = [];
          const visitedUrls = new Set<string>([normalizeUrlForLoopCheck(resolvedUrl)]);
          const blacklistedHrefs = new Set<string>();
          const patchStack: { url: string; snapshot: PageExtractionResult }[] = [
            { url: resolvedUrl, snapshot: homeSnapshot },
          ];

          let initialPatchMaxScent = 0;

          for (let step = 1; step <= maxSteps; step++) {
            totalSteps = step;
            const currentPatch = patchStack[patchStack.length - 1];
            const currentSnapshot = currentPatch.snapshot;

            const scoredCandidates = currentSnapshot.candidates
              .filter((c) => !blacklistedHrefs.has(c.href))
              .map((c) => {
                const s = computeCandidateScent(c, task, currentSnapshot, baseHost);
                return {
                  candidate: c,
                  scentScore: s.scentScore,
                  components: s.components,
                  rationale: s.rationale,
                };
              })
              .sort((a, b) => b.scentScore - a.scentScore);

            if (step === 1 && scoredCandidates.length > 0) {
              initialPatchMaxScent = scoredCandidates[0].scentScore;
            }

            if (scoredCandidates.length === 0) {
              if (patchStack.length > 1) {
                backtrackCount++;
                const popped = patchStack.pop()!;
                const parentPatch = patchStack[patchStack.length - 1];
                decisionLogs.push({
                  step,
                  currentUrl: popped.url,
                  action: 'BACKTRACK',
                  decisionMode: 'IFT-Cognitive-Agent',
                  selectedText: '[Backtrack to parent hub]',
                  selectedHref: parentPatch.url,
                  scentScore: 0.05,
                  scentComponents: { lexicalScent: 0, urlScent: 0, salienceBonus: 0, clutterPenalty: 0 },
                  candidateCount: 0,
                  reasoning: `Patch exhausted (0 remaining viable candidates on ${popped.url}); agent backtracked to parent patch ${parentPatch.url}.`,
                });
                continue;
              } else {
                terminationReason = 'LOW_SCENT_ABANDONED';
                decisionLogs.push({
                  step,
                  currentUrl: currentPatch.url,
                  action: 'PATCH_EXHAUSTED',
                  decisionMode: 'IFT-Cognitive-Agent',
                  selectedText: 'NONE',
                  selectedHref: currentPatch.url,
                  scentScore: 0,
                  scentComponents: { lexicalScent: 0, urlScent: 0, salienceBonus: 0, clutterPenalty: 0 },
                  candidateCount: 0,
                  reasoning: `No navigable candidate links found on root portal patch.`,
                });
                break;
              }
            }

            const topChoice = scoredCandidates[0];
            scentHistory.push(topChoice.scentScore);

            if (patchStack.length > 1 && topChoice.scentScore < task.patchLeaveThreshold) {
              backtrackCount++;
              const abandonedPatch = patchStack.pop()!;
              const parentPatch = patchStack[patchStack.length - 1];
              decisionLogs.push({
                step,
                currentUrl: abandonedPatch.url,
                action: 'BACKTRACK',
                decisionMode: 'IFT-Cognitive-Agent',
                selectedText: topChoice.candidate.text || '[Low-Scent Interior Link]',
                selectedHref: parentPatch.url,
                scentScore: topChoice.scentScore,
                scentComponents: topChoice.components,
                candidateCount: scoredCandidates.length,
                reasoning: `Max candidate scent (${topChoice.scentScore}) on interior patch fell below IFT patch-leaving threshold (${task.patchLeaveThreshold}). Triggering BACKTRACK to ${parentPatch.url}.`,
              });
              continue;
            }

            blacklistedHrefs.add(topChoice.candidate.href);
            const targetHref = topChoice.candidate.href;
            const normTarget = normalizeUrlForLoopCheck(targetHref);

            if (visitedUrls.has(normTarget)) {
              loopCount++;
              backtrackCount++;
              decisionLogs.push({
                step,
                currentUrl: currentPatch.url,
                action: 'LOOP_DETECTED',
                decisionMode: 'IFT-Cognitive-Agent',
                selectedText: topChoice.candidate.text,
                selectedHref: targetHref,
                scentScore: topChoice.scentScore,
                scentComponents: topChoice.components,
                candidateCount: scoredCandidates.length,
                reasoning: `Candidate '${topChoice.candidate.text}' resolved to previously visited URL (${targetHref}), causing a navigation loop. Agent logged loop & backtracked to evaluate alternative links.`,
              });
              continue;
            }

            if (/\.(pdf|doc|docx|xls|xlsx|zip)(\?.*)?$/i.test(targetHref)) {
              clickDepth++;
              visitedUrls.add(normTarget);
              if (topChoice.scentScore >= 0.48 && task.id !== 'T1_Contact') {
                taskCompleted = true;
                terminationReason = 'GOAL_REACHED';
                decisionLogs.push({
                  step,
                  currentUrl: currentPatch.url,
                  action: 'GOAL_REACHED',
                  decisionMode: 'IFT-Cognitive-Agent',
                  selectedText: topChoice.candidate.text,
                  selectedHref: targetHref,
                  scentScore: topChoice.scentScore,
                  scentComponents: topChoice.components,
                  candidateCount: scoredCandidates.length,
                  reasoning: `${topChoice.rationale}. Direct official document link reached (${targetHref}); foraging goal satisfied at clickDepth=${clickDepth}.`,
                });
                break;
              } else {
                backtrackCount++;
                decisionLogs.push({
                  step,
                  currentUrl: currentPatch.url,
                  action: 'BACKTRACK',
                  decisionMode: 'IFT-Cognitive-Agent',
                  selectedText: topChoice.candidate.text,
                  selectedHref: targetHref,
                  scentScore: topChoice.scentScore,
                  scentComponents: topChoice.components,
                  candidateCount: scoredCandidates.length,
                  reasoning: `Document link (${targetHref}) had low task specificity (scent=${topChoice.scentScore}); agent backtracked to parent patch.`,
                });
                continue;
              }
            }

            clickDepth++;
            const navRes = await safeNavigate(page, targetHref, 11000);
            let nextSnapshot: PageExtractionResult | null = null;
            let actualNextUrl = targetHref;

            if (navRes.ok) {
              actualNextUrl = page.url();
              nextSnapshot = await extractPageMetricsAndLinks(page);
            }

            if (!navRes.ok || !nextSnapshot || nextSnapshot.totalDomNodes <= 10) {
              backtrackCount++;
              decisionLogs.push({
                step,
                currentUrl: currentPatch.url,
                action: 'BACKTRACK',
                decisionMode: 'IFT-Cognitive-Agent',
                selectedText: topChoice.candidate.text,
                selectedHref: targetHref,
                scentScore: topChoice.scentScore,
                scentComponents: topChoice.components,
                candidateCount: scoredCandidates.length,
                reasoning: `Navigation to '${topChoice.candidate.text}' (${targetHref}) timed out or returned broken patch; agent executed BACKTRACK to ${currentPatch.url}.`,
              });
              continue;
            }

            const normActual = normalizeUrlForLoopCheck(actualNextUrl);
            if (visitedUrls.has(normActual) && normActual === normalizeUrlForLoopCheck(currentPatch.url)) {
              loopCount++;
              backtrackCount++;
              decisionLogs.push({
                step,
                currentUrl: currentPatch.url,
                action: 'LOOP_DETECTED',
                decisionMode: 'IFT-Cognitive-Agent',
                selectedText: topChoice.candidate.text,
                selectedHref: targetHref,
                scentScore: topChoice.scentScore,
                scentComponents: topChoice.components,
                candidateCount: scoredCandidates.length,
                reasoning: `Redirect loop detected: '${topChoice.candidate.text}' redirected back to visited patch ${actualNextUrl}. Agent incremented loopCount & backtracked.`,
              });
              continue;
            }

            visitedUrls.add(normActual);

            const goalCheck = verifyGoalReached(
              task,
              nextSnapshot,
              actualNextUrl,
              topChoice.scentScore,
              topChoice.candidate.text
            );

            if (goalCheck.reached) {
              taskCompleted = true;
              terminationReason = 'GOAL_REACHED';
              decisionLogs.push({
                step,
                currentUrl: actualNextUrl,
                action: 'GOAL_REACHED',
                decisionMode: 'IFT-Cognitive-Agent',
                selectedText: topChoice.candidate.text,
                selectedHref: targetHref,
                scentScore: topChoice.scentScore,
                scentComponents: topChoice.components,
                candidateCount: scoredCandidates.length,
                reasoning: `${topChoice.rationale}. ${goalCheck.evidence}`,
              });
              break;
            }

            if (topChoice.scentScore < 0.46) {
              backtrackCount++;
              decisionLogs.push({
                step,
                currentUrl: actualNextUrl,
                action: 'BACKTRACK',
                decisionMode: 'IFT-Cognitive-Agent',
                selectedText: topChoice.candidate.text,
                selectedHref: targetHref,
                scentScore: topChoice.scentScore,
                scentComponents: topChoice.components,
                candidateCount: scoredCandidates.length,
                reasoning: `${topChoice.rationale}. ${goalCheck.evidence}. Sub-optimal patch scent (${topChoice.scentScore} < 0.46) triggered IFT BACKTRACK from ${actualNextUrl} to hub.`,
              });
            } else {
              patchStack.push({ url: actualNextUrl, snapshot: nextSnapshot });
              decisionLogs.push({
                step,
                currentUrl: currentPatch.url,
                action: 'CLICK',
                decisionMode: 'IFT-Cognitive-Agent',
                selectedText: topChoice.candidate.text,
                selectedHref: targetHref,
                scentScore: topChoice.scentScore,
                scentComponents: topChoice.components,
                candidateCount: scoredCandidates.length,
                reasoning: `${topChoice.rationale}. Advancing deeper to intermediate patch ${actualNextUrl} (${nextSnapshot.candidates.length} outgoing links).`,
              });
            }
          }

          const avgScentScore =
            scentHistory.length > 0
              ? Number((scentHistory.reduce((a, b) => a + b, 0) / scentHistory.length).toFixed(4))
              : 0;
          const backtrackRate = Number((backtrackCount / Math.max(1, totalSteps)).toFixed(4));

          taskResults[task.id] = {
            taskId: task.id,
            taskName: task.name,
            difficulty: task.difficulty,
            taskCompleted,
            clickDepth,
            totalSteps,
            backtrackCount,
            backtrackRate,
            loopCount,
            avgScentScore,
            initialPatchMaxScent,
            completionTimeMs: Date.now() - taskStart,
            terminationReason,
            finalUrl: decisionLogs.length > 0 ? decisionLogs[decisionLogs.length - 1].selectedHref : resolvedUrl,
            decisionLogs,
          };

          console.log(
            `     [${task.id}] completed=${taskCompleted}, depth=${clickDepth}, steps=${totalSteps}, backtracks=${backtrackCount} (rate=${backtrackRate}), loops=${loopCount}, scent=${avgScentScore}`
          );
        }

        const taskList = Object.values(taskResults);
        const completedCount = taskList.filter((t) => t.taskCompleted).length;
        const TCR = Number((completedCount / taskList.length).toFixed(4));
        const avgClickDepth = Number(
          (taskList.reduce((acc, t) => acc + t.clickDepth, 0) / taskList.length).toFixed(4)
        );
        const totalBacktrackCount = taskList.reduce((acc, t) => acc + t.backtrackCount, 0);
        const avgBacktrackCount = Number((totalBacktrackCount / taskList.length).toFixed(4));
        const backtrackRate = Number(
          (taskList.reduce((acc, t) => acc + t.backtrackRate, 0) / taskList.length).toFixed(4)
        );
        const totalLoopCount = taskList.reduce((acc, t) => acc + t.loopCount, 0);
        const avgScentScore = Number(
          (taskList.reduce((acc, t) => acc + t.avgScentScore, 0) / taskList.length).toFixed(4)
        );

        const siteRecord: SiteAuditRecord = {
          siteId: site.id,
          siteName: actualSiteName,
          group: site.group,
          region: site.region,
          localTier: site.localTier,
          province: actualProvince,
          requestedUrl,
          resolvedUrl,
          reachable,
          httpStatus,
          loadTimeMs,
          hasSplashPage,
          visualComplexity,
          foragingSummary: {
            TCR,
            tasksCompletedCount: completedCount,
            avgClickDepth,
            totalBacktrackCount,
            avgBacktrackCount,
            backtrackRate,
            totalLoopCount,
            avgScentScore,
          },
          tasks: taskResults,
          auditedAt: new Date().toISOString(),
        };

        allRecords.push(siteRecord);

        const buildMasterSummary = () => ({
          studyTitle: 'Computational Information Foraging and Agentic HCI Auditing of Public-Sector Websites',
          targetVenue: 'Journal of Advances in Information Technology (JAIT)',
          generatedAt: new Date().toISOString(),
          totalSitesAudited: allRecords.length,
          groupACount: allRecords.filter((r) => r.group === 'Group_A_Central').length,
          groupBCount: allRecords.filter((r) => r.group === 'Group_B_Regional').length,
          localTierCounts: {
            Central_Agency: allRecords.filter((r) => r.localTier === 'Central_Agency').length,
            Large_City_PAO: allRecords.filter((r) => r.localTier === 'Large_City_PAO').length,
            Medium_Town: allRecords.filter((r) => r.localTier === 'Medium_Town').length,
            Small_Subdistrict: allRecords.filter((r) => r.localTier === 'Small_Subdistrict').length,
          },
          regionCounts: {
            Central_National: allRecords.filter((r) => r.region === 'Central_National').length,
            North: allRecords.filter((r) => r.region === 'North').length,
            Northeast: allRecords.filter((r) => r.region === 'Northeast').length,
            Central_East: allRecords.filter((r) => r.region === 'Central_East').length,
            South: allRecords.filter((r) => r.region === 'South').length,
          },
          sites: allRecords,
        });

        fs.writeFileSync(cachedFilePath, JSON.stringify(siteRecord, null, 2), 'utf-8');
        fs.writeFileSync(masterOutputPath, JSON.stringify(buildMasterSummary(), null, 2), 'utf-8');
      } finally {
        await Promise.race([
          context.close().catch(() => {}),
          new Promise((resolve) => setTimeout(resolve, 2500)),
        ]);
      }
    }

    fs.writeFileSync(
      masterOutputPath,
      JSON.stringify(
        {
          studyTitle: 'Computational Information Foraging and Agentic HCI Auditing of Public-Sector Websites',
          targetVenue: 'Journal of Advances in Information Technology (JAIT)',
          generatedAt: new Date().toISOString(),
          totalSitesAudited: allRecords.length,
          groupACount: allRecords.filter((r) => r.group === 'Group_A_Central').length,
          groupBCount: allRecords.filter((r) => r.group === 'Group_B_Regional').length,
          localTierCounts: {
            Central_Agency: allRecords.filter((r) => r.localTier === 'Central_Agency').length,
            Large_City_PAO: allRecords.filter((r) => r.localTier === 'Large_City_PAO').length,
            Medium_Town: allRecords.filter((r) => r.localTier === 'Medium_Town').length,
            Small_Subdistrict: allRecords.filter((r) => r.localTier === 'Small_Subdistrict').length,
          },
          regionCounts: {
            Central_National: allRecords.filter((r) => r.region === 'Central_National').length,
            North: allRecords.filter((r) => r.region === 'North').length,
            Northeast: allRecords.filter((r) => r.region === 'Northeast').length,
            Central_East: allRecords.filter((r) => r.region === 'Central_East').length,
            South: allRecords.filter((r) => r.region === 'South').length,
          },
          sites: allRecords,
        },
        null,
        2
      ),
      'utf-8'
    );

    console.log(`\nCompleted foraging audit for ${allRecords.length} sites. Master dataset saved to ${masterOutputPath}`);
  });
});
