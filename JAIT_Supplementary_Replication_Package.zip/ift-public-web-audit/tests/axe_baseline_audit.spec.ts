import { test } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import * as fs from 'fs';
import * as path from 'path';

interface MasterSite {
  siteId: string;
  siteName: string;
  group: string;
  region: string;
  localTier: string;
  requestedUrl: string;
  resolvedUrl: string;
}

interface AxeTopRule {
  id: string;
  impact: string;
  nodes: number;
}

interface AxeSiteAuditRecord {
  siteId: string;
  siteName: string;
  group: string;
  region: string;
  localTier: string;
  resolvedUrl: string;
  scannedUrl: string;
  axeScanned: boolean;
  axeError: string | null;
  axeViolationRuleCount: number;
  axeViolationNodeCount: number;
  axeCriticalNodeCount: number;
  axeSeriousNodeCount: number;
  axeCriticalSeriousNodeCount: number;
  axeModerateNodeCount: number;
  axeMinorNodeCount: number;
  axeLinkNameViolationNodes: number;
  axeImageAltViolationNodes: number;
  axePassRuleCount: number;
  topViolationRules: AxeTopRule[];
  scannedAt: string;
}

test.describe('JAIT RQ4 Static WCAG 2.1 Baseline Audit (axe-core)', () => {
  test('Scan all 60 portals with axe-core WCAG 2.1 AA tags', async ({ browser }) => {
    test.setTimeout(25 * 60 * 1000);

    const resultsDir = path.resolve(__dirname, '..', 'ift_hci_results');
    const masterPath = path.join(resultsDir, 'ift_hci_master_dataset.json');
    const outPath = path.join(resultsDir, 'axe_baseline_dataset.json');

    const master = JSON.parse(fs.readFileSync(masterPath, 'utf-8'));
    const sites: MasterSite[] = master.sites || [];

    const existingMap = new Map<string, AxeSiteAuditRecord>();
    if (fs.existsSync(outPath)) {
      try {
        const prev = JSON.parse(fs.readFileSync(outPath, 'utf-8'));
        for (const rec of prev.sites || []) {
          if (rec.axeScanned) {
            existingMap.set(rec.siteId, rec);
          }
        }
      } catch {
        // Ignore stale or incomplete output file
      }
    }

    const records: AxeSiteAuditRecord[] = [];

    const saveOutput = () => {
      const scannedCount = records.filter((r) => r.axeScanned).length;
      fs.writeFileSync(
        outPath,
        JSON.stringify(
          {
            studyTitle: 'Static WCAG 2.1 AA Accessibility Baseline via axe-core',
            tags: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'],
            generatedAt: new Date().toISOString(),
            totalSites: records.length,
            scannedSuccessCount: scannedCount,
            sites: records,
          },
          null,
          2
        ),
        'utf-8'
      );
    };

    for (let i = 0; i < sites.length; i++) {
      const site = sites[i];
      const cached = existingMap.get(site.siteId);
      const normUrl = (u: string) => (u || '').replace(/\/$/, '').toLowerCase();
      if (cached && cached.axeScanned && normUrl(cached.resolvedUrl) === normUrl(site.resolvedUrl) && normUrl(cached.scannedUrl) === normUrl(site.resolvedUrl)) {
        console.log(
          `[${i + 1}/${sites.length}] Loaded cached axe-core for ${site.siteId} (${site.siteName}): rules=${cached.axeViolationRuleCount}, nodes=${cached.axeViolationNodeCount}`
        );
        records.push(cached);
        continue;
      }

      const context = await browser.newContext({
        viewport: { width: 1366, height: 768 },
        ignoreHTTPSErrors: true,
        userAgent:
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      });

      let scannedUrl = site.resolvedUrl || site.requestedUrl;
      let axeScanned = false;
      let axeError: string | null = null;
      let ruleCount = 0;
      let nodeCount = 0;
      let critNodes = 0;
      let serNodes = 0;
      let modNodes = 0;
      let minNodes = 0;
      let linkNameNodes = 0;
      let imgAltNodes = 0;
      let passCount = 0;
      let topRules: AxeTopRule[] = [];

      try {
        const page = await context.newPage();
        const urlsToTry = Array.from(
          new Set([site.resolvedUrl, site.requestedUrl].filter((u) => Boolean(u)))
        );

        let navOk = false;
        for (const u of urlsToTry) {
          try {
            await page.goto(u, { waitUntil: 'domcontentloaded', timeout: 15000 });
            await page.waitForLoadState('networkidle', { timeout: 3000 }).catch(() => {});
            await page.waitForTimeout(1000);
            scannedUrl = page.url();
            navOk = true;
            break;
          } catch (navErr: any) {
            const msg = String(navErr?.message || '');
            if (msg.includes('interrupted by another navigation') || msg.includes('Execution context was destroyed')) {
              await page.waitForTimeout(1800);
              scannedUrl = page.url();
              navOk = true;
              break;
            }
            axeError = msg.slice(0, 180);
          }
        }

        if (navOk) {
          // If bounced back to a splash page (/intro3/, /event.php) despite requesting resolvedUrl, click Enter Site
          if (normUrl(page.url()) !== normUrl(site.resolvedUrl)) {
            try {
              const enterBtn = page
                .locator('a')
                .filter({ hasText: /(เข้าสู่เว็บไซต์|เข้าสู่หน้าหลัก|enter\s*site|enter\s*website)/i })
                .first();
              if ((await enterBtn.count()) > 0) {
                await Promise.all([
                  page.waitForLoadState('domcontentloaded', { timeout: 10000 }).catch(() => {}),
                  enterBtn.click({ timeout: 5000 }).catch(() => {}),
                ]);
                await page.waitForLoadState('networkidle', { timeout: 3000 }).catch(() => {});
                await page.waitForTimeout(1200);
                scannedUrl = page.url();
              }
            } catch {
              // Proceed with current URL if click fails
            }
          }

          let results: Awaited<ReturnType<AxeBuilder['analyze']>> | null = null;
          for (let attempt = 0; attempt < 2; attempt++) {
            try {
              await page.waitForLoadState('load', { timeout: 4000 }).catch(() => {});
              const analyzePromise = new AxeBuilder({ page })
                .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
                .analyze();
              const timeoutPromise = new Promise<never>((_, reject) =>
                setTimeout(() => reject(new Error('axe-core analyze timeout (>20s)')), 20000)
              );
              results = await Promise.race([analyzePromise, timeoutPromise]);
              scannedUrl = page.url();
              break;
            } catch (axErr: any) {
              if (attempt === 0 && String(axErr?.message || '').includes('Execution context')) {
                await page.waitForTimeout(2200);
                continue;
              }
              throw axErr;
            }
          }
          if (results) {
            axeScanned = true;
            axeError = null;
            ruleCount = results.violations.length;
            passCount = results.passes.length;

            for (const v of results.violations) {
              const nLen = v.nodes.length;
              nodeCount += nLen;
              if (v.id === 'link-name') {
                linkNameNodes += nLen;
              } else if (v.id === 'image-alt') {
                imgAltNodes += nLen;
              }
              for (const n of v.nodes) {
                const imp = (n.impact || v.impact || '').toLowerCase();
                if (imp === 'critical') critNodes++;
                else if (imp === 'serious') serNodes++;
                else if (imp === 'moderate') modNodes++;
                else if (imp === 'minor') minNodes++;
              }
            }

            topRules = results.violations
              .slice()
              .sort((a, b) => b.nodes.length - a.nodes.length)
              .slice(0, 5)
              .map((v) => ({
                id: v.id,
                impact: v.impact || '',
                nodes: v.nodes.length,
              }));
          }
        }
      } catch (err: any) {
        axeError = String(err?.message || err).slice(0, 200);
      } finally {
        await Promise.race([
          context.close().catch(() => {}),
          new Promise((resolve) => setTimeout(resolve, 2000)),
        ]);
      }

      const rec: AxeSiteAuditRecord = {
        siteId: site.siteId,
        siteName: site.siteName,
        group: site.group,
        region: site.region,
        localTier: site.localTier,
        resolvedUrl: site.resolvedUrl,
        scannedUrl,
        axeScanned,
        axeError,
        axeViolationRuleCount: ruleCount,
        axeViolationNodeCount: nodeCount,
        axeCriticalNodeCount: critNodes,
        axeSeriousNodeCount: serNodes,
        axeCriticalSeriousNodeCount: critNodes + serNodes,
        axeModerateNodeCount: modNodes,
        axeMinorNodeCount: minNodes,
        axeLinkNameViolationNodes: linkNameNodes,
        axeImageAltViolationNodes: imgAltNodes,
        axePassRuleCount: passCount,
        topViolationRules: topRules,
        scannedAt: new Date().toISOString(),
      };

      console.log(
        `[${i + 1}/${sites.length}] ${site.siteId} (${site.siteName}): scanned=${axeScanned}, rules=${ruleCount}, nodes=${nodeCount}, crit+ser=${critNodes + serNodes}, linkName=${linkNameNodes}, imgAlt=${imgAltNodes}${axeError ? ' | ERR=' + axeError : ''}`
      );

      records.push(rec);
      saveOutput();
    }

    saveOutput();
    console.log(`\nCompleted axe-core baseline audit across ${records.length} sites -> ${outPath}`);
  });
});
