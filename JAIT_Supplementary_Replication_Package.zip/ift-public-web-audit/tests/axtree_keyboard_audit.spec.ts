import { test } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

interface MasterSite {
  siteId: string;
  siteName: string;
  group: string;
  region: string;
  localTier: string;
  requestedUrl: string;
  resolvedUrl: string;
  visualComplexity: {
    aboveTheFoldLinks: number;
    totalVisibleLinks: number;
    ambiguousLinkRatio: number;
  };
  foragingSummary: {
    TCR: number;
    backtrackRate: number;
  };
  tasks: Record<string, { taskCompleted: boolean; clickDepth: number; avgScentScore: number }>;
}

const STRATIFIED_SITES = ['A16', 'A22', 'B01', 'A01', 'B04', 'B27', 'A02', 'A20', 'B17'];

const TASK_CUES: Record<string, { id: string; keywords: string[]; urlTokens: string[] }> = {
  T1_Contact: {
    id: 'T1_Contact',
    keywords: ['ติดต่อเรา', 'ติดต่อหน่วยงาน', 'ข้อมูลการติดต่อ', 'ติดต่อสอบถาม', 'ช่องทางการติดต่อ', 'ที่อยู่หน่วยงาน', 'แผนที่ตั้ง', 'contact us', 'contact', 'ติดต่อ', 'โทรศัพท์', 'เบอร์โทร', 'สายด่วน'],
    urlTokens: ['contact', 'about', 'location', 'map', 'address', 'tel'],
  },
  T2_ServiceForm: {
    id: 'T2_ServiceForm',
    keywords: ['คู่มือสำหรับประชาชน', 'คู่มือประชาชน', 'ดาวน์โหลดแบบฟอร์ม', 'แบบฟอร์มคำร้อง', 'บริการประชาชน', 'บริการออนไลน์', 'ระบบบริการออนไลน์', 'e-service', 'eservice', 'citizen manual', 'บริการ', 'คู่มือ', 'แบบฟอร์ม', 'คำร้อง', 'ยื่นคำร้อง', 'oss', 'download', 'service'],
    urlTokens: ['service', 'eservice', 'e-service', 'manual', 'form', 'download', 'citizen', 'oss'],
  },
  T3_Procurement_Plan: {
    id: 'T3_Procurement_Plan',
    keywords: ['จัดซื้อจัดจ้าง', 'ประกาศจัดซื้อจัดจ้าง', 'ข่าวจัดซื้อจัดจ้าง', 'ประกวดราคา', 'ราคากลาง', 'สรุปผลการจัดซื้อจัดจ้าง', 'แผนการจัดซื้อจัดจ้าง', 'แผนพัฒนาท้องถิ่น', 'แผนปฏิบัติการ', 'ข้อบัญญัติงบประมาณ', 'แผนพัฒนา', 'งบประมาณ', 'แผนการใช้จ่าย', 'ita', 'oit', 'ความโปร่งใส', 'procurement', 'tender'],
    urlTokens: ['procure', 'egp', 'tender', 'bid', 'budget', 'plan', 'ita', 'oit', 'supply'],
  },
};

function matchesTaskCue(nameOrText: string, href: string, taskKey: string): boolean {
  const cfg = TASK_CUES[taskKey];
  const normText = (nameOrText || '').toLowerCase().trim();
  const normHref = (href || '').toLowerCase().trim();
  if (normText.length > 1) {
    for (const kw of cfg.keywords) {
      if (normText.includes(kw.toLowerCase())) return true;
    }
  }
  for (const tok of cfg.urlTokens) {
    if (normHref.includes(tok.toLowerCase())) return true;
  }
  return false;
}

test.describe('CDP Accessibility Tree & Sequential Keyboard Tab Cross-Validation (9 Portals / 27 Tasks)', () => {
  test('Audit 9 stratified portals via Chromium CDP Accessibility.getFullAXTree and Tab traversal', async ({ browser }) => {
    test.setTimeout(10 * 60 * 1000);

    const resultsDir = path.resolve(__dirname, '..', 'ift_hci_results');
    const masterPath = path.join(resultsDir, 'ift_hci_master_dataset.json');
    const outPath = path.join(resultsDir, 'axtree_keyboard_validation.json');

    const master = JSON.parse(fs.readFileSync(masterPath, 'utf-8'));
    const allSites: MasterSite[] = master.sites || [];
    const siteMap = new Map<string, MasterSite>(allSites.map((s) => [s.siteId, s]));

    const portalRecords: any[] = [];
    const taskComparisons: any[] = [];

    for (const sid of STRATIFIED_SITES) {
      const site = siteMap.get(sid);
      if (!site) continue;

      const context = await browser.newContext({
        viewport: { width: 1366, height: 768 },
        ignoreHTTPSErrors: true,
        userAgent:
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      });

      const page = await context.newPage();
      const normUrl = (u: string) => (u || '').replace(/\/$/, '').toLowerCase();
      let auditedUrl = site.resolvedUrl || site.requestedUrl;

      try {
        for (let navTry = 0; navTry < 2; navTry++) {
          try {
            await page.goto(auditedUrl, { waitUntil: 'domcontentloaded', timeout: 28000 });
            break;
          } catch (navErr: any) {
            const msg = String(navErr?.message || '');
            if (msg.includes('interrupted') || msg.includes('Execution context')) {
              break;
            }
            if (navTry === 1) throw navErr;
            await page.waitForTimeout(1500);
          }
        }
        await page.waitForLoadState('networkidle', { timeout: 3500 }).catch(() => {});
        await page.waitForTimeout(2000);
        auditedUrl = page.url();

        // Splash parity check
        if (normUrl(page.url()) !== normUrl(site.resolvedUrl)) {
          const enterBtn = page
            .locator('a')
            .filter({ hasText: /(เข้าสู่เว็บไซต์|เข้าสู่หน้าหลัก|enter\s*site|enter\s*website)/i })
            .first();
          if ((await enterBtn.count()) > 0) {
            await Promise.all([
              page.waitForLoadState('domcontentloaded', { timeout: 10000 }).catch(() => {}),
              enterBtn.click({ timeout: 5000 }).catch(() => {}),
            ]);
            await page.waitForLoadState('networkidle', { timeout: 3000 }).catch(() => {});
            await page.waitForTimeout(1500);
            auditedUrl = page.url();
          }
        }

        // 1. Extract live DOM visible links & computed accessible labels (with retry on redirect)
        let domLinks: Array<{ text: string; href: string; isAmbiguous: boolean }> = [];
        for (let attempt = 0; attempt < 2; attempt++) {
          try {
            domLinks = await page.evaluate(() => {
              const anchors = Array.from(document.querySelectorAll('a[href]'));
              const visible: Array<{ text: string; href: string; isAmbiguous: boolean }> = [];
              const genericRe = /^(คลิก|คลิกที่นี่|อ่านต่อ|รายละเอียด|ดูทั้งหมด|เพิ่มเติม|เข้าสู่เว็บไซต์|click|click here|read more|more|details|view all|enter)$/i;
              for (const a of anchors) {
                const el = a as HTMLAnchorElement;
                const rect = el.getBoundingClientRect();
                const style = window.getComputedStyle(el);
                if (rect.width <= 2 || rect.height <= 2 || style.display === 'none' || style.visibility === 'hidden') {
                  continue;
                }
                const imgAlts = Array.from(el.querySelectorAll('img'))
                  .map((img) => (img.getAttribute('alt') || '').trim())
                  .filter(Boolean)
                  .join(' ');
                const label = (
                  (el.innerText || '').trim() ||
                  (el.getAttribute('aria-label') || '').trim() ||
                  (el.getAttribute('title') || '').trim() ||
                  imgAlts
                ).replace(/\s+/g, ' ');
                const isAmb = label.length <= 1 || genericRe.test(label);
                visible.push({ text: label, href: el.href || '', isAmbiguous: isAmb });
              }
              return visible;
            });
            auditedUrl = page.url();
            break;
          } catch {
            await page.waitForTimeout(2000);
          }
        }

        // 2. Query Chromium Native Accessibility Tree via CDP
        const cdp = await context.newCDPSession(page);
        const axTree: any = await cdp.send('Accessibility.getFullAXTree');
        const axNodes: any[] = axTree?.nodes || [];
        const axLinkNodes = axNodes.filter(
          (n) => !n.ignored && n.role && n.role.value === 'link'
        );
        const genericAxRe = /^(คลิก|คลิกที่นี่|อ่านต่อ|รายละเอียด|ดูทั้งหมด|เพิ่มเติม|เข้าสู่เว็บไซต์|click|click here|read more|more|details|view all|enter)$/i;
        let axNamedLinks = 0;
        let axUnlabelledOrAmbiguousLinks = 0;
        const axLinkNames: string[] = [];

        for (const ln of axLinkNodes) {
          const accName = String(ln.name?.value || '').replace(/\s+/g, ' ').trim();
          axLinkNames.push(accName);
          if (accName.length <= 1 || genericAxRe.test(accName)) {
            axUnlabelledOrAmbiguousLinks++;
          } else {
            axNamedLinks++;
          }
        }

        // 3. Sequential Keyboard Tab Simulation (60 Tab presses after focusing body)
        await page.evaluate(() => {
          if (document.body) {
            document.body.setAttribute('tabindex', '-1');
            document.body.focus();
          }
        }).catch(() => {});

        const maxTabs = 60;
        const tabStops: Array<{ step: number; tag: string; name: string; href: string }> = [];
        for (let t = 1; t <= maxTabs; t++) {
          await page.keyboard.press('Tab').catch(() => {});
          const active = await page.evaluate(() => {
            const el = document.activeElement as HTMLElement | null;
            if (!el || el === document.body || el === document.documentElement) {
              return null;
            }
            const imgAlts = Array.from(el.querySelectorAll('img'))
              .map((img) => (img.getAttribute('alt') || '').trim())
              .filter(Boolean)
              .join(' ');
            const accName = (
              (el.innerText || '').trim() ||
              (el.getAttribute('aria-label') || '').trim() ||
              (el.getAttribute('title') || '').trim() ||
              imgAlts
            ).replace(/\s+/g, ' ');
            const href = (el as HTMLAnchorElement).href || el.getAttribute('href') || '';
            return {
              tag: el.tagName.toLowerCase(),
              name: accName,
              href,
            };
          }).catch(() => null);
          if (active) {
            tabStops.push({ step: t, ...active });
          }
        }

        const uniqueTabHrefs = new Set(tabStops.map((s) => `${s.tag}:${s.name}:${s.href}`)).size;
        const focusTrapDetected = tabStops.length === 0 || (uniqueTabHrefs <= 2 && axNamedLinks <= 2);

        // 4. Task-level Accessibility Tree + Keyboard reachability vs IFT Agent outcome
        for (const taskKey of ['T1_Contact', 'T2_ServiceForm', 'T3_Procurement_Plan']) {
          const iftPass = Boolean(site.tasks[taskKey]?.taskCompleted);
          const axHasTaskLink = axLinkNames.some((nm) => matchesTaskCue(nm, '', taskKey));
          const tabReachedTaskLink = tabStops.some(
            (ts) => ts.name.length > 1 && matchesTaskCue(ts.name, ts.href, taskKey)
          );
          const axKeyboardReachable = Boolean(
            axHasTaskLink && !focusTrapDetected
          );

          taskComparisons.push({
            siteId: sid,
            siteName: site.siteName,
            group: site.group,
            taskId: taskKey,
            iftCompleted: iftPass ? 1 : 0,
            axHasNamedTaskCue: axHasTaskLink ? 1 : 0,
            tabReachedTaskCueIn60: tabReachedTaskLink ? 1 : 0,
            axKeyboardCompositePass: axKeyboardReachable ? 1 : 0,
            focusTrapDetected,
          });
        }

        const domAmbigRatio =
          domLinks.length > 0
            ? domLinks.filter((d) => d.isAmbiguous).length / domLinks.length
            : 1.0;
        const axAmbigRatio =
          axLinkNodes.length > 0 ? axUnlabelledOrAmbiguousLinks / axLinkNodes.length : 1.0;

        portalRecords.push({
          siteId: sid,
          siteName: site.siteName,
          group: site.group,
          resolvedUrl: site.resolvedUrl,
          auditedUrl,
          iftRecordedTCR: site.foragingSummary.TCR,
          iftRecordedAmbigRatio: site.visualComplexity.ambiguousLinkRatio,
          liveDomVisibleLinks: domLinks.length,
          liveDomAmbigRatio: Number(domAmbigRatio.toFixed(4)),
          cdpTotalAXNodes: axNodes.length,
          cdpAXLinkNodes: axLinkNodes.length,
          cdpAXNamedLinks: axNamedLinks,
          cdpAXUnlabelledOrAmbigLinks: axUnlabelledOrAmbiguousLinks,
          cdpAXAmbigRatio: Number(axAmbigRatio.toFixed(4)),
          keyboardTabStopsCount: tabStops.length,
          keyboardUniqueFocusTargets: uniqueTabHrefs,
          keyboardFocusTrapDetected: focusTrapDetected,
        });

        console.log(
          `[AXTree+Tab] ${sid} (${site.siteName}): DOM_links=${domLinks.length}, AX_links=${axLinkNodes.length} (named=${axNamedLinks}, ambig=${(axAmbigRatio * 100).toFixed(1)}%), TabUnique=${uniqueTabHrefs}/60, trap=${focusTrapDetected}`
        );
      } catch (err: any) {
        console.error(`[AXTree+Tab Error] ${sid}: ${err?.message || err}`);
      } finally {
        await context.close().catch(() => {});
      }
    }

    // Compute concordance statistics across 27 tasks
    let tp = 0, tn = 0, fp = 0, fn = 0;
    for (const tc of taskComparisons) {
      if (tc.iftCompleted === 1 && tc.axKeyboardCompositePass === 1) tp++;
      else if (tc.iftCompleted === 0 && tc.axKeyboardCompositePass === 0) tn++;
      else if (tc.iftCompleted === 1 && tc.axKeyboardCompositePass === 0) fp++;
      else if (tc.iftCompleted === 0 && tc.axKeyboardCompositePass === 1) fn++;
    }
    const nTasks = taskComparisons.length;
    const agreement = nTasks > 0 ? (tp + tn) / nTasks : 0;
    const pYesIft = (tp + fp) / nTasks;
    const pYesAx = (tp + fn) / nTasks;
    const pe = pYesIft * pYesAx + (1 - pYesIft) * (1 - pYesAx);
    const kappa = pe < 1 ? (agreement - pe) / (1 - pe) : 1.0;

    const payload = {
      studyTitle: 'Chromium CDP Accessibility Tree & Sequential Keyboard Tab Cross-Validation',
      generatedAt: new Date().toISOString(),
      nPortals: portalRecords.length,
      nTasks,
      concordanceSummary: {
        tp_both_pass: tp,
        tn_both_fail: tn,
        fp_ift_pass_ax_fail: fp,
        fn_ift_fail_ax_pass: fn,
        exactAgreementRate: Number(agreement.toFixed(4)),
        cohensKappa: Number(kappa.toFixed(4)),
      },
      portals: portalRecords,
      taskComparisons,
    };

    fs.writeFileSync(outPath, JSON.stringify(payload, null, 2), 'utf-8');
    console.log(`\nSaved CDP AXTree + Keyboard Tab validation -> ${outPath}`);
    console.log(`Concordance across ${nTasks} tasks: Agreement=${(agreement * 100).toFixed(2)}%, Cohen's kappa=${kappa.toFixed(4)} (TP=${tp}, TN=${tn}, FP=${fp}, FN=${fn})`);
  });
});
